---
name: cooplens-skill
description: Analyze Chinese-foreign cooperative undergraduate programs and institutions for parents with official-source verification, direct parent-facing answers before Markdown/PDF reports, local project/ranking indexes as discovery-only aids, multi-project comparison, province/score/rank candidate retrieval, and CoopLens parent-facing report workflows. Use when the assistant is asked for CoopLens, 中外合作办学项目/机构分析, 家长版择校报告, 单项目分析, 多项目对比, 按省份分数位次检索候选项目, 官方来源核验, or cooperative-program comparison.
---

# CoopLens Skill 1.0.12

## Use Order

1. Before producing any CoopLens analysis, read `references/core_workflow.md`.
2. When a task requires source collection, fact verification, ranking lookup, admission data, tuition/certificate checks, curriculum checks, employment/further-study data, or current-year approvals, also read `references/source_methods.md`.
3. When generating or validating structured reports, read `references/schema.md` and `prompts/report_modules.md`.
4. Use `scripts/cooplens_core.py` for deterministic local-index lookup, ranking-name lookup, privacy checks, report policy checks, and best-effort link checks. Run package `validate` only when the user explicitly asks to validate the package; never expose validation/install status on the startup page.

## Operating Contract

- At the beginning of every CoopLens execution, before source collection or analysis, obtain the runtime date/time through an available tool instead of relying on model memory, file timestamps, cached years, or the user prompt. Preferred order: `user_info.get_user_info` when available for the user's local date/time; otherwise run `python scripts/cooplens_core.py runtime-date` or an equivalent system/Python date tool. Record `current_date`, `current_year`, `timezone`, `date_source_tool`, and `checked_at` internally.

- Startup is not an installation report. When the user asks to start/launch the skill, never write “已成功启动/安装完成/验证结果/必需文件完整/包结构有效/功能概览/如何使用”, never show a table, and never invent free-form example prompts. Output only the fixed clean three-card startup page from `references/core_workflow.md`, with the fixed disclaimer as the first non-empty line and the runtime-date line second. If you run `validate` internally, keep its result hidden and still output the clean startup page only.
- In every direct chat answer, Markdown report, and PDF report, put a visible runtime-date line immediately after the fixed disclaimer: `检索执行日期：YYYY年MM月DD日（时区：...；通过工具获取）` and use that year to decide current-year approvals, current-year admissions, and whether the latest completed admission year is available.
- Treat `data/project_major_index.json` and `data/rankings_local_compact.json` as discovery and alias-matching aids only. Do not cite them as final user-facing sources.
- Verify every key fact through opened official or authoritative original sources before writing it into a direct answer, Markdown report, or PDF.
- Apply this globally: empty URLs, unreachable URLs, and sources whose content does not contain the corresponding fact are not valid evidence. If verification fails, do not write the data value; write only that no valid public source was verified.

- Key-data evidence final check is mandatory. For rankings, employment/further-study/overseas-study/postgraduate-recommendation rates, tuition/fees, scores, admission ranks, admission-plan counts, QS rankings, ShanghaiRanking/软科 rankings, industry scale, company revenue/profit/growth, hiring/headcount indicators, and any figure used for ordering, the final product must verify that the linked source exists, the link is usable, and the opened content actually supports the displayed value or derived calculation. Before delivery, run `python scripts/cooplens_core.py key-data-evidence-check <final-answer.md>` when a report contains these values; if the check cannot confirm support, remove the value or rewrite it as not verified.

- Function 2 and Function 3 must match Function 1's evidence and PDF quality standard. Do not let Function 2/3 degrade into a dense database-style candidate list. Scores, ranks/位次, tuition, admission-plan counts, rates, rankings and calculated ranges must be directly clickable in the PDF body itself, not only in Markdown and not only in the final source list. After PDF generation, run both `python scripts/cooplens_core.py pdf-key-data-link-check <report.pdf>` and `python scripts/cooplens_core.py pdf-visual-layout-check <report.pdf>`; if either fails, regenerate the report/PDF before delivery.
- Function 2/3 PDF reports must use a card-first layout. The body may use only narrow two-column fact tables inside each card; never use wide candidate/comparison tables that mix project name, specialty, score/rank, tuition, city and mode in one row. Summary ranking should be a numbered card list or compact one-column cards, with data values embedded as clickable links.
- Function 2 is now table-hostile by default: for multi-project comparison reports, do not use Markdown pipe tables in the body or in the final reference-source section. Use numbered project cards, HTML/CSS card blocks, or one-field-per-line lists. If the executor drafts any Function 2 Markdown pipe table before the final source section, or a source-section pipe table with long links, it must regenerate the report before PDF export.
- Function 2 key-data parity rule: every score, rank/位次, QS/软科 ranking, tuition/fee, plan count, cost estimate, rate, rank gap, calculated admission range and recommendation basis must be directly linked in the direct text and preserved as a clickable annotation in the PDF. A final source list is not a substitute. If a value cannot be linked to an opened supporting source, omit the value or say `未核到可打开且内容对应的官方/权威原文`.
- Function 2 completion must run `python scripts/cooplens_core.py function2-check <report.md>`, `python scripts/cooplens_core.py key-data-evidence-check <report.md>`, `python scripts/cooplens_core.py pdf-visual-layout-check <report.pdf>`, and `python scripts/cooplens_core.py pdf-key-data-link-check <report.pdf>` after generation. If any check fails, the answer/PDF must be regenerated; do not deliver a known-failed PDF.
- Function 3 new/no-history projects must be user-friendly. If a new project is kept in the recommended candidate list, give a visible rough rank reference range or three-scenario range (optimistic / neutral / conservative) with linked input data and formula. Do not write `待补充具体数据`, `待补充样本数据`, `暂无法给出准确的位次估算范围`, or tell the user to calculate it themselves. If the evidence is too weak to form any rough range, remove the item from the ranked recommendation and place it in a separate “仅关注/待核验，不参与排序” card.
- Function 3 new-project/no-history rank estimation is a high-risk inference. For any 新开项目、首次招生、本省首招、无历史线、暂无本项目历史线 or 新获批项目, do not give only one estimated rank/score. Show the complete estimation basis: project status, latest completed admission-year basis, official approval/admission-plan evidence, B ordinary-admission baseline, A same-province same-tier ordinary-vs-cooperative/international samples, similarity dimensions, sample count and weakness, formula, rough range, non-prediction boundary, and clickable evidence for every numeric input. Run `python scripts/cooplens_core.py function3-new-project-estimation-check <report.md>` before delivery.
- All user-facing numeric data values must carry the approximate-prefix rule: write `约` immediately before the value for scores, ranks, rankings, percentages/rates, tuition/fees, plan counts, enrollment counts, rank gaps, cost totals, course ratios, and calculated ranges in direct chat answers, Markdown, and PDF. Do not show a bare numeric data value such as `589分`, `第133名`, `30%`, `4.8万元/年`, or `120人`; write `约589分`, `约第133名`, `约30%`, `约4.8万元/年`, `约120人`.
- Reference sources must never be text-only. Every user-facing source must be a clickable hyperlink or citation that opens to the original page/PDF/attachment. Reports should not repeat separate `数据来源/来源链接/原文链接` blocks under every module; instead, keep important numeric values directly clickable in the body and place one consolidated `参考来源与核验说明` section at the very end of the direct chat answer, Markdown, and PDF.
- Important numeric indicators must be hyperlinks themselves, not merely followed by a source column or source list. For scores, ranks, rankings, rates, tuition/fees, plan counts, enrollment counts, rank gaps, cost totals, course ratios, and calculated ranges, the displayed value must be written as a clickable value such as `[约589分](https://...)`, `[约第133名](https://...)`, `[约30%](https://...)`, or an HTML `<a href="...">约589分</a>` anchor. In direct ChatGPT chat where native citations cannot wrap the number, put the citation immediately after the numeric value as the fallback; Markdown and PDF should use the number itself as the hyperlink. If an important numeric value cannot be directly linked to a valid source, do not silently leave it bare; mark it as `【未满足：数字未直接链接来源】` or withhold the value.
- For 升学率、出国率、考研率、保研率, write the year, source level, and source-validity status; the detailed source link may be placed in the final `参考来源与核验说明` section, while any numeric rate itself must remain directly clickable. If project-level data is not public, state the checked year/source level and the unresolved boundary instead of omitting the item.

- 保研率/推免率 is a high-impact numeric indicator. If any user-facing output states a 保研率、推免率、推免比例、推荐免试人数/名额 or similar value, the numeric value itself must be a clickable link to an opened official or authoritative source. Valid evidence includes school/college 推免办法、推免实施细则、推免名额分配、推免资格公示、推免名单、就业质量报告 or 本科教学质量报告. Third-party summaries or public discussion cannot support a 保研率/推免率 number. If project-level or major-level 保研率 is not public, state `项目级保研率/推免率未核到官方公开数据` and explain the source level and boundary; do not invent, infer, or copy an unsupported rate.

- PDF visual layout final check is mandatory. After generating any PDF for Function 1/2/3, the executor/agent must open or render the actual PDF and check that no table cell text overlaps, no line is clipped, and no link text covers adjacent text. Do not rely only on Markdown table checks. Run `python scripts/cooplens_core.py pdf-visual-layout-check <report.pdf>` when a local PDF path is available, or run it on the final answer containing a sandbox/local PDF link. If any overlap or unreadable table is found, regenerate the PDF with card-style sections or split tables before delivery.
- Dense comparison/candidate Markdown pipe tables must not be sent directly to PDF. In Function 2/3, any table mixing 学校/项目、专业、分数/位次、学费、培养模式/证书 should be converted to project cards or several narrow two-column tables before PDF export. Five columns is already unsafe for A4 Chinese PDF; treat the screenshot-style 5-column table as a hard failure.
- Key-data evidence checks must run in open-link mode before final delivery. `--no-open` is allowed only for local drafting diagnostics, never as the final gate. If a link cannot be opened, is empty, redirects to an irrelevant page, or the opened page/PDF does not contain evidence for the displayed value, remove that value and write `未核到可打开且内容对应的官方/权威原文` instead of keeping a broken or unsupported linked number.
- Function 2/3 PDF table layout hard rule: do not render wide dense tables into PDF. For multi-project comparison and candidate-retrieval reports, any body table with more than 5 columns, any long narrative cell, or any cell containing long URLs/source text must be split into smaller tables or converted to project cards before PDF generation. PDF table cells must auto-wrap, use auto row height, top vertical alignment, adequate padding and line-height, and must never use fixed row heights, `white-space: nowrap`, `overflow: hidden`, or ReportLab fixed `rowHeights`. Same-cell text overlap is a hard failure.


- For Function 2 multi-project comparison, the direct chat answer, Markdown report, and PDF report must use the 11-chapter decision structure. Chapter 6 must be “专业与行业前景对比” and must compare future employment for each project over the student's graduation/early-career horizon of roughly 4–8 years: industry scale, cycle/prosperity, representative leading-company performance, AI productivity impact, entry-level job compression/expansion, future talent demand, hiring/JD signals, and concrete student response. A Function 2 output that only compares current outcome rates or current employment destinations is incomplete.
- In Function 3, when a candidate project has no prior target-province admission line / no historical admission information and any admission rank, relative position, or sorting position must be inferred, never show only one inferred value or one inferred rank. The output must include a complete “推测依据” chain: B 普通招生基线, A 同省同档普通—中外/国际路径位次差样本, sample count and sample weakness/strength, calculation formula, B 粗略参照范围, and a non-prediction boundary. Every numeric datum inside that basis must be clickable itself and linked to the corresponding official/authoritative source. If the basis is incomplete, mark the item as `【未满足：无历史线推测依据不完整】`; if a basis datum lacks a direct source hyperlink, mark it as `【未满足：推测依据数据缺少链接】`.
- Start every user-facing text produced under this skill with the fixed disclaimer defined in `references/core_workflow.md`.

- Every user-visible reply under this skill, including short acknowledgements, progress notes, error explanations, PDF download notes, and follow-up answers, must start with the fixed disclaimer as the first non-empty line. Do not reserve the disclaimer only for full reports.
- Every user-visible textual response generated by CoopLens Skill must start with the fixed disclaimer as the first non-empty line. For analysis/report deliveries (chat final answer, Markdown report, PDF-visible text, PDF download message), the final non-empty line must also repeat the exact same disclaimer. Do not replace the final disclaimer with any source-scope sentence.
- Never write footer or closing statements such as “本报告所有数据均来自公开可查的网络信息，由AI整理生成”, “所有数据均来自公开可访问页面”, “所有信息均来自公开渠道”, “全部数据已核实”, “所有数据都有官方来源”, or any similar blanket source guarantee. If the internal final review detects this problem in chat, Markdown, or PDF-visible content, the output is invalid and the executor/agent must regenerate the report before delivery.
- Never make blanket source guarantees such as “所有数据均来自公开可访问页面”, “所有信息均来自公开渠道”, “全部数据已核实”, or “所有数据都有官方来源”. Some facts may come from user-provided files, inaccessible attachments, partial public pages, derived calculations, or unresolved checks. Use cautious wording only: the final `参考来源与核验说明` lists the sources actually used and the boundaries that still need confirmation.
- Before delivering any user-visible final answer, Markdown report, or PDF report, perform an internal executor/agent final review of the generated product. This is not a mandatory external language-model API call. Default to the current execution platform's agent or scheduler (for example Codex, 豆包办公任务, ChatGPT, or another agent that can read/write files and run local scripts) to re-read the output, run deterministic checks, revise failures, and then deliver. If API quota is explicitly available and the user/environment permits it, an external model/API may be used only as an optional supplementary reviewer; never make API access a prerequisite. Re-read the whole output and generated report for: fixed disclaimer at the first non-empty line, runtime date line, no forbidden blanket source guarantee, no per-module source clutter, final consolidated sources with clickable links, important numeric values linked directly, 保研率/推免率 evidence, Function 1/2/3 completeness, PDF delivery, and Function 2/3 table layout. If the review finds any issue, revise and re-run the relevant checks before output. Do not expose the internal review checklist unless the user asks.
- For functions 1/2/3, answer the parent directly in chat first, then generate Markdown/PDF from the same facts unless the user explicitly asks not to.
- 全功能 PDF 强制交付硬规则: Function 1/2/3 outputs must end in the same response with a visible, clickable PDF download link. A Markdown-only fallback, “PDF 生成失败”, “请继续生成 PDF”, “稍后生成 PDF”, “见 PDF”, or asking the user to prompt again is not a completed delivery. If a PDF tool fails, the executor/agent must keep converting/regenerating with another available method before final delivery, or clearly mark the run as not completed rather than presenting it as finished.
- 全功能完成闸门: Function 1/2/3 outputs are not complete until the same response includes (a) the complete function-specific chapter structure, (b) 专业与行业前景/未来约4–8年就业分析, (c) important numeric values with direct source hyperlinks, (d) one final consolidated `参考来源与核验说明` section with clickable original sources, (e) Markdown/PDF generated from the same facts, and (f) a visible clickable PDF download link. Do not stop after a short 6–7 section chat answer. Never write “见PDF/稍后生成PDF/请继续生成PDF”; generate and link the PDF in the current response.
- Keep final reports parent-facing: no internal claim ledger, no script output, no `claim_id`, no `audit_status`, no `verified`/`unresolved` labels, and no local-cache wording as evidence.

## Packaging Contract

- License the package as MIT-0; keep `license.txt` in the skill root.
- Keep OpenClaw-style compatibility: a single skill folder with `SKILL.md`, frontmatter `name` and `description`, and plain-language operating instructions.
- Do not include install hooks, post-install scripts, obfuscated commands, encoded shell payloads, hidden network startup behavior, secrets, credentials, or machine-specific absolute paths.
- Require user-invoked validation for network checks; `link-check` only opens URLs explicitly present in a report file.

## Helper Commands

Run from the skill root:

```bash
python scripts/cooplens_core.py runtime-date
python scripts/cooplens_core.py validate
python scripts/cooplens_core.py query --query "<学校/项目/专业>" --top 8
python scripts/cooplens_core.py rank-query --query "<学校或外方高校>" --top 8
python scripts/cooplens_core.py report-check <report.md>
python scripts/cooplens_core.py numeric-link-check <report.md> --annotate-out <marked.md>
python scripts/cooplens_core.py consolidated-source-check <report.md>
python scripts/cooplens_core.py function2-check <report.md>
python scripts/cooplens_core.py function3-estimation-check <report.md> --annotate-out <marked.md>
python scripts/cooplens_core.py postgraduate-recommendation-check <report.md>
python scripts/cooplens_core.py pdf-table-layout-check <report.md> --annotate-out <marked.md>
python scripts/cooplens_core.py pdf-delivery-check <final-answer.md>
python scripts/cooplens_core.py completion-gate-check <final-answer.md>
python scripts/cooplens_core.py final-product-audit-check <final-answer.md>
python scripts/cooplens_core.py link-check <report.md> --max-urls 20
```


补充硬规则：打开链接后内容必须真的支撑数字；打不开或内容不对应必须删除数据，改写为未核到可打开且内容对应的官方/权威原文。


## 1.0.12 HTML/PDF 交付与防截断硬规则

- HTML 强制交付硬规则：功能 1/2/3 完成时必须同时交付 Markdown、HTML、PDF 三件套；同一轮回答必须有可点击 PDF 下载链接、HTML 可视化报告链接和 Markdown 报告链接。运行 `python scripts/cooplens_core.py artifact-delivery-check <final-answer.md>`、`html-delivery-check`、`pdf-delivery-check`，任一失败都必须重新生成。
- HTML 不使用固定内容模板：HTML 必须从同一份 Markdown 生成，只能把 Markdown 的标题、段落、列表、链接、卡片化结构转成 HTML 标签并加 CSS；不能在 HTML 中新增项目、说明、统计、标题、图片、页脚口号、示例内容或任何 Markdown/PDF 没有的可见文字。
- HTML 与 Markdown/PDF 内容一致性：HTML、Markdown、PDF 的章节顺序、正文、关键数据、链接、核验边界、免责声明必须保持一致。运行 `python scripts/cooplens_core.py html-consistency-check <report.md> <report.html>`；发现 HTML 与 Markdown/PDF 内容不一致，标记 `【未满足：HTML与Markdown/PDF内容不一致或添加了额外内容】` 并重新生成。
- 不得增加图片：HTML 报告不得新增 `<img>`、SVG、canvas、iframe、外部图片、背景图片、图标库或脚本。视觉效果只能来自 CSS 的色彩、留白、边框、阴影、卡片、标签、时间线和响应式布局；不能添加其他图片。
- 色彩与布局提示词：HTML 可参考现代前端报告页的轻量风格，但只作为样式层使用。建议使用浅色背景、白色卡片、圆角、轻微阴影、蓝紫/青绿/琥珀等少量强调色、清晰标题层级、项目卡片、来源卡片、提示框、宽松行距、可打印 CSS；不得改变内容。
- PDF 文本防截断硬规则：PDF 不能出现文本截断、同一行被裁剪、免责声明被切掉、表格单元格文字叠加。Markdown/HTML 转 PDF 时必须设置 `overflow-wrap:anywhere`、`word-break:break-word`、`line-break:anywhere`、`white-space:normal`、`hyphens:auto`、`height:auto`、`max-width:100%`，并禁止 `white-space:nowrap`、`overflow:hidden`、固定高度和固定行高。
- 每行固定字数上限：面向 PDF 的可见段落建议约 32-38 个中文字符后自然换行；免责声明、来源 URL、长项目名、长专业名、长数值解释必须允许自动换行。执行 `python scripts/cooplens_core.py pdf-text-wrap-check <report.md-or-html>`；出现 `【未满足：PDF存在文本截断/换行风险，必须重新生成】` 时必须重排。
- PDF 必须优先从已通过 `html-report-check` 的 HTML 导出，而不是直接把 Markdown 宽表转 PDF。HTML/PDF 中仍不得使用 Function 2/3 宽表，候选项目、费用、位次、证书、课程、来源均优先使用卡片或窄列表。
- 产物交付前必须依次运行：`html-report-check <report.html>`、`html-consistency-check <report.md> <report.html>`、`pdf-text-wrap-check <report.html>`、`pdf-visual-layout-check <report.pdf>`、`pdf-key-data-link-check <report.pdf>`、`completion-gate-check <final-answer.md>`。任何一步失败都必须重新生成 Markdown/HTML/PDF 三件套。


兼容校验短语：Markdown、PDF、HTML 三件套；从同一份 Markdown 生成 HTML；内容严格一致；不能添加额外内容；视觉样式只能来自 CSS；免责声明可视化换行；CJK line breaking；不得截断文本；发现截断必须重新生成。
