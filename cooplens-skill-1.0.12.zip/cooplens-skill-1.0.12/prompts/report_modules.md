# Report Module Subprompts — 1.0.12

## 0. Generation contract

Generate a parent-facing report. Every text answer produced under this skill, including startup prompts, progress notes, direct chat answers, Markdown, PDF content and attachment notes, must use the fixed disclaimer as the first non-empty line. Do not write like an internal database. For functions 1/2/3, first produce a complete parent-friendly direct chat answer, then generate the PDF from the same answer. Each module must answer: conclusion → evidence → what must be verified next. Avoid sounding like a textbook or audit memo.

Core parent mindset: many families choose Chinese-foreign cooperative programs as a higher-budget route to expand admission choices and obtain a stronger domestic university brand, better city, suitable major access, recognizable domestic credentials, and possibly an additional foreign degree. Keep the wording calm and implicit. Use “录取门槛差异、位次空间、平台匹配度、家庭投入边界、竞品项目坐标”; do not use blunt phrases such as “花钱买平台/低分进名校/用钱补分”.

Evidence-link contract: Every number, ranking and key fact in the direct chat answer, Markdown and PDF must be backed by opened official/authoritative original sources. To reduce repeated clutter, do not write a separate “数据来源/来源/来源链接/原文链接” block under every module and do not add a source column to every body table by default. Instead, important numeric indicators in the body must remain directly clickable, such as `[约589分](https://...)`, while all user-facing reports must end with one consolidated `参考来源与核验说明` section. That final section lists the original source name, clickable link, source type, source year/publication time, what it supports, and any boundary to reconfirm. Reference sources cannot be text-only: do not write only “学校官网/CRS/省考试院/QS/软科/招生章程” without a clickable hyperlink. Empty URLs, unreachable URLs, and URLs whose page content does not contain the corresponding fact are invalid; if verification fails, do not write the data value. Required linked facts include scores, ranks, plan counts, tuition, fees, certificates, approval status, study-mode conditions, course ratios, industry scale, market size, revenue, profit, growth, employment/headcount/recruitment indicators, employment/further-study/overseas-study/recommendation-for-postgraduate-study data, QS/软科 rankings, 985/211/双一流/C9 labels and any fact used for ordering. 升学率、出国率、考研率、保研率 must each show the statistical year, source link, source level, and source-validity/content-match status in the final consolidated source section or immediately next to the value when needed. Public discussion is the only exception and must remain anonymous; it cannot support official facts. If any output uses the literal block label “数据来源：”, the entire line/block must be red, and the text immediately after the colon must be “上述信息务必需要用户自行确认，本报告为AI生成，不对真实性负责”. Preferred final-source heading: `## 参考来源与核验说明`.



Key-data evidence final-audit contract: At the end of every Function 1/2/3 generation, before delivery, the executor/agent must audit all key data links. This covers 各种排名、就业率、升学率、保研率/推免率、出国/境升学率、学费、分数线、排位/位次、招生人数、QS排名、软科排名、行业规模、企业营收/利润/增速、招聘/员工指标 and every figure used in ordering. A valid data link must exist, be openable by the available tool/agent workflow, and the opened content must actually support the value, year, province, subject category, major/project level, and source level. If a link cannot be opened or the content does not support the number, remove the number or write “未核到官方/权威公开数据”; never leave a confident number with an unsupported link. Run `key-data-evidence-check` and include link-status/content-match boundaries in the final `参考来源与核验说明` section.


Function 2/3 parity contract: Function 2 and Function 3 must not be less strict than Function 1. In multi-project comparison and candidate retrieval reports, every score/rank, tuition, plan count, rate, QS/软科 ranking and calculated interval must remain a clickable numeric anchor in the body and in the generated PDF. The final source section is an archive, not a substitute for linked data values. Before delivery, the actual PDF must pass `pdf-key-data-link-check` and `pdf-visual-layout-check`; a PDF with zero link annotations or with bare key numbers is invalid and must be regenerated.

Function 2/3 card layout contract: For Function 2 and Function 3, do not render a wide Markdown pipe table in the PDF body. Use project cards/candidate cards. Each card should include: project name, fit judgment, admission reference with linked score/rank, tuition with linked fee, certificate/mode, major match, uncertainty boundary, and “next verification”. Within a card, use only 2-column mini tables or short bullet lists. Ranking/summary sections should be numbered cards, not dense tables.

Function 3 new-project user-friendly range contract: For any 新开/首招/无历史线 candidate that remains in the recommended list, provide a rough rank reference range or three-scenario range. The range must be computed from linked inputs: B ordinary-admission baseline, A same-province same-tier ordinary-vs-cooperative/international samples, similarity adjustments and sample-strength note. Phrases like “待补充具体数据”, “待补充样本数据”, “暂无法给出准确的位次估算范围”, “用户自行计算/关注官方信息即可” are not acceptable final output. If the basis is too weak, move the item to “仅关注/待核验，不参与排序” and explain why.

Function 3 new-project estimation contract: For 新开项目、首次招生、本省首招、新获批项目 or 无历史线/暂无本项目历史线 projects, rank estimation must be generated as a complete evidence chain, not a single estimate. Required elements are 项目状态、官方/权威基础事实、B普通招生基线、A同省同档样本、相似性维度、样本数量与样本强弱、计算公式、B粗略参照范围、非预测边界 and clickable/source-verified numbers. Run `function3-new-project-estimation-check`; if incomplete, mark `【未满足：新开/无历史线项目位次估算理由链不完整】` and fix before PDF delivery.


Numeric-link contract: For every important numeric indicator, the number itself must be the clickable source anchor. Do not rely only on a separate “来源链接” cell, a footnote at the end of the paragraph, or a generic source list. Preferred output forms are `[约589分](https://...)`、`[约第133名](https://...)`、`[约30%](https://...)`、`[约4.8万元/年](https://...)`、`<a href="https://...">约120人</a>`. For ranges, link each endpoint or link the complete range text: `[约2万—约3万位](https://...)`. In ChatGPT direct replies, if the interface only supports citations, the citation must immediately follow the numeric value; Markdown and PDF must make the displayed numeric value a hyperlink. If any important numeric indicator is not directly hyperlinked, mark it immediately after the value as `【未满足：数字未直接链接来源】` before finalizing, then fix or remove the value.



Postgraduate-recommendation evidence contract: 保研率/推免率 is a high-impact field. A report may not output a numeric 保研率、推免率、推免比例、推荐免试人数 or 推免名额 unless the value itself is directly hyperlinked to an opened official/authoritative original source and the final `参考来源与核验说明` records year, source level, source type, supported field and content-match status. Valid sources are 学校/学院推免办法、推免实施细则、推免名额分配、推免资格公示、推免名单、就业质量报告、本科教学质量报告、教务处/研究生院/学院官网 official pages. Third-party summaries, public discussion and local indexes cannot support the number. If project-level data is unavailable, write `项目级保研率/推免率未核到官方公开数据` and use only policy/qualification wording with a clear boundary.

PDF table-layout contract: Function 2 and Function 3 reports must be designed for PDF before conversion, not repaired after conversion. Do not put large comparison/candidate/source tables into A4 PDF as dense Markdown tables. Body tables should normally have no more than 5 columns; cells with long explanations, links, source names, or multi-sentence content must become stacked cards or split tables. For HTML/Markdown PDF, require wrapping styles such as `white-space: normal; overflow-wrap: anywhere; word-break: break-word; vertical-align: top; line-height: 1.45; padding: 6px 8px; height: auto;`. For ReportLab, use `Paragraph` objects, `VALIGN=TOP`, `splitByRow=True`, no fixed `rowHeights`, and CJK word wrapping. If a table would cause same-cell text overlap, convert it to card layout before PDF generation. Run `pdf-table-layout-check` on Function 2/3 Markdown before PDF delivery.

Approximate-value contract: All user-facing numeric data in direct chat answers, Markdown and PDF must add `约` immediately before the displayed value. This applies to scores, ranks, rankings, rates/percentages, plan counts, enrollment counts, tuition/fees, total costs, course ratios, rank gaps, industry scale, market size, revenue, profit, growth, employee counts, recruitment counts, calculated ranges and historical reference intervals. Use `约589分`, `约第133名`, `约30%`, `约4.8万元/年`, `约120人`, `约2万—约3万位`; do not output bare numeric data such as `589分`, `第133名`, `30%`, `4.8万元/年`, `120人`. For ranges, add `约` to both ends. Keep original exact values internally for source matching.

Runtime-date contract: Before any search, source collection, comparison, or report drafting, acquire the current date/time through an available tool. Use `user_info.get_user_info` when available, otherwise run `python scripts/cooplens_core.py runtime-date` or an equivalent system/Python date command. Do not use model memory, local index years, file timestamps, cached reports, or the user's wording as the current-year basis. Direct chat answers, Markdown reports and PDF reports must all show, immediately after the fixed disclaimer and before the title/conclusion, `检索执行日期：YYYY年MM月DD日（时区：...；通过工具获取）`. This runtime date controls current-year approval search, current-year admission-plan checks, and whether admission lines are treated as latest completed-year data. 中文输出中要写清运行时日期如何判断“最新完成招生年度”。

Major-industry-AI contract: Function 1 and Function 2 must include a visible 专业与行业前景分析 module. The module must not be a generic major introduction. It must map the major to its main industry/sub-industry, then analyze 行业规模、景气程度、龙头企业业绩、人工智能对行业的影响、行业员工招聘的影响、学生如何应对. The analysis must focus on the future employment horizon of roughly 4–8 years after enrollment, because families care about the labor market when the student graduates and enters early career. It must explicitly cover AI productivity impact, task automation/augmentation, entry-level job compression or expansion, future talent demand, and concrete ways to prepare. For Function 2, add a dedicated comparison chapter and a qualitative “专业/行业景气与AI适应度排序”; do not use scores. All numbers in this module must follow the `约` prefix and numeric-self-link contract.

Local index rule: local project/ranking indexes, old reports and cached files are discovery aids only. They are never user-facing sources. Anything copied from them must be re-verified through an opened official/authoritative original link before appearing in the direct answer, Markdown or PDF.

Startup-page contract: when the user only asks to start/launch CoopLens, output the clean startup page only. The first non-empty line is the fixed disclaimer, the second line is the tool-acquired runtime-date line, and then exactly three function cards: ① 单项目分析, ② 多项目对比, ③ 按所在省份 + 分数/位次 + 考试科目检索可参考项目. Add one concise province-default note and one material-upload reminder. Do not show version, mode names, validation status, install/success messages, script names, internal policy rules, report directories, candidate lists, rankings, tables, or source-link instructions on the startup page. Never write 已成功启动、安装完成、验证结果、必需文件完整、包结构有效、Skill 功能概览、如何使用, or README-style example prompts. The startup page must call the province field 所在省份, never 目标省份; if omitted, default to the Chinese partner university's province/municipality. Run `startup-check` on any saved startup sample.


Final-delivery action for every Function 1/2/3 run:
1. Save the complete report as Markdown.
2. Convert that Markdown/HTML content into a PDF with readable, auto-wrapping layout.
3. Run `pdf-delivery-check` and `completion-gate-check` on the final answer text.
4. The last visible part of the user response must contain a PDF download link.
5. If the check fails, do not deliver; regenerate the PDF and revise the final answer until the PDF link is present.

Response/PDF contract: for functions 1/2/3, automatically generate a PDF unless the user explicitly asks not to. The order is mandatory: first provide a complete direct chat answer that contains the real conclusion, key fact table, admission-reference table, curriculum/course source table, course explanation, major-industry-AI table, employment/further-study/overseas-study/recommendation-for-postgraduate-study table, competitor map, family-fit/not-fit profile, qualitative sorting and public-discussion synthesis; then generate the PDF from the same facts; then provide visible PDF/Markdown links in the same response. The PDF is a saved/readable version, not the place where key information is hidden. The PDF must not omit tables, professional profile, major-industry-AI analysis, competitor references or public-discussion content already given in the direct answer. PDF delivery is mandatory: a final answer without a clickable PDF download link is incomplete. Do not ask the user to continue/追加生成 PDF, do not say “稍后生成 PDF/见 PDF”, and do not treat Markdown-only fallback as completion; if conversion fails, retry with another available PDF path before final delivery.

Ranking contract: `data/rankings_local_compact.json` is only a matching/lookup aid. Any QS/软科 ranking number shown to the user must be verified against an opened official QS/软科 page, official ranking table, or authoritative original source link. Use safe alias matching for QS; for 软科专业排名, always state mapping status and source link. If no official/authoritative link opens and matches the content, do not show the ranking as a verified fact.

Every text reply under this skill, including direct chat answer, Markdown report, PDF and attachment note, must start with this disclaimer as the first non-empty line, exactly as written:

> 重要声明：CoopLens Skill产出的内容由AI 生成，真实性需要使用者自行核实，不代表任何官方意见，不能作为任何决策依据或参考。

Do not add a longer disclaimer elsewhere. Do not over-list project names. The report should reveal admission-threshold, cost, certificate, curriculum/course, employer-recognition, competing-option and hidden-pain issues that ordinary official summaries miss.

Parent-pain order contract: organize function 1 and function 3 in this order unless the user explicitly asks otherwise: **能不能考上 → 文凭认不认 → 要花多少钱 → 出不出国 → 专业所在行业还值不值得读 → 未来四年怎么走 → 同省同分段备选 → 核对提醒 → 公开讨论**. Do not start with long background, ranking paragraphs or internal evidence taxonomy.

Function 2 comparison-order contract: for multi-project comparison, use the dedicated decision flow: **先给排序结论 → 能不能上（分数位次） → 花多少钱（全成本） → 文凭硬不硬（认可度） → 出路好不好（就业升学） → 专业所在行业好不好（行业与AI影响） → 孩子能不能读（培养难度） → 哪些事项要确认（待核对点） → 适不适合自家 → 怎么核实 → 最终建议**. The direct answer and PDF/Markdown must follow the same 11-chapter structure.

Mandatory four-path contract: every function 1/2/3 report must include a visible module titled “未来四年：考研、出国、保研、就业四条路怎么准备” or equivalent parent-facing title. It must give 大一/大二/大三/大四 actions, maximum risks, parent watchpoints, and school questions for 保研/推免、国内考研、出国/境申硕、就业. This module is separate from the data module “就业、升学、出国和保研情况”.

Direct-answer style requirements:

- Write like a knowledgeable friend helping parents compare choices. Use short paragraphs and practical wording.
- Do not write “本报告按功能3处理”, “候选来源与核验边界”, “proxy”, “unresolved”, “verified”, “结构化抽取”, “本地索引”, “召回” or similar internal terms in the user-facing answer/PDF.
- Do not use placeholders such as “待填”, “TBD”, “暂无所以略”, “见 PDF”, “PDF里有详细内容”, or empty sections.
- If data is missing, say plainly: “这项还没查到可打开且内容对应的官方/权威原文，需要继续向招生办/学院要材料确认。” Do not use local index values as substitutes and do not ask the user to perform the web verification for us.
- Curriculum/course information is mandatory. If the full official training plan is unavailable, use official brochure/project-page/foreign-course-page disclosed courses or modules; do not invent courses.
- 专业与行业前景分析 is mandatory for function 1 and function 2. Do not replace it with a generic “专业介绍” or a list of job titles; it must cover industry scale, prosperity/cycle, leading-company performance, AI impact, hiring impact and concrete student response.
- Do not treat first-year/first-intake admission as good, bad, risky, advantageous or a sorting factor. It only means there is no direct historical score line, so comparable samples are needed. If the conclusion is “观察” or “慎选”, the reason must be substantive: tuition/certificate/overseas requirement/curriculum/professional fit/budget/implementation conditions, not first intake itself.
- If the target project has no direct historical line, first search and display same-school existing international/cooperative pathways: CRS cooperative projects, 中外学分互认, 国际本科学术互认, 联合培养, 双学位, 学分互认. Label the exact type; do not mix them. For Jiangxi Normal University cases, explicitly check 2025 计算机科学与技术（中外学分互认） and 人工智能（中外学分互认） before relying on ordinary computer/AI lines.

Direct-answer minimum content blocks, in parent-pain order:

1. one-line conclusion and family-fit / not-fit type;
2. admission threshold and rank-space table with same-school international/cooperative samples before ordinary samples when there is no direct historical line;
3. ordinary-vs-cooperative/international rank-gap reference when applicable;
4. certificate and recognition table: domestic diploma/degree, foreign degree, unified-admission identity, graduate-school/civil-service/employer recognition questions;
5. fee table: annual tuition, dorm, possible textbook/language/overseas-stage costs, four-year total estimate;
6. study mode and curriculum/course source table plus course explanation;
7. major-industry-AI analysis table: 专业所属行业、行业规模、景气程度、龙头企业业绩、人工智能对行业的影响、行业员工招聘的影响、学生如何应对;
8. future four-path plan table: recommendation-for-postgraduate-study, domestic postgraduate entrance exam, overseas/border-region master application, employment;
9. employment/further-study/overseas-study/recommendation-for-postgraduate-study data table;
10. similar alternatives and competitor map, with formal competitors limited to target-province alternatives from other schools;
11. application pitfall checklist: questions to ask admissions office/college;
12. anonymous public discussion synthesis and PDF/Markdown links.

PDF style requirements:

- Build a readable report, not a dense database export. Prefer Markdown/HTML-to-PDF style with conclusion cards, clear headings, enough whitespace, and short tables.
- Large tables must be split or rendered horizontally; no cramped A4 tables.
- The first page must contain a conclusion card.
- Tables should use parent-facing labels, not internal status codes.
- Function 1 PDFs must visibly include the anonymous public discussion synthesis table.
- Every PDF must visibly include the curriculum/course source table, course explanation table, and 专业与行业前景分析 table.
- Every PDF table row that contains data must include clickable source links, not text-only source names.
- Every PDF numeric data value must keep the `约` prefix after rendering.
- Competitor/reference sections must include score/rank tables when data is available.

Forbidden in final reports:

- project scoring, numeric ratings, star ratings, recommendation indices;
- “今年预计 X 分 / 今年预计 X 位次” unless it is already official current-year data;
- public platform names, usernames, post titles, raw comments or screenshots;
- blunt value phrases such as “用钱换平台” or “低分买名校”.

Allowed: official Gaokao score lines, ranks and plan counts as evidence; qualitative sorting and ordinal ranking such as 第 1 / 第 2.

## 1. One-line decision and family-fit type

Prompt:

> Decide whether this project is a priority candidate, backup candidate, observation candidate, or cautious candidate under a higher-budget cooperative-route logic. State what the family can realistically obtain: domestic school name, city, major, foreign degree, domestic employment recognition, or unresolved uncertainty. If tuition/certificates/admission status are unverified, do not make a value claim.

Required:

- concise decision;
- target family type;
- one main reason to keep it and one boundary to verify;
- no scoring.

## 2. Target province and time basis

Prompt:

> Determine 所在省份. If the user gave a province, use it. If not, default to the Chinese partner's province/municipality, not the project campus city unless the user says so. Use the current date to judge whether this year’s admission result is already official; if not, use only the latest 1–2 completed admission years.

Required subquestions:

1. What province is being used, and why?
2. What is the current admission-year status?
3. Which completed years are used as evidence?
4. If the user’s real province differs, what must be recalculated?

## 3. Admission-threshold ladder and same-province references

Prompt:

> Build an admission-threshold evidence ladder: direct project line → same-school existing international/cooperative pathway line (CRS cooperative project / 中外学分互认 / 国际互认 / 联合培养 / 双学位 / 学分互认) → same-school similar ordinary major line → formal same-province competitor cooperative samples from other schools → same-province ordinary similar-major samples → same-province same-tier ordinary-vs-cooperative rank-gap samples. Compare relative level only. Do not predict current-year exact ranks.

Required table columns when possible:

- 年份
- 省份
- 科类/选科
- 批次/专业组
- 学校/项目
- 类型：本项目直连 / 同校中外合作 / 同校中外学分互认或国际互认 / 同校联合培养或双学位 / 同校普通相近专业 / 同省竞品中外合作 / 同省普通相近专业 / 可比省份样本
- 专业
- 计划数
- 最低分
- 最低位次
- 和目标项目的关系：更靠前 / 接近 / 更靠后 / 不可比 / 暂未查到
- 数据说明
- 来源
- 家长怎么理解

Hard rule:

- If the same Chinese school has both a cooperative sample and an ordinary similar-major sample, list them as two separate rows. Do not merge them into prose.
- For several schools, use one unified table, not separate mini paragraphs.
- If a project has no direct historical line because it is a first-year/first-intake admission project, write that only as a data limitation, not as a risk/advantage/sorting reason.
- When there is no direct historical line, do not jump directly to ordinary majors. Check same-school existing international/cooperative pathways first. If none are found, explicitly say none were found.
- If a same-school 中外学分互认 or 国际互认 sample exists, label it as that exact type and do not call it a CRS cooperative program.

Preferred wording:

- “该项目没有历史分数线。可比样本只能说明过去一两年的相对位置，不能直接等同于该项目当年结果。”
- “现有数据未体现明显录取门槛差异。”
- “与同校普通招生相比，该项目过去数据呈现一定/明显/不明显的位次空间。”

Forbidden wording:

- “预计低 X 分” without official current-year results.
- “中外合作一定降分”.
- “今年预计第 X 位”.

## 4. Local QS/软科 rankings

Prompt:

> Query the local ranking database for safe matching, then attach the official QS/软科 page or authoritative original source link before writing rankings in the user-facing answer. For QS, match the foreign university through official English name or curated alias map; if not safely matched, write that the local ranking DB did not safely match. For 软科, separate Chinese school main ranking, cooperative-university ranking, and major ranking; if a major rank is only a suggested mapping, do not present it as exact. Display rank, year, ranking name and source link, not raw score.

Required:

- foreign QS status;
- Chinese partner 软科 status;
- major 软科 status and mapping confidence;
- parent-facing meaning;
- caveat.

## 4A. Official data source and acquisition method — reusable

Prompt:

> For every key official data type, use the shared source acquisition method from `source_methods.md`. Do not merely state a fact; record where it came from and how it was obtained. The final report may use concise source notes, but the analysis must keep the data lineage.

Required methods:

1. Project identity/certificates/admissions: CRS → Chinese university admissions office/charter/plan/fee notice → project college page → foreign university official page.
2. Curriculum/courses: official training plan first; if unavailable, official brochure/project page/foreign course page disclosed courses or modules are mandatory; do not invent courses.
3. QS: local ranking DB first; if latest verification is requested or local match is unsafe, use QS official TopUniversities annual World University Rankings page. Record edition year, official English name, rank/band, and whether it is main list or subject list.
4. 软科: local ranking DB first; if latest verification is requested or local match is unsafe, use official ShanghaiRanking pages. Separate Chinese university main ranking, cooperative-university ranking, and major ranking. Major mapping must be marked as exact, adjacent mapping, or not found.
5. Same-province score/rank/percentile band: provincial exam authority and school admissions systems first. If only score is official, use the same-year same-province same-subject official 一分一段表 to convert to a nearby rank band and mark it as converted, not school-published rank.

Required source table columns when useful:

- 数据项;
- 优先来源;
- 获取方法;
- 报告里怎么写;
- 查不到时怎么处理.

## 5. Domestic credential and unified-admission identity

Prompt:

> Verify whether the program is officially approved and included in unified Gaokao admissions. Explain domestic graduation certificate, domestic degree, school name, major name, college name, Xuexin/official-record implications, and whether documents may reveal cooperative status. This module is more important than overseas narratives unless the user says otherwise.

Required:

- CRS/official identity;
- domestic certificate wording if verified;
- foreign degree name and conditions if verified;
- unified admission/professional group implications;
- unresolved questions.

## 6. Fees and family-input boundary

Prompt:

> Verify domestic tuition, accommodation, compulsory overseas/visit costs, optional exchange costs, and four-year total cost. Compare cost with platform, certificate, major and admission-threshold signals. Avoid blunt value phrasing. Write what the confirmed family input corresponds to, and what must be true for the choice to make sense.

Forbidden:

- “每降低一分多少钱”; 
- “花的钱买到了什么”; 
- “用钱弥补分数”.

## 7. Study mode and major learning

Prompt:

> Explain 4+0/3+1/2+2, domestic/overseas years, English/bilingual teaching pressure, foreign partner teaching share, project-based learning, lab/internship practice. Mention first-year admission only as a data-availability background. Do not use it as an advantage, disadvantage, risk rank, or overall sorting factor unless an official fact such as certificate, plan, or compulsory overseas year is actually unclear.

## 8. 培养方案与课程：必须出现

Prompt:

> Explain the major in plain Chinese and include a curriculum/course module in every report. The first choice is the official current-year training plan. If the full official training plan is unavailable, use the official admissions brochure, project website or foreign course page to list the disclosed courses or course modules. Do not invent course lists from general major knowledge.

Required content:

- 专业白话解释；
- 培养方案/课程来源说明；
- 大学主要课程或课程模块；
- 高中能力要求；
- 学习难点；
- 常见误解；
- 本科毕业岗位；
- 考研方向；
- 适合孩子画像；
- 劝退画像。

Required table 1 — 培养方案/课程来源表:

- 来源类型：官方培养方案 / 招生宣传册 / 项目官网 / 外方课程页 / 还没查到；
- 文件或页面名称；
- 年份/适用年级；
- 能说明什么；
- 不能说明什么；
- 下一步要问谁确认。

Required table 2 — 课程白话解释表:

- 课程/模块名称；
- 来源；
- 家长白话解释；
- 高中能力要求；
- 学习难点；
- 对就业/读研的关系；
- 需要确认的问题。

Fallback wording:

> 未核到当年官方培养方案全文；现阶段只能根据官方招生宣传中已披露的课程模块/培养方向解释，具体课程以学校后续公布为准。

Hard rules:

- If a brochure or official project page discloses courses/modules, include them even without a full training plan.
- If the brochure only discloses broad modules, list those modules and state that they are not a full course plan.
- If no official course information is found, do not create a generic course list. State plainly that the course list must be requested from the college.

## 8A. Major, industry, AI and hiring impact analysis — mandatory for function 1 and function 2

Prompt:

> Add a parent-facing module titled “专业与行业前景分析：这个专业未来还能不能走远” or similar. Translate the major into real industry/sub-industry directions, then use current official/authoritative sources to analyze industry scale, prosperity/cycle signals, leading-company performance, AI impact, hiring impact, and student response. The horizon is not just today’s job market: focus on roughly 4–8 years after enrollment, when the student graduates and enters early career. This module must appear in direct chat answer, Markdown and PDF.

Required visible table in both direct answer and PDF:

- 专业/项目；
- 专业所属行业 / 子行业；
- 行业规模：source-linked approximate numeric value or “公开权威数据暂未核到”；
- 景气程度：expanding / recovering / diverging / cyclical / structural adjustment, with evidence;
- 龙头企业业绩：2–4 representative companies, latest revenue/profit/R&D/business change when publicly available;
- 人工智能对行业的影响：tasks replaced, tasks enhanced, productivity/human-efficiency changes, new roles and entry-level threshold changes;
- 约4–8年就业展望：未来人才需求是扩张、收缩、分化还是结构升级；哪些本科入门岗位可能被压缩，哪些复合能力岗位可能增加；
- 行业员工招聘的影响：campus hiring/JD/skill/headcount signals and whether hiring demand is likely to become more selective;
- 学生如何应对：year-by-year or ability-by-ability actions that improve employability at graduation and early career;
- 来源链接：clickable original sources.

Source priority:

1. Official statistics and regulators: 国家统计局、工信部、国家发改委、行业主管部门、行业协会、信通院 and equivalent official/authoritative bodies;
2. Listed-company/leading-company sources: annual reports, interim reports, quarterly reports, investor-relations pages, exchange filings, official earnings releases;
3. Hiring sources: company campus-recruitment pages, official job descriptions, career pages, school employment quality reports; recruitment-platform annual reports only as trend signals, not project-level facts;
4. AI impact sources: official/authoritative AI policy reports, industry white papers, company filings that describe automation, AI products, R&D direction, productivity, human-efficiency or workforce changes.
5. Future-demand sources: government/industry talent plans, digital-economy/industry development plans, enterprise campus hiring pages, annual-report workforce discussion, R&D headcount, capital-expenditure plans and credible longitudinal employment reports.

Rules:

- Every industry-scale, revenue, profit, growth, headcount or recruitment number must display with `约` and the number itself must be a hyperlink.
- Do not claim “AI will replace this major” or “AI has no impact” without evidence; describe task-level changes, productivity effects, and how students can respond.
- Separate current hiring signals from future talent demand. Use language such as “未来约4–8年可能更看重……”, “入门岗位可能更少但高质量岗位更看重……”, or “行业需求可能从人数扩张转为能力升级”; avoid deterministic predictions.
- Do not equate one leading company’s performance with the whole industry; say it is a thermometer, not the whole map.
- If no authoritative industry data is found, state that plainly and keep the analysis to verified curriculum/employer/JD signals plus questions to verify.

## 8B. Employment rate, further-study rate, overseas-study rate, and recommendation-for-postgraduate-study status

Prompt:

> For every function 1/2/3 report, check the project/major, joint college, Chinese university, similar ordinary major/college, and foreign university official sources for employment rate, further-study rate, overseas or border-region further-study rate, and recommendation-for-postgraduate-study status. Do not call this module “毕业出口”, “出口数据”, or “出口透明度”. Use the parent-facing Chinese title “就业、升学、出国和保研情况”. If project-level data is absent, say so plainly and show the nearest available official data level. Do not rank these rates in multi-project reports.

Source priority:

1. Target project / target major official data.
2. Joint institute / project college data.
3. Chinese university undergraduate employment quality annual report, further-study destination, overseas or border-region study destination.
4. Similar ordinary major or similar college at the same Chinese university.
5. Foreign university official graduate outcomes, only as background and never as a direct proxy for the China-based project.
6. Admissions office, college, career office, or academic affairs questions to verify.

Required visible table in both direct answer and PDF:

- 数据项：就业率 / 升学率或深造率 / 出国或国（境）外升学率 / 保研或推免情况;
- 项目级数据：查到的数值或“项目级未公开/暂无毕业生/还没查到公开官方数据”;
- 可参考的学校或学院背景数据：only if clearly labeled;
- 数据层级：项目级 / 专业级 / 学院级 / 学校级 / 相近普通专业 / 外方背景;
- 这条数据不能说明什么;
- 家长要问谁、问什么。

Rules:

- Missing data is not a disadvantage by itself; it is a question to verify.
- Do not invent rates.
- Do not convert university-level rates into project-level rates.
- Do not sort or rank these rates. For function 2/3, show a side-by-side table only.
- Keep this module separate from domestic employer recognition. Employment rate/further-study data is official or semi-official outcome information; employer recognition is about hiring filters and resume perception.

## 8C. Future four-path planning — mandatory

Prompt:

> Add a parent-facing module titled “未来四年：考研、出国、保研、就业四条路怎么准备”. This is not an outcome-rate table; it is an action plan. For each path, explain what the student should do in 大一、大二、大三、大四, the biggest risk, what parents should watch, and what must be confirmed with the school. Tailor the plan to the actual major and cooperative-study mode.

Required visible table in both direct answer and PDF:

- 路径：保研/推免、国内考研、出国/境申硕、就业；
- 大一重点；
- 大二重点；
- 大三重点；
- 大四重点；
- 主要不确定项；
- 家长要盯什么；
- 需要向学校确认的问题。

For computer/AI/data/software/electronic-information related majors, explicitly cover:

- GPA and ranking from year 1;
- math, English and programming fundamentals;
- algorithm, database, system, data and project abilities;
- research/competition/project portfolio;
- internships and resume evidence;
- how foreign courses, English-taught courses, GPA conversion and foreign transcripts may affect postgraduate, overseas and employment paths.

Rules:

- Do not imply postgraduate recommendation eligibility unless official recommendation rules support it.
- Do not imply overseas admission advantage merely because a foreign partner exists; tie it to GPA, language score, transcript, degree and project evidence.
- Do not write a generic four-year plan that ignores major, study mode or certificate conditions.
- Do not let this module replace the required official data table for employment/further-study/overseas-study/recommendation-for-postgraduate-study.

## 9. Domestic employer recognition

Prompt:

> Search public recruitment signals and public discussion about whether large domestic employers recognize this type of cooperative background. Cover big tech, finance, manufacturing, state-owned enterprises, research institutes, civil-service/graduate-school constraints only when relevant. Summarize hard evidence separately from anonymous discussion.

Subsections:

1. Hard gate: public job requirements, education level, major, school tier, explicit exclusions if any.
2. Resume presentation: how the domestic school/major/cooperative college may appear.
3. Recognition debate: aggregated positive/negative/rebuttal themes from public discussion, without platform names or identities.
4. Practical hedge: internships, projects, contests, research, English ability, transcript and certificate preparation.
5. Questions to verify with admissions office/career office.

## 10. Anonymous community reputation and hidden pain points

Prompt:

> Search public online discussions, news comments, career discussions, and Q&A about the project, Chinese partner, foreign partner, major, study mode, domestic credentials, employer recognition, certificates, visa/exit issues, and cost. Summarize only aggregated themes. Include positive views, negative concerns, and rebuttals. Do not mention platform names, usernames, post titles, direct quotes, screenshots, or identifiable stories. Do not treat public comments as official facts.

Output as a visible parent-facing table in both direct answer and PDF for function 1/2/3:

- 公开讨论里常见看法；
- 家长该怎么理解；
- 需要官方确认的问题；
- 信号强弱：反复出现 / 有一些讨论 / 样本很少。

Cover positive themes, negative concerns, rebuttals and clarifications, and official questions. Do not name platforms. Do not hide this module in PDF, especially for function 1.

## 11. Similar alternatives and competitor map — mandatory for single-project reports

Prompt:

> Build a competitor map. Recall candidates from the local index, then verify officially. Select 4–8 meaningful alternatives, not a long list. Each formal competitor must be another school/project that admits in the target province and must have a comparison role plus target-province admission-position reference from the latest 1–2 completed years when available. Out-of-province data may only be listed as comparable samples, not competitors. Compare relative high/low, not current-year exact predictions.

Required competitor roles:

1. 同类平台 + 同类外方 + 类似专业;
2. 更高中方平台 + 专业略弱或不完全贴合;
3. 略低中方平台 + 更贴近/更强专业;
4. 投入更低 + 平台稍低但专业可接受;
5. 投入更高 + 平台/城市/证书更清楚;
6. 同省普通招生相近专业 as non-cooperative reference.

Required output tables:

1. 竞品坐标总表
   - 角色
   - 项目/学校与专业
   - 省份
   - 中方平台相对位置
   - 外方/合作方相对位置
   - 专业贴合度
   - 费用边界
   - 培养模式
   - 证书清晰度
   - 相对排序：优先 / 备选 / 观察 / 慎选
   - 为什么值得或不值得放入候选池

2. 录取位置参照表
   - 项目/学校
   - 类型：本项目直连 / 同校中外合作 / 同校中外学分互认或国际互认 / 同校联合培养或双学位 / 同校普通相近专业 / 同省竞品中外合作 / 同省普通相近专业 / 可比省份样本
   - 专业
   - 省份
   - 年份
   - 最低分
   - 最低位次
   - 数据口径
   - 和目标项目的关系：更靠前 / 接近 / 更靠后 / 暂未查到

Rules:

- Do not predict current-year exact score/rank. You may report a historical rough range for ordinary-vs-cooperative rank gap when there are enough same-province same-tier samples.
- Do not score projects numerically.
- Do not show internal labels such as `proxy_score_only`; use parent-facing wording such as “只是参照样本，不能等同于目标项目”.
- The same school’s cooperative / 中外学分互认 / 国际互认 / 联合培养 line and ordinary similar-major line must be listed separately when available.
- Formal competitors must be target-province alternatives from other schools. Same-school rows are reference anchors, not competitors. Out-of-province rows belong in a comparable-sample table.


## 11A. Ordinary vs cooperative/international rank-gap reference — required when applicable

Prompt:

> If the target has a Chinese university that also has ordinary undergraduate admissions in the target province, estimate a rough historical rank-space reference between ordinary admissions and cooperative/international-path admissions. This is not a current-year exact prediction. If there is no Chinese ordinary-admission baseline, such as 香港中文大学（深圳）, 香港科技大学（广州）, 上海纽约大学, 昆山杜克大学 and similar institutions, state that this method is not applicable.

Sampling rules:

1. Same school first: collect the Chinese partner’s ordinary similar-major/group rank and its cooperative / 中外学分互认 / 国际互认 / 联合培养 rank in the same target province and completed year.
2. Same province same tier next: collect other target-province schools that are similar by 软科 main ranking band and by C9 / 985 / 211 / 双一流 / 双非 / public-private status.
3. The ordinary major and cooperative major do not have to be the exact same major, but if they differ, label the sample as “非同专业，只作学校层面历史位次空间样本”.
4. Try for at least 5 pairs. If fewer than 3 pairs exist, call it a weak reference and do not form a stable range; do not exclude a first-intake candidate solely for that reason if hard facts are otherwise clear.
5. Output median/common range/min-max/outliers if useful, but do not write “今年预计第 X 位”.

Required rank-gap table columns:

- 学校;
- 层次标签;
- 软科层次或排名附近;
- 年份;
- 省份;
- 普通招生专业/组;
- 普通招生最低位次;
- 中外/国际路径专业/组;
- 中外/国际路径最低位次;
- 位次差;
- 是否同专业;
- 样本作用.

A→B transfer for first-intake function-3 candidates:

- B = the target first-intake/newly approved project’s Chinese university.
- B ordinary baseline = B university’s same-province ordinary similar-major/group rank in the latest completed year.
- A samples = same-province same-tier universities with ordinary and cooperative/international-path ranks.
- B rough reference range = B ordinary baseline + the common range of A ordinary-vs-cooperative rank gaps.
- Use this range to decide whether the first-intake candidate can be 优先关注 / 可作为备选 / 需要观察 / 暂不建议. Do not default to observation just because it is first intake.
- Never show only a single inferred score/rank/range or only a sorting conclusion for a no-history candidate. Show the complete 推测依据 chain: no-history status, B 普通招生基线, A 同省同档样本, sample count and sample strength/weakness, formula, B 粗略参照范围, user-rank relationship, and “不是今年录取预测”.
- Every numeric datum in this basis must be clickable itself: `[约X](source-url)`. If a datum is calculated, link the displayed calculated value to the input-source row and state the formula in the same row. Missing basis: `【未满足：无历史线推测依据不完整】`. Missing direct numeric source link: `【未满足：推测依据数据缺少链接】`.

Preferred wording:

> 这不是在预测今年分数线，而是在看同省同档学校过去“普通招生”和“中外/国际路径招生”之间通常差了多少位次。它只能作为历史参照区间，不能等同于目标项目当年录取结果。首次招生项目不能因为没有本项目历史线被回避；如果官方硬条件清楚，就要用这个参照范围判断是否值得推荐。

## 12. Multi-project comparison 11-chapter decision report — mandatory for function 2

Prompt:

> For multiple projects, write as a parent decision report, not as a database comparison. First give the order, then help the family test admission feasibility, total cost, certificate recognition, outcomes, future major/industry employment outlook, academic difficulty, risks, fit, verification actions and final choice. Function 2 is incomplete if it omits the dedicated future-employment comparison chapter. Do not use points, percentages, stars, weighted scores or recommendation indices.

Function 2 report structure must use these 11 chapters in both direct answer and PDF/Markdown: Missing chapter 6 is a hard failure for Function 2; do not merge it into current outcome-rate comparison.

1. **第 1 章 对比结论与优先级排序（开篇直接给答案）**
   - 综合优先级总排序;
   - 不同家庭目标下的最优选择：国内就业优先 / 出国深造优先 / 性价比优先;
   - 一句话核心优劣势速览.
2. **第 2 章 录取门槛对比：你家孩子能不能上**
   - 近 3 年本省录取最低分 / 最低位次对比表;
   - 同校普通专业 vs 中外合作的分差 / 位次差;
   - 选科要求、招生计划数;
   - 首招 / 新获批项目的分数参照依据. First-intake status is only a data state, never a risk/advantage/sorting reason.
3. **第 3 章 全成本对比：四年到底要花多少钱**
   - Domestic annual tuition, dorm, four-year tuition;
   - Overseas-stage fees for 2+2/3+1/1+3: tuition, living cost, insurance, visa, flights, language tests, registration, textbook and other necessary fees;
   - Hidden-cost scan;
   - Separate total estimates for 4+0 domestic-only and overseas-stage scenarios.
4. **第 4 章 文凭与认可度对比：毕业证到底硬不硬**
   - Chinese diploma/degree, foreign degree details;
   - Whether diploma/degree/transcript/Xuexin information marks 中外合作办学 or 联合学院;
   - Recommendation-for-postgraduate-study eligibility and whether it is equal to ordinary majors;
   - Civil service, selected graduates, SOE/central-SOE and public-institution restrictions;
   - Foreign degree CSCSE/Ministry/CRS filing status.
5. **第 5 章 毕业去向对比：花了钱，出路怎么样**
   - Employment rate, further-study rate, overseas/border-region further-study rate;
   - Overseas application destination level, domestic further-study destinations, main industries and employer types;
   - For new/no-graduate projects: mark 暂无毕业生数据 and use same-school/same-type/college/school-level reference only, never as project-level fact;
   - These rates are displayed side-by-side, not ranked.
6. **第 6 章 专业与行业前景对比：这个专业未来还能不能吃饭**
   - Major-to-industry/sub-industry mapping for each project;
   - Industry scale, prosperity/cycle and structural signals;
   - 2–4 leading/representative companies' latest performance;
   - AI impact on tasks, productivity, roles, entry-level thresholds and new opportunities;
   - Future employment horizon: how the labor market may look around graduation and early career, roughly 4–8 years after enrollment;
   - Future talent demand: whether demand is likely to expand, shrink, diverge or structurally upgrade;
   - Hiring impact: campus hiring, JD, skills, headcount/R&D signals;
   - Student response: courses, projects, internships, portfolio, certifications, graduate-study direction and AI-tool ability.
7. **第 7 章 培养模式与学业难度对比：孩子能不能跟上**
   - 4+0/2+2/3+1/1+3 and whether overseas study is compulsory;
   - Foreign-course share, English-taught share, foreign-faculty share and delivery mode;
   - English/GPA requirements, retake/re-sit rules, academic pressure;
   - Transfer policy and exit mechanism;
   - Curriculum/source table from official training plan, brochure, project page or foreign handbook. Do not invent generic courses.
8. **第 8 章 待确认事项对比：这些问题请逐项核对**
   - Stability: CRS/Ministry filing, validity period, renewal, suspension/stop signals;
   - Overseas-failure risk and fallback plan;
   - Foreign university identity, official ranking and accreditation;
   - Policy risks: cooperative-education policy, visa, exit/entry, CSCSE, recruitment rules;
   - Risks must be verifiable; first-intake status itself is not a risk.
9. **第 9 章 适配人群对比：哪个更适合你家孩子**
   - Fit profile for project A/B/C;
   - Budget, rank, subject selection, English, math/programming, overseas willingness, employment city and further-study target;
   - Situations where none of the compared projects are recommended.
10. **第 10 章 招生办必核实问题清单**
   - 证书类 3 题;
   - 保研政策类 2 题;
   - 费用类 2 题;
   - 出国 / 培养类 3 题;
   - Each question must specify who to ask and what evidence to request.
11. **第 11 章 小屏总结**
   - Selection conclusions under different development targets;
   - Filling-order reminders, adjustment risk, budget reminders, and verification priority;
   - Final order without numeric scoring.

Required sorting. Use parent-facing titles such as “第 1 章 对比结论与优先级排序” or “各目标下怎么选”, not “家长该先看什么”.

1. 综合优先级总排序;
2. 国内就业优先 / 出国深造优先 / 性价比优先 best choice;
3. 录取位置相对高低排序;
4. 全成本压力排序;
5. 证书清晰与认可度排序;
6. 专业/行业景气与AI适应度排序;
7. 培养可承受度排序;
8. 待确认事项清晰度排序;
9. 适配人群排序;
10. 就业、升学、出国和保研情况总表：only side-by-side, never ranked;
11. 总体建议顺序.

Each order must explain why the first item is ahead and what caveat could reverse the order.

Function 2 authenticity rule:

- All factual information must come from official or authoritative sources: CRS/Ministry filing platform, provincial exam authority, school admissions charter, official admissions plan, official tuition notice, Chinese/foreign university pages, official curriculum/training plan/brochure, employment-quality report, postgraduate recommendation policy, CSCSE/Ministry filing and official recruitment requirements.
- Authoritative media may support policy/background facts or widely reported institutional changes, but cannot replace official admissions, certificate, tuition, score/rank, curriculum or postgraduate-recommendation evidence.
- Public online comments are the only exception: they may appear only as anonymous aggregated discussion signals and must never support official facts.
- Internally use a claim-ledger / source-triangulation process similar to research-literature fact checking, but never show claim_id, audit_status, verified, unresolved, proxy, retrieval scores or script output in the user-facing report.

## 13. Candidate retrieval sorting — mandatory for function 3

Prompt:

> For province/score/rank/subject retrieval, first recall candidates from local index and local rankings, then verify target-province plan, subject requirements, tuition, certificates and latest 1–2 completed-year admission positions. Include cooperative projects and ordinary-admission similar majors as references. Produce grouped candidates and a final order. Do not avoid first-intake or newly approved projects; use A→B same-tier ordinary-vs-cooperative rank-gap transfer to build an evidence-based rough historical reference when direct project lines do not exist.

Candidate groups:

- 优先关注;
- 可作为备选;
- 需要观察;
- 暂不建议.

First-intake handling for function 3:

- A first-intake/newly approved project that matches province, subjects, budget and major interest must enter the candidate comparison if target-province plan, certificate, tuition and study mode can be verified from official/authoritative sources.
- Do not place it in 需要观察 or 暂不建议 solely because it lacks its own historical line.
- Build B 普通招生基线 from the target Chinese university’s ordinary similar major/group in the same province.
- Build A 同档普通—中外位次差样本 from same-province same-tier universities: same C9/985/211/双一流/双非/public-private status and similar Softke ranking band when possible.
- Compute B 粗略参照范围 = B 普通招生基线 + A 位次差常见区间, then compare that range with the user’s rank. Every input number must have a source link.
- Fewer than 3 samples means weak reference, not automatic exclusion.

Required sorting:

- platform recognition;
- major fit;
- relative admission position;
- affordability pressure;
- certificate clarity;
- employer recognition;
- overall order.

Required reference tables for function 3:

- Target project and each alternative/reference project must show province, year, score/rank when publicly available.
- Same-school cooperative and ordinary similar-major rows must be split.
- Ordinary-admission similar majors in the same province should be included as a non-cooperative reference, not hidden in prose.
- For first-intake/newly approved/no-history candidates, include: 无历史线候选核验表（首次招生候选核验表）, B 普通招生基线表, A 同档普通—中外位次差样本表, B 粗略参照范围与适配表.
- Each table must make important numbers directly clickable and must not rely on a final source list only.

No numeric scoring may be displayed. No current-year exact score/rank prediction may be displayed.

## 14. Fit and discouraging profiles

Prompt:

> Write differentiated profiles using admission-threshold gap, family budget, domestic brand preference, English level, math/physics/programming foundation, desire for foreign degree, career path, and need for stable domestic pathways.

## 15. Parent question checklist

Prompt:

> Convert all unresolved risks into exact questions parents can ask admissions offices and career offices. Prioritize questions that can change the application decision: target-province plan, certificate wording, whether domestic degree is identical in effect, employment/career-office support, professional group and historical score-line口径, transfer policy, and official course plan, brochure course list, and foreign-course-page curriculum requirements.

## 16. Source authenticity and claim audit

Prompt:

> Use an internal claim-ledger approach similar to research-literature fact checking. Every high-impact factual claim must be backed by an official or authoritative source unless it is explicitly labeled as public discussion. Keep the audit mechanism internal. Do not expose claim_id, audit_status, retrieval score, source ledger, or script output in the user-facing report/PDF.

High-impact facts that require official or authoritative support:

1. CRS/project approval, program name, level, admission mode and certificate wording;
2. target-province plan, subject requirements, batch/group, score/rank and one-score-one-rank conversion;
3. tuition, dorm fee and overseas-stage fee conditions;
4. study mode, whether overseas study is compulsory, language/GPA/foreign-degree requirements;
5. curriculum/course list, training plan, brochure modules and foreign program structure;
6. industry scale, prosperity/cycle, leading-company performance, AI impact and hiring-impact claims used in 专业与行业前景分析;
7. employment rate, further-study rate, overseas/border-region further-study rate, recommendation-for-postgraduate-study policy;
8. QS/软科 ranking records;
9. competitor target-province admission status and historical score/rank.

Internal claim-ledger fields:

- claim_id;
- claim_text;
- claim_type;
- source_name;
- source_type: CRS / 招生章程 / 学校本科招生网 / 省考试院 / 一分一段表 / 培养方案 / 招生宣传册 / 外方官网 / 行业主管部门 / 行业协会 / 龙头企业年报 / 企业招聘公告 / 就业质量报告 / 推免办法 / 权威媒体 / 第三方线索 / 公开讨论;
- source_date_or_year;
- evidence_strength: 官方直接支持 / 官方间接支持 / 权威媒体线索 / 第三方线索待核 / 公开讨论信号;
- contradiction_check;
- user_facing_wording;
- next_verification_question.

Final report rule:

- The report may say “官方材料显示 / 学校章程显示 / 省考试院数据 / 项目级未公开 / 只是历史参照 / 只是公开讨论里的担心”.
- The report must not show claim_id, audit_status, verified, unresolved, proxy, internal evidence codes, source ledger table, or script output.
- Third-party score/rank summaries may be used as search leads only. If not verified by official province/school data, phrase as “第三方汇总线索，需以省考试院或学校招办复核”.
- Public discussion cannot support official facts. It only generates questions to verify.

## 17. Internal audit vocabulary and user-facing wording

Internal audit may use machine-readable labels, but final reports must translate them into plain Chinese.

Internal-only labels include:

- `verified`
- `partially_supported`
- `unresolved`
- `conflict`
- `community_signal_only`
- `employer_signal_only`
- `proxy_score_only`
- `direct_admission_line`
- `same_school_proxy`
- `same_tier_proxy`
- `ordinary_admission_reference`

User-facing replacements:

- 官方已确认
- 有官方材料支持，但还要核一处细节
- 还没查到公开官方信息，需要问学校
- 公开信息存在不一致
- 只是公开讨论里的担心，不能当事实
- 只是招聘/求职信号，不能代替官方证书说明
- 只是参照样本，不能等同于目标项目
- 本项目/本专业历史线
- 同校参照样本
- 同层次参照样本
- 普通招生相近专业参照

Final reports must not show internal retrieval scores or internal audit codes. Only qualitative sorting and ordinal order are allowed.

备注：公开讨论、新闻评论和求职反馈均不作为官方事实，只作为待核验的口碑信号和追问线索。


Legal-safe wording contract: never use “避坑清单”, “这些坑”, “有什么坑”, “坑点”, “风险点对比”, “野鸡大学”, “骗局”, “欺骗”, “虚假宣传”, or similar accusatory wording in user-facing answers, Markdown, or PDF. Use “核对提醒”, “待确认事项”, “需要向招生办/学院确认的问题”, and “公开资料尚未核到的内容”.

Function 3 current-year approval contract: every recommendation run must first acquire the runtime date through a tool, use the tool-returned current year to search Ministry of Education/CRS newly approved, newly announced, or recently reviewed cooperative institutions/projects, then check target-province招生计划/选科/学费/证书 from official school/provincial sources. Include a visible table/note for 当年新批准/新获批项目检索结果. Do not omit first-intake candidates just because they are absent from the local index or have no historical line. For first-intake/no-history candidates, if relative rank or admission position must be inferred, the report must show complete 推测依据 and direct source hyperlinks for every numeric datum.


## 多重确认机制提示

生成任何功能 1/2/3 报告前，先按以下顺序核验：

1. 零假设：AI 生成内容、搜索摘要、本地索引、第三方汇总均只作线索。
2. 打开原文：CRS、教育部、省考试院、学校招生章程、招生计划、收费公示、培养方案、就业质量报告、推免办法、外方官网、QS/软科官方等。
3. 三步匹配：来源存在、元信息一致、内容支持。
4. 双源交叉：高影响事实优先做到一级官方源 + 独立交叉源。
5. 冲突处理：公开材料冲突时，不裁决，只列明口径不一致并让家长向学校/省考试院确认。
6. 功能 3：每次必须先通过工具获取执行时日期，再检索工具返回当前年份的教育部/CRS 新批准、最新公布或最新复核项目，并与所在省招生计划交叉。



## 统一参考来源章节

每份功能 1/2/3 报告的最后一章必须是 `参考来源与核验说明`。正文各模块不要重复放“数据来源：/来源：/来源链接：”小节；表格里也不要为了来源额外扩成宽表。重要数字仍必须在数字本身上放链接。最后统一来源章节建议字段：来源编号、来源名称、可点击链接、来源类型、年份/发布时间、支持的数据或事实、核验边界/需要向学校确认的问题。若使用“数据来源：”字样，必须按红色提示规则输出；优先使用“参考来源与核验说明”作为标题。


Closing-disclaimer contract: for every Function 1/2/3 final chat answer, Markdown report and PDF-visible report text, the final non-empty line must be exactly:

> 重要声明：CoopLens Skill产出的内容由AI 生成，真实性需要使用者自行核实，不代表任何官方意见，不能作为任何决策依据或参考。

Do not end with “本报告所有数据均来自公开可查的网络信息，由AI整理生成”, “所有数据均来自公开可访问页面”, “所有信息均来自公开渠道”, “全部数据已核实”, “所有数据都有官方来源”, or similar blanket source guarantees. If such wording appears anywhere, regenerate the report before delivery instead of simply shipping a flawed report.

Blanket-source-claim ban: Do not write “所有数据均来自公开可访问页面”, “所有信息均来自公开渠道”, “全部数据已核实”, “所有数据都有官方来源”, “所有来源均已验证”, or similar absolute guarantees anywhere in direct chat, Markdown, or PDF. The final source section may only describe sources actually used in this run and the remaining boundaries to reconfirm.

Final executor/agent review contract: Before delivering any output, the current executor or agent should re-read the whole generated answer/report as a reviewer; this does not require an external language-model API call. If the output misses the fixed disclaimer, runtime date, full function structure, final consolidated sources, direct numeric hyperlinks, PDF link, 保研率/推免率 evidence, or contains any blanket source guarantee or PDF table-overlap risk, revise the output before sending. Do not show the internal review checklist unless asked.


## 1.0.12 final-review execution note

最终审核默认由当前执行器/智能体调度完成，不要求外部语言模型 API。Codex、豆包办公任务、ChatGPT 或其他可读写文件并运行脚本的平台都可以执行该审核；有 API 额度且使用者允许时，API 只作为可选补充审核，不作为默认路径或完成前提。


## 1.0.12 PDF 与链接最终硬闸门

- 功能 2/3 不得把多项目候选或同分段参考项目做成普通 4–5 列 Markdown 宽表后直接转 PDF；必须拆表或卡片化。
- PDF 生成后必须做视觉渲染复核；若出现文字重叠、裁切或链接覆盖，必须重新生成。
- 关键数据链接必须最终打开并确认内容支持对应数字。若打不开或内容不支持，删除该数字或写“未核到可打开且内容对应的官方/权威原文”。

## 1.0.12 Function 2 card-only PDF module

When writing Function 2, output comparison content as cards rather than Markdown tables. Use this style:

### 第 1 位：项目名称
- 定位：...
- 2025 年录取：`[约xxx分 / 约xxx位](source)`
- 学费：`[约x万元/年](source)`
- QS/软科：`[约第x位](source)`
- 主要理由：...
- 需要核对：...

Do not use pipe tables for ranking, fee comparison, certificate comparison, QS ranking comparison, employment/further-study comparison, or final source list. If a generated Function 2 draft contains any body pipe table, regenerate into cards before creating PDF.


## 1.0.12 HTML/PDF 交付与防截断硬规则

- HTML 强制交付硬规则：功能 1/2/3 完成时必须同时交付 Markdown、HTML、PDF 三件套；同一轮回答必须有可点击 PDF 下载链接、HTML 可视化报告链接和 Markdown 报告链接。运行 `python scripts/cooplens_core.py artifact-delivery-check <final-answer.md>`、`html-delivery-check`、`pdf-delivery-check`，任一失败都必须重新生成。
- HTML 不使用固定内容模板：HTML 必须从同一份 Markdown 生成，只能把 Markdown 的标题、段落、列表、链接、卡片化结构转成 HTML 标签并加 CSS；不能在 HTML 中新增项目、说明、统计、标题、图片、页脚口号、示例内容或任何 Markdown/PDF 没有的可见文字。
- HTML 与 Markdown/PDF 内容一致性：HTML、Markdown、PDF 的章节顺序、正文、关键数据、链接、核验边界、免责声明必须保持一致。运行 `python scripts/cooplens_core.py html-consistency-check <report.md> <report.html>`；发现 HTML 与 Markdown/PDF 内容不一致，标记 `【未满足：HTML与Markdown/PDF内容不一致或添加了额外内容】` 并重新生成。
- 不得增加图片：HTML 报告不得新增 `<img>`、SVG、canvas、iframe、外部图片、背景图片、图标库或脚本。视觉效果只能来自 CSS 的色彩、留白、边框、阴影、卡片、标签、时间线和响应式布局；不能添加其他图片。
- 色彩与布局提示词：HTML 可参考现代前端报告页的轻量风格，但只作为样式层使用。建议使用浅色背景、白色卡片、圆角、轻微阴影、蓝紫/青绿/琥珀等少量强调色、清晰标题层级、项目卡片、来源卡片、提示框、宽松行距、可打印 CSS；不得改变内容。
- PDF 文本防截断硬规则：PDF 不能出现文本截断、同一行被裁剪、免责声明被切掉、表格单元格文字叠加。Markdown/HTML 转 PDF 时必须设置 `overflow-wrap:anywhere`、`word-break:break-word`、`line-break:anywhere`、`white-space:normal`、`hyphens:auto`、`height:auto`、`max-width:100%`，并禁止 `white-space:nowrap`、`overflow:hidden`、固定高度和固定行高。
- 每行固定字数上限：面向 PDF 的可见段落建议约 32-38 个中文字符后自然换行；免责声明、来源 URL、长项目名、长专业名、长数值解释必须允许自动换行。执行 `python scripts/cooplens_core.py pdf-text-wrap-check <report.md-or-html>`；出现 `【未满足：PDF存在文本截断/换行风险，必须重新生成】` 时必须重排。
- PDF 必须优先从已通过 `html-report-check` 的 HTML 导出，而不是直接把 Markdown 宽表转 PDF。HTML/PDF 中仍不得使用 Function 2/3 宽表，候选项目、费用、位次、证书、课程、来源均优先使用卡片或窄列表。
- 产物交付前必须依次运行：`html-report-check <report.html>`、`html-consistency-check <report.md> <report.html>`、`pdf-text-wrap-check <report.html>`、`pdf-visual-layout-check <report.pdf>`、`pdf-key-data-link-check <report.pdf>`、`completion-gate-check <final-answer.md>`。任何一步失败都必须重新生成 Markdown/HTML/PDF 三件套。


兼容校验短语：Markdown、PDF、HTML 三件套；从同一份 Markdown 生成 HTML；内容严格一致；不能添加额外内容；视觉样式只能来自 CSS；免责声明可视化换行；CJK line breaking；不得截断文本；发现截断必须重新生成。
