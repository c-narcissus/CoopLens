# CoopLens 1.0.12 Output Schema


## Global report contract

```json
{
  "first_non_empty_line_required": "重要声明：CoopLens Skill产出的内容由AI 生成，真实性需要使用者自行核实，不代表任何官方意见，不能作为任何决策依据或参考。",
  "applies_to": ["direct_chat_answer", "markdown_report", "pdf_report"],
  "local_indexes_are_sources": false,
  "source_rule": "Important numeric indicators must be clickable source anchors in the body; non-numeric source details are consolidated in the final 参考来源与核验说明 section with clickable opened source links and content-match boundaries. Text-only source names are invalid.",
  "numeric_link_rule": "Every important numeric indicator must itself be the clickable source anchor in Markdown/PDF, e.g. [约589分](https://...) or <a href=\"https://...\">约589分</a>; if not satisfied, mark as 【未满足：数字未直接链接来源】.",
  "approximate_value_rule": "All user-facing numeric data values in direct chat, Markdown and PDF must display with 约 before the value, e.g. 约589分, 约第133名, 约30%, 约4.8万元/年. Internal source matching keeps exact original values.",
  "runtime_date_rule": "Before analysis, acquire current date/time through an available tool, record runtime_context, and display 检索执行日期 immediately after the fixed disclaimer in direct chat, Markdown and PDF.",
  "major_industry_ai_rule": "Function 1 and Function 2 must include 专业与行业前景分析 covering 专业所属行业、行业规模、景气程度、龙头企业业绩、人工智能对行业的影响、AI productivity impact、约4–8年后未来人才需求、行业员工招聘的影响、学生如何应对; all numbers follow 约 and numeric-self-link rules.",
  "function2_eleven_chapter_rule": "Function 2 must use the 11-chapter comparison structure; chapter 6 must be 专业与行业前景对比 and compare the future employment outlook of each project around 4–8 years after enrollment. Current outcome rates alone do not satisfy this rule.",
  "blanket_source_claim_rule": "Do not claim all data/information comes from publicly accessible pages, public channels, official sources, public searchable network information, or has all been verified. The final source section lists only actual sources used and boundaries that still need confirmation.",
  "closing_disclaimer_rule": "For Function 1/2/3 final chat answers, Markdown reports and PDF-visible report text, the final non-empty line must repeat the exact fixed disclaimer; if missing, regenerate before delivery.",
  "final_large_model_review_required": true,
  "key_data_evidence_final_check_required": "All key data links for rankings, rates, tuition, scores, ranks, plan counts, QS/软科 rankings, industry/company/hiring indicators must be opened or otherwise verified by the executor/agent; final sources must record link_open_status and content_match_status.",
  "function3_new_project_estimation_basis_required": "For new/opening/first-intake/no-history Function 3 candidates, rank estimates require project status, official facts, B ordinary baseline, A same-province same-tier samples, similarity dimensions, sample count/weakness, formula, rough range, non-prediction boundary, and linked numeric evidence.",
  "pdf_delivery_required_for_functions_1_2_3": true,
  "pdf_delivery_rule": "Every Function 1/2/3 final answer must include a visible clickable PDF download link in the same response. Markdown-only output, PDF failure notes, delayed generation promises, or asking the user to continue generating the PDF are not completed delivery."
}
```

## Runtime context record

```json
{
  "current_date": "YYYY-MM-DD",
  "current_year": "string",
  "timezone": "IANA timezone or UTC/system timezone",
  "checked_at": "ISO-8601 string",
  "date_source_tool": "user_info.get_user_info | scripts/cooplens_core.py runtime-date | system date | python datetime | other available tool",
  "user_visible_line": "检索执行日期：YYYY年MM月DD日（时区：...；通过工具获取）",
  "latest_completed_admission_year_basis": "string explaining whether current-year admission lines are official or whether the report uses the latest completed 1-2 years",
  "current_year_approval_search_required": true
}
```

## Source evidence record

```json
{
  "claim_text": "string",
  "claim_type": "admission | certificate | fee | ranking | curriculum | major_industry_ai | industry_scale | company_performance | ai_impact | hiring_impact | employment | postgraduate_recommendation | source_for_ordering | other",
  "source_name": "string",
  "source_url": "https://...",
  "source_type": "CRS | provincial_exam_authority | school_admission_site | school_official_site | official_training_plan | foreign_university_site | industry_statistical_authority | industry_association | company_annual_report | company_interim_report | company_recruitment_page | AI_policy_or_whitepaper | employment_quality_report | postgraduate_recommendation_policy | QS_official | ShanghaiRanking_official | authoritative_media | user_provided_file",
  "local_index_used_only_for_discovery": true,
  "link_open_status": "opened | failed | not_applicable_user_file",
  "final_url": "string | null",
  "source_title": "string | null",
  "source_date_or_year": "string | null",
  "matched_text_or_table_anchor": "string",
  "content_match_status": "matched | partially_matched | derived_from_source_data | not_matched",
  "derived_formula": "string | null",
  "checked_at": "ISO-8601 string",
  "user_visible_source_link_required": true,
  "user_visible_source_must_be_clickable": true,
  "user_visible_numeric_value_prefix_required": "约",
  "user_visible_numeric_value_itself_must_be_clickable": true,
  "numeric_value_unlinked_marker": "【未满足：数字未直接链接来源】"
}
```


## Candidate row from local index

```json
{
  "index_id": "string",
  "canonical_project_or_institution_name": "string",
  "province_of_chinese_partner_or_entity": "string",
  "chinese_partner": "string",
  "foreign_partner": "string",
  "country_region": "string",
  "project_level": "string",
  "major_or_category": {"name": "string", "type": "string", "verification_status": "string"},
  "admissions": {"tuition_domestic_rmb_per_year_text": "string", "certificates": {}, "gaokao_subject_requirements": {}},
  "rankings": {},
  "data_quality": {"needs_human_or_live_web_recheck_before_final_recommendation": true},
  "recommendation_features": {}
}
```

## Target province and time basis fragment

```json
{
  "target_province": "string",
  "province_basis": "user_specified | chinese_partner_location_default | other_explained",
  "chinese_partner_province": "string",
  "campus_or_project_location": "string | null",
  "runtime_context": {
    "current_date": "YYYY-MM-DD",
    "current_year": "string",
    "timezone": "string",
    "date_source_tool": "string",
    "checked_at": "ISO-8601 string",
    "user_visible_line": "检索执行日期：YYYY年MM月DD日（时区：...；通过工具获取）"
  },
  "current_date_basis": "tool_acquired_runtime_date | unavailable_conservative_by_source_dates",
  "completed_admission_years_used": ["string"],
  "caveat": "如果用户实际报考省份不同，分数/计划/选科结论必须重算；不得预测当前年度确切位次"
}
```

## Report module fragment

```json
{
  "module_key": "string",
  "title": "string",
  "parent_question": "string",
  "answer": "string",
  "internal_evidence_status": "verified | partially_supported | unresolved | conflict | community_signal_only | employer_signal_only | direct_admission_line | same_school_international_reference | same_school_ordinary_reference | same_province_competitor | same_province_rank_gap_sample | comparable_sample",
  "user_facing_evidence_label": "官方已确认 | 还要核一处细节 | 还没查到公开官方信息 | 公开信息不一致 | 只是公开讨论信号 | 只是招聘/求职信号 | 只是参照样本 | 所在省竞品 | 历史位次空间样本",
  "risk_level": "red | yellow | blue | green",
  "official_sources_needed": ["CRS", "招生章程", "培养方案", "省考试院", "学校招办", "学校历年分数系统", "公开招聘公告", "就业质量报告", "就业质量年度报告", "推免工作办法", "推免名单/资格公示", "升学去向公示"],
  "next_action": "string"
}
```

## Admission threshold comparison fragment

User-facing numeric fields in this fragment are display strings and must include `约` before values; exact numeric values may be stored internally only for calculation/source matching.
Important numeric display fields should be rendered as clickable values, e.g. `[约589分]({source_url})`; a separate `source_url` field alone is not enough for user-facing Markdown/PDF.

```json
{
  "admission_threshold_status": "direct_verified | same_school_international_reference | same_school_ordinary_reference | same_province_competitor_reference | ordinary_admission_reference | rank_gap_reference | unavailable",
  "target_province": "string",
  "comparison_tier": "direct_project | same_school_coop | same_school_credit_mutual | same_school_international_path | same_school_similar_major | same_province_competitor | same_province_ordinary_similar_major | C9 | 985 | 211_double_first_class | double_first_class | non_double_first_class",
  "year": "string",
  "province": "string",
  "subject_or_selection": "string",
  "batch_or_group": "string",
  "major": "string",
  "plan_count": "string display with 约 | null",
  "minimum_score": "string display with 约 | null",
  "minimum_rank": "string display with 约 | null",
  "is_target_province_admission": true,
  "relative_position": "更靠前 | 接近 | 更靠后 | 不可比 | 数据不足",
  "source": "省考试院/学校招办/官方分数系统",
  "source_url": "https://...",
  "link_open_status": "opened",
  "content_match_status": "matched",
  "limits": "不能把参照样本直接等同于目标项目；不能预测当前年度确切分数或位次"
}
```

## Ordinary vs cooperative/international rank-gap fragment

```json
{
  "rank_gap_applicability": "applicable | not_applicable_no_chinese_ordinary_baseline | insufficient_data",
  "not_applicable_examples": ["香港中文大学（深圳）", "香港科技大学（广州）", "上海纽约大学", "昆山杜克大学"],
  "target_province": "string",
  "sample_count": "string display with 约",
  "minimum_sample_rule": "尽量不少于5组；少于3组只能作弱参照",
  "summary": {
    "median_rank_gap": "string display with 约 | null",
    "common_range_rank_gap": "string | null",
    "min_rank_gap": "string display with 约 | null",
    "max_rank_gap": "string display with 约 | null",
    "outlier_note": "string | null"
  },
  "samples": [
    {
      "school": "string",
      "tier_label": "C9 | 985 | 211/双一流 | 双一流 | 双非 | 其他",
      "softke_rank_or_band": "string | null",
      "year": "string",
      "province": "string",
      "ordinary_major_or_group": "string",
      "ordinary_minimum_rank": "string display with 约 | null",
      "coop_or_international_major_or_group": "string",
      "coop_or_international_type": "中外合作 | 中外学分互认 | 国际互认 | 联合培养 | 双学位 | 其他",
      "coop_or_international_minimum_rank": "string display with 约 | null",
      "rank_gap": "string display with 约 | null",
      "same_major": true,
      "sample_role": "同校优先样本 | 同省同档扩展样本 | 非同专业学校层面样本",
      "source": "string",
      "source_url": "https://...",
      "link_open_status": "opened",
      "content_match_status": "matched"
    }
  ],
  "allowed_wording": "这不是在预测今年分数线，而是在看同省同档学校过去普通招生和中外/国际路径招生之间通常差了多少位次。",
  "forbidden_wording": ["今年预计第X位", "今年预计X分", "一定低X分"]
}
```

## Competitor project fragment

```json
{
  "role": "同省同类平台同类外方类似专业 | 同省更高中方平台专业略弱 | 同省略低中方平台更贴近专业 | 同省投入更低平台稍低 | 同省投入更高平台/城市/证书更清楚 | 同省普通招生相近专业",
  "project_or_school": "string",
  "major": "string",
  "target_province_admission_status": "已核到所在省招生 | 待核验 | 未核到所在省招生",
  "formal_competitor": true,
  "same_school_reference_not_competitor": false,
  "chinese_platform_relative": "更高 | 接近 | 略低 | 不可比",
  "foreign_partner_relative": "更高 | 接近 | 略低 | 不适用 | 待核验",
  "major_fit": "更贴近 | 接近 | 略弱 | 不完全贴合",
  "cost_boundary": "更低 | 接近 | 更高 | 待核验",
  "recent_target_province_admission_position": "更靠前 | 接近 | 更靠后 | 数据不足",
  "certificate_clarity": "清楚 | 部分清楚 | 待核验",
  "relative_order": "优先 | 备选 | 观察 | 慎选",
  "internal_evidence_status": "verified | partially_supported | unresolved",
  "user_facing_evidence_label": "官方已确认 | 有材料支持但还要核细节 | 所在省竞品 | 还没查到公开官方信息",
  "why_it_matters": "string"
}
```

## Curriculum/course fragment

```json
{
  "curriculum_required": true,
  "source_priority": [
    "官方培养方案/专业培养计划",
    "招生宣传册/项目官网专业介绍",
    "外方课程页/handbook/program structure",
    "未查到公开课程清单，需问学院"
  ],
  "source_rows": [
    {
      "source_type": "官方培养方案 | 招生宣传册 | 项目官网 | 外方课程页 | 未查到",
      "source_name": "string",
      "year_or_applicable_cohort": "string | null",
      "what_it_supports": "string",
      "what_it_cannot_prove": "string",
      "next_confirmation": "string"
    }
  ],
  "course_rows": [
    {
      "course_or_module": "string",
      "source_type": "官方培养方案 | 宣传册 | 项目官网 | 外方课程页",
      "plain_parent_explanation": "string",
      "high_school_ability_needed": "string",
      "learning_difficulty": "string",
      "career_or_postgraduate_link": "string",
      "question_to_confirm": "string"
    }
  ],
  "fallback_sentence_if_no_full_plan": "未核到当年官方培养方案全文；现阶段只能根据官方招生宣传中已披露的课程模块/培养方向解释，具体课程以学校后续公布为准。",
  "do_not_invent_generic_courses": true
}
```

## Major, industry, AI and hiring impact analysis fragment

User-facing numeric fields in this fragment are display strings and must include `约`; important numeric values should be rendered as clickable values, e.g. `[约1.2万亿元]({source_url})`.

```json
{
  "module_title": "专业与行业前景分析",
  "required_for": ["function_1_single_project", "function_2_multi_project_comparison"],
  "must_cover": [
    "专业所属行业/子行业",
    "行业规模",
    "景气程度",
    "龙头企业业绩",
    "人工智能对行业的影响",
    "AI 对生产率/人效的影响",
    "约4–8年后未来人才需求",
    "行业员工招聘的影响",
    "学生如何应对"
  ],
  "rows": [
    {
      "project_or_major": "string",
      "industry_mapping": {
        "primary_industry": "string",
        "sub_industries": ["string"],
        "mapping_basis": "培养方案 | 招生宣传册 | 项目官网 | 外方课程页 | 就业去向 | 招聘JD"
      },
      "industry_scale": {
        "display_value": "[约X](https://...) | 公开权威数据暂未核到",
        "metric_name": "市场规模 | 营业收入 | 增加值 | 从业人数 | 企业数量 | 其他",
        "source_url": "https://...",
        "source_type": "industry_statistical_authority | industry_association | authoritative_report | company_annual_report"
      },
      "prosperity_signal": {
        "qualitative_status": "扩张 | 修复 | 分化 | 周期波动 | 结构调整 | 数据不足",
        "evidence_summary": "string",
        "source_url": "https://..."
      },
      "leading_company_performance": [
        {
          "company": "string",
          "performance_metric": "营收 | 净利润 | 研发投入 | 员工人数 | 资本开支 | 业务增减 | 其他",
          "display_value": "[约X](https://...) | 未公开",
          "what_it_suggests": "string",
          "limit": "不能把单家公司业绩等同于整个行业"
        }
      ],
      "ai_impact": {
        "tasks_automated_or_assisted": ["string"],
        "productivity_or_human_efficiency_change": "string",
        "roles_enhanced": ["string"],
        "new_roles_or_opportunities": ["string"],
        "entry_level_threshold_change": "string",
        "source_url": "https://... | null"
      },
      "future_4_to_8_year_employment_outlook": {
        "horizon": "入学后约4–8年，覆盖毕业和早期职业阶段",
        "talent_demand_direction": "扩张 | 收缩 | 分化 | 结构升级 | 头部集中 | 周期波动 | 数据不足",
        "ai_productivity_effect_on_headcount": "string",
        "entry_level_jobs_likely_compressed": ["string"],
        "roles_likely_to_grow": ["string"],
        "confidence_boundary": "情景判断，不是确定预测",
        "source_url": "https://... | null"
      },
      "hiring_impact": {
        "signals": ["校招公告", "岗位JD", "员工/研发投入", "就业质量报告", "招聘平台趋势线索"],
        "skills_in_demand": ["string"],
        "source_url": "https://... | null"
      },
      "student_response": {
        "freshman": "string",
        "sophomore": "string",
        "junior": "string",
        "senior": "string",
        "portfolio_or_internship_focus": "string"
      },
      "fallback_sentence_if_unverified": "公开权威行业规模/景气数据暂未核到，需要继续查主管部门、行业协会或龙头企业财报。"
    }
  ],
  "function2_required_sorting": "专业/行业景气与AI适应度排序",
  "no_numeric_score": true
}
```

## Employment, further-study, overseas-study, and recommendation-for-postgraduate-study fragment

```json
{
  "module_title": "就业、升学、出国和保研情况",
  "must_not_use_titles": ["毕业出口", "出口数据", "出口透明度"],
  "required_items": ["就业率", "升学率/深造率", "出国/境升学率或国（境）外升学比例", "保研/推免情况"],
  "do_not_rank_these_rates": true,
  "rows": [
    {
      "item": "就业率 | 升学率/深造率 | 出国/境升学率 | 保研/推免情况",
      "project_level_value": "string | 未公开 | 暂无毕业生 | 还没查到公开官方数据",
      "nearest_available_reference": "学院级 | 学校级 | 相近普通专业 | 外方背景 | 无",
      "data_level": "项目级 | 专业级 | 学院级 | 学校级 | 相近普通专业 | 外方背景 | 未公开",
      "source_type": "就业质量年度报告 | 学院就业统计 | 推免工作办法 | 推免名单/资格公示 | 升学去向公示 | 外方官方背景 | 未查到",
      "what_it_can_support": "string",
      "what_it_cannot_prove": "不能把学校级/学院级数据等同于目标项目",
      "question_to_confirm": "string"
    }
  ],
  "fallback_sentence": "项目级就业率、升学率、出国/境升学率和保研/推免情况还没查到公开官方数据；目前只能把学校/学院层面的数据作为背景，不能等同于这个专业。"
}
```


## Future four-path planning fragment

```json
{
  "module_title": "未来四年：考研、出国、保研、就业四条路怎么准备",
  "separate_from_outcome_rates_module": true,
  "rows": [
    {
      "path": "保研/推免 | 国内考研 | 出国/境申硕 | 就业",
      "freshman_year_focus": "string",
      "sophomore_year_focus": "string",
      "junior_year_focus": "string",
      "senior_year_focus": "string",
      "biggest_risk": "string",
      "parent_watchpoint": "string",
      "school_confirmation_question": "string",
      "major_specific_notes": "计算机/人工智能/数据类需覆盖编程、数学、英文、项目、科研/竞赛、实习、GPA与外方课程影响"
    }
  ],
  "must_include_grade_terms": ["大一", "大二", "大三", "大四"],
  "must_include_paths": ["保研", "国内考研", "出国申硕", "就业"],
  "forbidden_shortcut": "不能用就业率/升学率数据表替代四年路径规划"
}
```

## Internal claim audit fragment

```json
{
  "internal_only": true,
  "do_not_show_in_user_report": true,
  "claims": [
    {
      "claim_id": "string",
      "claim_text": "string",
      "claim_type": "project_identity | admission_plan | score_rank | certificate | tuition | study_mode | curriculum | major_industry_ai | industry_scale | company_performance | ai_impact | hiring_impact | ranking | employment_further_study | recommendation_policy | competitor | public_discussion",
      "source_name": "string",
      "source_type": "CRS | 招生章程 | 学校本科招生网 | 省考试院 | 一分一段表 | 培养方案 | 招生宣传册 | 外方官网 | 行业主管部门 | 行业协会 | 龙头企业年报 | 龙头企业财报 | 企业招聘公告 | AI政策/白皮书 | 就业质量报告 | 推免办法 | 权威媒体 | 第三方线索 | 公开讨论",
      "source_date_or_year": "string | null",
      "evidence_strength": "官方直接支持 | 官方间接支持 | 权威媒体线索 | 第三方线索待核 | 公开讨论信号",
      "contradiction_check": "none | conflict_found | insufficient_sources",
      "user_facing_wording": "string",
      "next_verification_question": "string | null"
    }
  ],
  "final_report_must_not_show": ["claim_id", "audit_status", "verified", "unresolved", "proxy", "检索分值", "脚本输出"]
}
```

## Module sorting fragment for multi-project / retrieval reports

```json
{
  "module": "综合优先级 | 国内就业优先 | 出国深造优先 | 性价比优先 | 录取位置 | 全成本压力 | 证书清晰与认可度 | 专业/行业景气与AI适应度 | 培养可承受度 | 待确认事项清晰度 | 适配人群 | 总体建议",
  "rate_fields_not_allowed_as_sorting_modules": ["就业率", "升学率", "出国/境升学率", "保研率", "推免情况"],
  "order": [
    {
      "rank_order": 1,
      "project": "string",
      "qualitative_label": "优先 | 备选 | 观察 | 慎选 | 更高 | 接近 | 更低",
      "reason": "string",
      "caveat": "string"
    }
  ],
  "no_numeric_score": true
}
```

## Function 2 eleven-chapter comparison report fragment

```json
{
  "function": "multi_project_comparison",
  "decision_flow": [
    "先给排序结论",
    "能不能上（分数位次）",
    "花多少钱（全成本）",
    "文凭硬不硬（认可度）",
    "出路好不好（就业升学）",
    "专业所在行业好不好（行业与AI影响）",
    "孩子能不能读（培养难度）",
    "哪些事项要确认（待核对点）",
    "适不适合自家",
    "怎么核实",
    "最终建议"
  ],
  "required_chapters": [
    {"chapter": 1, "title": "对比结论与优先级排序", "must_include": ["综合优先级总排序", "国内就业优先", "出国深造优先", "性价比优先", "一句话核心优劣势速览"]},
    {"chapter": 2, "title": "录取门槛对比：你家孩子能不能上", "must_include": ["近3年本省最低分/最低位次", "同校普通vs中外位次差", "选科要求", "招生计划", "首招/新获批项目参照依据"]},
    {"chapter": 3, "title": "全成本对比：四年到底要花多少钱", "must_include": ["国内年学费", "四年总学费", "海外阶段费用", "隐性成本", "4+0和出国场景分开估算"]},
    {"chapter": 4, "title": "文凭与认可度对比：毕业证到底硬不硬", "must_include": ["中方毕业证/学位证", "外方学位", "证书标注", "保研资格", "考公/选调/国企限制", "留服/备案核查"]},
    {"chapter": 5, "title": "毕业去向对比：花了钱，出路怎么样", "must_include": ["就业率", "升学率/深造率", "出国/境升学率", "海外申研院校层次", "主要就业行业", "暂无毕业生数据标注"]},
    {"chapter": 6, "title": "专业与行业前景对比：这个专业未来还能不能吃饭", "must_include": ["专业所属行业", "行业规模", "景气程度", "龙头企业业绩", "人工智能对行业的影响", "AI 对生产率/人效的影响", "约4–8年后未来人才需求", "行业员工招聘的影响", "学生如何应对", "专业/行业景气与AI适应度排序", "横向比较", "不是只看当前就业率"]},
    {"chapter": 7, "title": "培养模式与学业难度对比：孩子能不能跟上", "must_include": ["4+0/2+2/3+1", "是否强制出国", "外方课程占比", "英文授课比例", "外方师资形式", "英语/GPA要求", "转专业政策"]},
    {"chapter": 8, "title": "待确认事项对比：这些问题请逐项核对", "must_include": ["办学有效期", "办学有效期/招生状态", "出国条件未达成时的后续安排", "外方院校真实排名与资质", "政策变动"]},
    {"chapter": 9, "title": "适配人群对比：哪个更适合你家孩子", "must_include": ["各项目适合画像", "预算", "位次", "选科", "英语/数学/编程", "是否愿意出国", "多个项目都不建议选的情况"]},
    {"chapter": 10, "title": "招生办必核实问题清单", "must_include": ["证书类3题", "保研政策类2题", "费用类2题", "出国/培养类3题"]},
    {"chapter": 11, "title": "小屏总结", "must_include": ["不同发展目标选择结论", "填报注意事项", "最终建议顺序"]}
  ],
  "source_rule": "除公开讨论匿名聚合外，所有事实必须有官方或权威媒体来源；第三方只能作线索并需标注需官方复核。",
  "do_not_show_internal_audit": true,
  "no_numeric_score": true
}
```

## Direct response fragment

```json
{
  "direct_response_required_before_pdf": true,
  "must_include": [
    "先说结论",
    "关键理由",
    "所在省往年分数/位次表",
    "同校既有国际/中外路径参照",
    "普通 vs 中外/国际路径位次空间参照",
    "培养方案/课程来源与课程白话解释",
    "专业与行业前景分析",
    "未来四年：考研、出国、保研、就业四条路怎么准备",
    "同省正式竞品/可替代项目参照",
    "就业、升学、出国和保研情况",
    "公开讨论匿名聚合",
    "家长需要问清的问题"
  ],
  "forbidden_user_facing_terms": [
    "proxy",
    "unresolved",
    "verified",
    "功能3处理",
    "候选召回",
    "占位符",
    "TBD"
  ]
}
```

## PDF output fragment

```json
{
  "direct_response_before_pdf": true,
  "pdf_required_by_default": true,
  "markdown_optional": true,
  "pdf_title": "对{项目/机构 + 专业}项目的AI分析报告",
  "artifact_link_required": true,
  "skip_pdf_only_if_user_explicitly_requests_no_pdf": true,
  "pdf_style": "阅读型报告：结论卡片、短段落、浅色表格、留白、大表拆分或横排",
  "must_not_omit_from_pdf": ["培养方案/课程来源表", "课程白话解释表", "专业与行业前景分析表", "未来四年四条路径规划表", "就业/升学/出国/保研情况表", "竞品位次表", "普通—中外位次差距表", "公开讨论匿名聚合表", "同校中外/国际路径与同校普通专业分行参照"]
}
```

## Fixed disclaimer required in every report

```text
重要声明：CoopLens Skill产出的内容由AI 生成，真实性需要使用者自行核实，不代表任何官方意见，不能作为任何决策依据或参考。
```

## Forbidden in final report

- Platform names from public discussion.
- Usernames or handles.
- Post titles, direct quotes, screenshots, personal identifiers.
- Raw community URLs.
- Defamatory labels presented as fact.
- Claims that public comments alone prove employer recognition or non-recognition.
- Longer disclaimer text beyond the fixed one-sentence disclaimer.
- Numeric project ratings, recommendation scores, star ratings, weighted scores, percentage scores.
- Current-year exact score/rank predictions when official current-year admission data has not been released.
- Treating first-intake/first-year admissions as an advantage, disadvantage, risk, or sorting factor.
- Calling out-of-province samples “same-province competitors”.
- Applying ordinary-vs-cooperative rank-gap logic to institutions without a Chinese ordinary-admission baseline.
- Blunt phrases such as “用钱换平台”“低分进名校”“花钱补分”.
- Internal codes or placeholders such as `claim_id`, `audit_status`, `unresolved`, `verified`, `proxy`, `功能3处理`, `候选召回`, `待填`, `TBD`, `TODO`, `占位符`.


## 输出展示字段补充：红色数据来源提示

当报告结构需要单独展示来源说明时，字段 `source_note_display` 必须采用以下固定格式：

```html
<span style="color:red">数据来源：上述信息务必需要用户自行确认，本报告为AI生成，不对真实性负责；{source_links_or_page_notes}</span>
```

如果某个模块无法保证红色渲染，禁止在模块下输出“数据来源：”段落；改为报告最后统一使用 `参考来源与核验说明`，并保留可点击链接。


## Additional output constraints

- User-facing reports must not use “避坑清单”, “这些坑”, “有什么坑”, “坑点”, “风险点对比”, “野鸡大学”, “骗局”, “欺骗”, “虚假宣传”. Use “核对提醒”, “待确认事项”, “需要向招生办/学院确认的问题”.
- Function 3 reports must include `current_year_new_approvals_search`: current year, CRS/MOE source checked, 所在省 plan status, whether included as formal candidate, and source links.
- First-intake/current-year newly approved candidates cannot be skipped solely because they have no historical line; they must be evaluated through B 普通招生基线 + A 同档普通—中外位次差样本 + B 粗略参照范围 if official hard facts are available.
- Function 3 no-history candidates must not show only one inferred value or one inferred ordering result. They require visible 推测依据: 无历史线候选核验表, B 普通招生基线表, A 同省同档普通—中外/国际路径位次差样本表, B 粗略参照范围与适配表, formula, sample count/weakness, and non-prediction boundary. Every numeric datum in those tables must be a direct source hyperlink; otherwise mark `【未满足：推测依据数据缺少链接】` or `【未满足：无历史线推测依据不完整】`.


## multi_source_verification_fragment

内部核验字段，用户报告不得展示原字段名，只用于生成前检查。

```json
{
  "claim_id": "internal-only",
  "claim_text": "准备写入报告的事实",
  "claim_type": "project_identity | admission_plan | rank_score | certificate | fee | curriculum | ranking | employment | recommendation | competitor | community_signal",
  "source_name": "来源名称",
  "source_url": "https://...",
  "source_type": "L1_official_direct | L2_official_calculated | L3_authoritative | L4_third_party_lead | L5_public_discussion",
  "source_date_or_year": "2026",
  "retrieval_query": "检索式或站内检索词",
  "source_existence_status": "exists | search_snippet_only | not_found | broken_link",
  "metadata_match_status": "matched | partial | mismatched",
  "matched_text_or_table_anchor": "页码/表名/原文片段/行列说明",
  "content_match_status": "exact | calculated_from_source | partial | mismatch",
  "independent_source_count": 1,
  "evidence_strength": "L1_direct | L2_calculated | L3_authoritative | L4_lead_only | L5_discussion_only",
  "contradiction_check": "none | conflict_found",
  "contradiction_action": "use_higher_authority | present_as_inconsistent | do_not_use",
  "user_facing_wording": "给家长看的白话写法",
  "next_verification_question": "需要向招生办/学院确认的问题"
}
```


## 最终统一来源章节字段

报告末尾必须包含 `final_consolidated_sources`，用户可见标题为 `参考来源与核验说明`。建议字段：`source_id`、`source_name`、`source_url`、`source_type`、`year_or_publish_time`、`supports`、`verification_boundary`。正文模块下不要重复输出来源小节；重要数字仍必须在数字本身上挂可点击链接。


## 1.0.12 quality-gate additions

- `postgraduate_recommendation_evidence`: for 保研率/推免率/推免资格 fields, record `source_level`, `source_type`, `source_url`, `statistical_year`, `matched_text_or_table_anchor`, `content_match_status`, and `project_level_available`. If project-level data is unavailable, set `project_level_available=false` and do not output a numeric project rate.
- `pdf_table_layout_preflight`: for Function 2/3 reports, record `max_body_table_columns`, `long_cell_count`, `layout_action` (`keep_table`, `split_table`, `card_layout`), `row_height_mode=auto`, and `overlap_risk_status`. A report with `overlap_risk_status=risky` must not be delivered as PDF until fixed.


## 1.0.12 final-audit additions

- `no_blanket_source_claims`: user-facing output must not contain absolute source guarantees such as “所有数据均来自公开可访问页面”, “所有信息均来自公开渠道”, “全部数据已核实”, “所有数据都有官方来源”, or similar.
- `final_executor_agent_review`: before delivery, the current executor/agent must internally review the final direct reply, Markdown and PDF-visible content against the disclaimer, runtime date, source-link, no-blanket-claim, PDF-delivery and table-layout rules. This review is not a required external language-model API call: Codex, 豆包办公任务, ChatGPT, or another file/script-capable agent should run it by default. If API quota is explicitly available and permitted, an external model/API may be used only as optional supplementary review. The internal checklist is not shown to users unless requested.

## 1.0.12 mandatory PDF-delivery addition

Function 1/2/3 final-answer schema must include:

```json
{
  "pdf_delivery_required": true,
  "pdf_link_visible_in_same_response": true,
  "pdf_link_pattern": "*.pdf or platform PDF attachment link",
  "markdown_only_fallback_counts_as_complete": false,
  "delayed_pdf_language_allowed": false,
  "required_checks_before_delivery": ["pdf-delivery-check", "no-blanket-source-claims-check", "closing-disclaimer-check", "completion-gate-check", "final-product-audit-check"]
}
```


## 1.0.12 PDF 与链接最终硬闸门

- 功能 2/3 不得把多项目候选或同分段参考项目做成普通 4–5 列 Markdown 宽表后直接转 PDF；必须拆表或卡片化。
- PDF 生成后必须做视觉渲染复核；若出现文字重叠、裁切或链接覆盖，必须重新生成。
- 关键数据链接必须最终打开并确认内容支持对应数字。若打不开或内容不支持，删除该数字或写“未核到可打开且内容对应的官方/权威原文”。


## 1.0.12 Function 2/3 parity and PDF-link schema additions

Function 2/3 project cards must include `pdf_card_layout=true`, `body_wide_table_allowed=false`, `key_numeric_pdf_link_status`, and `pdf_link_annotation_status`. For every key value in the PDF body, store or verify: `value_text`, `source_url`, `source_open_status`, `content_match_status`, and `pdf_annotation_present`.

For Function 3 new/no-history projects that remain in the recommendation list, include `rough_rank_range_required=true` and fields `range_type` (`optimistic_neutral_conservative | broad_reference_range`), `range_text`, `B_ordinary_admission_baseline`, `A_same_tier_samples`, `sample_strength`, `formula`, `not_prediction_boundary`, and `basis_numeric_links_status`. If a range cannot be formed, set `ranking_participation=false` and move the item to `watch_only_candidates`.

## 1.0.12 Function 2 delivery parity additions

Function 2 reports must declare or satisfy:

- `function2_body_markdown_tables_allowed=false`
- `function2_source_table_allowed=false`
- `function2_layout_style=project_cards_or_html_cards`
- `function2_key_values_linked_in_markdown=true`
- `function2_key_values_linked_in_pdf=true`
- `function2_pdf_visual_layout_status=passed`
- `function2_pdf_key_data_link_status=passed`

If any status is not passed, regenerate the Function 2 report and PDF before delivery.


## 1.0.12 HTML/PDF 交付与防截断硬规则

- HTML 强制交付硬规则：功能 1/2/3 完成时必须同时交付 Markdown、HTML、PDF 三件套；同一轮回答必须有可点击 PDF 下载链接、HTML 可视化报告链接和 Markdown 报告链接。运行 `python scripts/cooplens_core.py artifact-delivery-check <final-answer.md>`、`html-delivery-check`、`pdf-delivery-check`，任一失败都必须重新生成。
- HTML 不使用固定内容模板：HTML 必须从同一份 Markdown 生成，只能把 Markdown 的标题、段落、列表、链接、卡片化结构转成 HTML 标签并加 CSS；不能在 HTML 中新增项目、说明、统计、标题、图片、页脚口号、示例内容或任何 Markdown/PDF 没有的可见文字。
- HTML 与 Markdown/PDF 内容一致性：HTML、Markdown、PDF 的章节顺序、正文、关键数据、链接、核验边界、免责声明必须保持一致。运行 `python scripts/cooplens_core.py html-consistency-check <report.md> <report.html>`；发现 HTML 与 Markdown/PDF 内容不一致，标记 `【未满足：HTML与Markdown/PDF内容不一致或添加了额外内容】` 并重新生成。
- 不得增加图片：HTML 报告不得新增 `<img>`、SVG、canvas、iframe、外部图片、背景图片、图标库或脚本。视觉效果只能来自 CSS 的色彩、留白、边框、阴影、卡片、标签、时间线和响应式布局；不能添加其他图片。
- 色彩与布局提示词：HTML 可参考现代前端报告页的轻量风格，但只作为样式层使用。建议使用浅色背景、白色卡片、圆角、轻微阴影、蓝紫/青绿/琥珀等少量强调色、清晰标题层级、项目卡片、来源卡片、提示框、宽松行距、可打印 CSS；不得改变内容。
- PDF 文本防截断硬规则：PDF 不能出现文本截断、同一行被裁剪、免责声明被切掉、表格单元格文字叠加。Markdown/HTML 转 PDF 时必须设置 `overflow-wrap:anywhere`、`word-break:break-word`、`line-break:anywhere`、`white-space:normal`、`hyphens:auto`、`height:auto`、`max-width:100%`，并禁止 `white-space:nowrap`、`overflow:hidden`、固定高度和固定行高。
- 每行固定字数上限：面向 PDF 的可见段落建议约 32-38 个中文字符后自然换行；免责声明、来源 URL、长项目名、长专业名、长数值解释必须允许自动换行。执行 `python scripts/cooplens_core.py pdf-text-wrap-check <report.md-or-html>`；出现 `【未满足：PDF存在文本截断/换行风险，必须重新生成】` 时必须重排。
- PDF 必须优先从已通过 `html-report-check` 的 HTML 导出，而不是直接把 Markdown 宽表转 PDF。HTML/PDF 中仍不得使用 Function 2/3 宽表，候选项目、费用、位次、证书、课程、来源均优先使用卡片或窄列表。
- 产物交付前必须依次运行：`html-report-check <report.html>`、`html-consistency-check <report.md> <report.html>`、`pdf-text-wrap-check <report.html>`、`pdf-visual-layout-check <report.pdf>`、`pdf-key-data-link-check <report.pdf>`、`completion-gate-check <final-answer.md>`。任何一步失败都必须重新生成 Markdown/HTML/PDF 三件套。
