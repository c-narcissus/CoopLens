#!/usr/bin/env python3
"""CoopLens 1.0.12 helper.

One-file utility for:
- validating the slim package,
- querying the local project-major candidate index,
- querying the compact local QS/软科 ranking DB,
- providing a runtime-date helper so every run can acquire current date through a tool,
- checking report text for community-source privacy leaks,
- enforcing fixed disclaimer, response-first output, pain-point report order, mandatory four-year four-path planning, friendly-PDF style, mandatory curriculum/course modules, mandatory major-industry-AI modules, official source-method rules, source-authenticity audit policy, admission-position references, competitor-map, qualitative-sorting, startup, ranking and employer-recognition policy terms.

The project index and ranking DB are discovery/matching aids only, never final user-facing sources.
User-facing招生/证书/学费/分数线/排名/行业规模/龙头企业业绩/招聘影响事实 require official or authoritative source links in the same paragraph or table row, and links must be opened and content-matched before writing facts. Important numeric indicators must make the numeric value itself a clickable source link; otherwise the report checker marks them.
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import re
import sys
import urllib.request
import urllib.error
from urllib.parse import urlparse
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

ROOT = Path(__file__).resolve().parents[1]
INDEX_PATH = ROOT / "data" / "project_major_index.json"
SKILL_PATH = ROOT / "SKILL.md"
CORE_WORKFLOW_PATH = ROOT / "references" / "core_workflow.md"
PROMPTS_PATH = ROOT / "prompts" / "report_modules.md"
RANKINGS_PATH = ROOT / "data" / "rankings_local_compact.json"
RANKINGS_SEMANTIC_PATH = ROOT / "data" / "rankings_semantic.md"
SOURCE_METHODS_PATH = ROOT / "references" / "source_methods.md"
SCHEMA_PATH = ROOT / "references" / "schema.md"

REQUIRED_FILES = [
    "SKILL.md",
    "license.txt",
    "references/core_workflow.md",
    "references/schema.md",
    "references/source_methods.md",
    "data/project_major_index.json",
    "data/rankings_local_compact.json",
    "data/rankings_semantic.md",
    "prompts/report_modules.md",
    "scripts/cooplens_core.py",
]

FORBIDDEN_TREE_NAMES = {
    "imports",
    "mcp",
    "app",
    "runtime_indexes",
    "generated_reports",
    "local_knowledge_sources",
    "softke_bcmr_2026",
    "qs_world_rankings_2027_2026_2025_official_json",
}

# These terms are forbidden in final user-facing report sections that summarize
# anonymous community reputation. They may appear inside this skill file as rules.
FORBIDDEN_REPORT_PLATFORM_TERMS = [
    "小红书", "知乎", "抖音", "快手", "B站", "微博", "Twitter",
    "Reddit", "一亩三分地", "豆瓣", "公众号评论", "网友", "楼主", "博主",
    "up主", "帖子", "原帖", "用户说", "评论区说",
]


# Terms that should not appear in final user-facing reports. Internal docs may
# discuss these as legacy wording, but generated reports should use calmer
# alternatives such as 录取门槛差异、位次空间、平台匹配度 and 家庭投入边界.
FORBIDDEN_BLUNT_REPORT_TERMS = [
    "花的钱买到了什么", "花的钱", "买到了什么", "分数折扣", "位次折扣",
    "用钱换平台", "用钱弥补", "花钱补分", "低分进名校", "低分买名校",
    "这笔钱买", "每降低一分", "每降低一档", "多少钱买",
    "避坑清单", "这些坑", "有什么坑", "坑点", "坑",
    "风险点对比", "这些坑一定要避开", "风险等级", "红灯", "黄灯", "蓝灯", "绿灯",
    "野鸡大学", "骗局", "欺骗", "虚假宣传", "不靠谱", "项目质量有问题", "学校不正规",
]

FORBIDDEN_RATING_REPORT_TERMS = [
    "综合评分", "推荐评分", "项目评分", "性价比评分", "评分：", "评分:",
    "推荐指数", "星级", "满分", "得分", "分值", "加权分", "权重分",
    "打分", "打个分", "百分制", "五星", "四星", "三星", "⭐",
]

FORBIDDEN_AMBIGUOUS_OUTCOME_TERMS = [
    "毕业出口", "出口数据", "出口透明度", "就业出口", "升学出口",
]

RATE_MODULE_REQUIRED_GROUPS = {
    "就业率": ["就业率"],
    "升学率/深造率": ["升学率", "深造率"],
    "出国/境升学率": ["出国/境升学率", "出国升学率", "境外升学率", "国（境）外升学", "国境外升学", "境外深造"],
    "考研率/国内考研": ["考研率", "国内考研", "考研"],
    "保研/推免情况": ["保研", "推免"],
    "数据层级或缺口": ["项目级", "专业级", "学院级", "学校级", "相近普通专业", "外方背景", "未公开", "暂无毕业生", "还没查到公开官方数据"],
}

RATE_YEAR_SOURCE_VALIDITY_GROUPS = {
    "升学率": ["升学率", "深造率"],
    "出国率": ["出国率", "出国/境升学率", "出国升学率", "境外升学率", "国（境）外升学", "国境外升学", "境外深造"],
    "考研率": ["考研率", "国内考研", "考研"],
    "保研率": ["保研率", "推免率", "保研", "推免"],
}

YEAR_PATTERN = re.compile(r"20\d{2}")
RATE_SOURCE_TERMS = ["来源链接", "数据来源", "原文链接", "就业质量报告", "本科教学质量报告", "推免办法", "推免名单", "学校官网"]
RATE_SOURCE_VALIDITY_TERMS = ["可打开", "已打开", "打开后", "内容对应", "核验", "核到", "有效来源", "来源有效", "原文显示", "表格显示"]
FAILED_SOURCE_TERMS = ["空网址", "空链接", "打不开", "无法打开", "链接失效", "死链", "404", "未打开", "没有对应信息", "内容不对应", "不对应", "未核验成功", "核验失败", "来源无效"]
EMPTY_SOURCE_PATTERN = re.compile(r"\]\(\s*\)|(?:来源链接|数据来源|原文链接)\s*[:：|]\s*(?:$|无|空|暂无|待补|N/?A|-)", flags=re.IGNORECASE)

FUTURE_FOUR_PATH_REQUIRED_GROUPS = {
    "未来四年标题": ["未来四年", "四条路", "四条路径", "四条出路"],
    "保研/推免路径": ["保研", "推免"],
    "国内考研路径": ["国内考研", "考研"],
    "出国/境申硕路径": ["出国申硕", "出国/境申硕", "境外申硕", "国（境）外", "海外申硕"],
    "就业路径": ["就业", "秋招", "实习"],
    "年级动作": ["大一", "大二", "大三", "大四"],
    "不确定项与家长盯点": ["主要不确定项", "家长要盯", "家长盯", "需要向学校确认", "需要问学校"],
}

SOURCE_AUTHORITY_REQUIRED_GROUPS = {
    "官方或权威来源": ["官方", "招生章程", "学校官网", "本科招生网", "CRS", "教育部", "省考试院", "招生考试院", "一分一段", "培养方案", "就业质量报告", "推免"],
    "数据缺口或复核": ["需要问", "需要确认", "还没查到", "未公开", "以学校", "以省考试院", "官方复核"],
    "公开讨论隔离": ["公开讨论", "匿名聚合", "不能当事实", "需要官方确认", "只是公开讨论"],
}

COMMUNITY_MODULE_REQUIRED_GROUPS = {
    "公开讨论": ["公开讨论", "网络讨论", "匿名聚合", "公开口碑"],
    "担心/看法": ["担心", "常见看法", "正面看法", "负面担忧"],
    "核验": ["需要官方确认", "需要问", "核验", "问清"],
}

MAJOR_INDUSTRY_AI_REQUIRED_GROUPS = {
    "专业所属行业": ["专业所属行业", "对应行业", "子行业", "行业方向", "行业映射"],
    "行业规模": ["行业规模", "市场规模", "产业规模", "营业收入", "增加值", "产值", "用户规模", "从业人数"],
    "景气程度": ["景气程度", "景气", "增速", "增长", "利润", "PMI", "景气指数", "周期", "结构调整", "扩张", "修复", "分化"],
    "龙头企业业绩": ["龙头企业", "代表企业", "行业龙头", "业绩", "营收", "净利润", "研发投入", "年报", "财报"],
    "人工智能影响": ["人工智能", "AI", "大模型", "自动化", "智能化", "任务替代", "任务增强"],
    "AI生产率影响": ["生产率", "提效", "人效", "效率", "人均产出", "自动化"],
    "约4-8年就业视角": ["4–8年", "4-8年", "四到八年", "毕业和早期职业", "毕业时", "早期职业", "孩子毕业"],
    "未来人才需求": ["未来人才需求", "人才需求", "需求变化", "用人需求", "岗位需求", "招聘需求", "结构升级"],
    "入门岗位变化": ["入门岗位", "岗位收缩", "岗位压缩", "扩张", "收缩", "分化", "结构升级", "头部集中"],
    "招聘影响": ["招聘", "校招", "岗位", "JD", "员工", "用人需求", "岗位变化", "入门门槛"],
    "学生应对": ["如何应对", "学生如何应对", "应对", "大一", "大二", "大三", "大四", "项目作品", "作品集", "实习", "竞赛", "技能"],
}

RATE_SORTING_PATTERN = re.compile(
    r"(?:就业率|升学率|深造率|出国(?:/境)?升学率|境外升学率|国（境）外升学|保研率|推免率|保研情况|推免情况).{0,16}(?:排序|排名|第\s*\d|优先|备选|观察|慎选)"
    r"|(?:排序|排名|第\s*\d|优先|备选|观察|慎选).{0,16}(?:就业率|升学率|深造率|出国(?:/境)?升学率|境外升学率|国（境）外升学|保研率|推免率|保研情况|推免情况)",
)

RATING_PATTERN = re.compile(r"(?:综合|推荐|项目|性价比|平台|专业|费用|证书|就业)?\s*(?:评分|得分|分值|推荐指数)\s*[:：]?\s*\d+(?:\.\d+)?\s*(?:/|／|分|%)")

FIRST_INTAKE_TERMS = ["首届本科招生", "首届招生", "首次本科招生", "首次招生", "新获批", "首次招收", "第一届招生"]
FIRST_INTAKE_REASON_TERMS = ["因为", "由于", "关键原因", "主要原因", "所以", "导致", "因此", "故", "作为原因"]
FIRST_INTAKE_JUDGMENT_TERMS = ["优先", "备选", "观察", "慎选", "不确定项", "劣势", "优势", "不建议", "暂不建议", "放后", "排序", "扣分", "回避", "过滤", "排除", "剔除", "淘汰", "不纳入", "不推荐", "默认观察", "默认放后"]
FIRST_INTAKE_SAFE_NEGATION_TERMS = ["不作为", "不能作为", "不得作为", "不能直接当成", "只影响", "只表示", "不能因为", "不得因为", "不要因为", "不能因", "不得因", "不是因为", "不因为", "不能回避", "不得回避", "不要回避", "不应回避", "不得过滤", "不能过滤", "不得排除", "不能排除"]
NO_HISTORY_TERMS = ["没有历史线", "无历史线", "暂无历史线", "没有历史分数线", "暂无本项目历史", "没有本项目历史", "无本项目历史"]
SAME_SCHOOL_INTERNATIONAL_TERMS = ["同校中外合作", "同校既有中外", "同校既有国际", "中外学分互认", "国际本科学术互认", "国际互认", "联合培养", "双学位", "学分互认"]
SAME_PROVINCE_COMPETITOR_TERMS = ["同省竞品", "目标省招生", "目标省有招生", "正式竞品", "其他学校", "同省招生"]
RANK_GAP_TERMS = ["普通—中外", "普通 vs 中外", "普通线", "中外线", "位次差", "位次空间", "历史参照区间", "历史位次空间"]
NO_CHINESE_ORDINARY_BASELINE_TERMS = ["没有中方普通", "不适用", "香港中文大学（深圳）", "香港科技大学（广州）", "港中深", "港科广", "上海纽约大学", "昆山杜克"]

FORBIDDEN_FINAL_INTERNAL_TERMS = [
    "proxy_score_only", "same_school_proxy", "same_tier_proxy", "ordinary_admission_reference",
    "direct_admission_line", "community_signal_only", "employer_signal_only",
    "unresolved", "verified", "partially_supported", "结构化抽取", "本地缓存",
    "知识图谱", "本地索引", "本地排名库", "本地库", "旧报告", "缓存文件", "候选召回", "功能3处理", "本报告按功能3处理",
    "待填", "TBD", "TODO", "占位符", "见 PDF", "见PDF", "PDF里有详细内容", "详见PDF",
    "claim_id", "audit_status", "source ledger", "源核验表", "内部核验表", "检索分值", "脚本输出",
]

COMMUNITY_POLICY_TERMS = [
    "公开网络口碑", "隐藏痛点", "匿名", "平台名称", "用户名", "正面", "负面", "反驳", "签证", "出境",
    "community_signal_only", "不作为官方事实", "不得出现平台名",
]

OFFICIAL_POLICY_TERMS = [
    "CRS", "招生章程", "培养方案", "宣传册", "课程清单", "省考试院", "一分一段", "分位数", "学费", "证书", "本地索引只用于候选召回", "本地索引、本地排名库", "不能作为最终来源", "不能把核验责任转交给用户",
    "rankings_local_compact.json", "QS", "软科", "local ranking database", "安全命中", "官方数据获取通用方法", "普通—中外位次空间", "同省正式竞品",
]

VALUE_POLICY_TERMS = [
    "录取门槛差异", "位次空间", "平台匹配度", "家庭投入", "更合适的国内高校平台", "国内证书", "统招身份",
    "国内雇主认可度", "大企业", "央国企", "公开招聘", "网申", "学校名声",
    "首次招生中性处理", "首届/首次招生严格中性规则", "中性但不回避", "功能 3 不回避首次招生项目", "首次招生项目不得因无历史线被回避", "用户省份", "中方学校所在地", "同校既有中外合作项目", "中外学分互认", "国际本科学术互认", "联合培养",
    "同校相近专业", "同档次", "C9", "985", "211", "双一流", "双非", "只是参照样本",
    "单项目分析", "多项目对比", "根据省市", "分数/位次", "选科",
    "相似项目", "竞品项目", "竞品坐标", "同类平台", "更高中方平台", "略低中方平台",
    "投入更低", "投入更高", "同省普通招生", "过去一两年", "不预测当前年度",
    "各维度结论", "总体排序", "禁止项目评分", "先直接回复", "完整家长版答复", "阅读型报告", "自动生成 PDF", "培养方案", "课程",
    "同省竞品", "目标省招生", "正式竞品", "其他学校", "普通—中外", "位次差", "历史参照区间", "软科主榜层次接近", "没有中方普通招生盘子", "香港中文大学（深圳）", "香港科技大学（广州）", "就业率", "升学率", "出国/境升学率", "保研", "推免", "公开讨论匿名聚合",
]

FOUR_PATH_POLICY_TERMS = [
    "未来四年", "四条路径", "四条路", "保研", "国内考研", "出国申硕", "就业", "大一", "大二", "大三", "大四",
    "主要不确定项", "家长要盯", "需要向学校确认", "不能替代四年路径规划",
]

TRUST_AUDIT_POLICY_TERMS = [
    "内部真实性核验", "claim ledger", "claim_id", "audit_status", "官方直接支持", "权威媒体", "第三方线索", "公开讨论信号",
    "双源校验", "冲突处理", "公开讨论隔离", "报告不展示内部机制", "CRS", "省考试院", "招生章程", "培养方案", "就业质量报告", "推免办法",
]

EVIDENCE_LINK_POLICY_TERMS = [
    "原文网络链接", "可点击引用", "数字即链接", "报告末尾统一参考来源", "参考来源与核验说明", "链接打开与内容一致性", "可打开", "内容对应",
    "数字、排名与关键事实", "第三方汇总线索，需以省考试院/学校招办复核",
    "聊天直接回复、Markdown 和 PDF", "QS/软科官方页", "本地索引不能作为来源",
]

AUDIT_ORCHESTRATION_POLICY_TERMS = [
    "智能体/执行器最终审核", "不依赖外部语言模型 API", "优先由当前平台的智能体自己调度",
    "Codex", "豆包办公任务", "ChatGPT", "读取文件", "运行脚本",
    "API 额度", "可选增强", "没有 API 时", "脚本自检",
]

RED_DATA_SOURCE_POLICY_TERMS = [
    "数据来源：", "上述信息务必需要用户自行确认，本报告为AI生成，不对真实性负责",
    "整段红色", "color:red", "红色数据来源提示", "PDF 渲染必须保留红色",
]

LEGAL_SAFE_WORDING_POLICY_TERMS = [
    "法律安全表达", "核对提醒", "待确认事项", "需要向招生办/学院确认的问题",
    "公开资料尚未核到", "不得使用", "避坑清单", "野鸡大学", "定性指控",
]

CURRENT_YEAR_APPROVAL_POLICY_TERMS = [
    "功能 3：当年新批准项目检索硬规则", "当前年份", "教育部/CRS 最新批准",
    "最新公布", "最新复核", "所在省招生计划", "已获批但本省计划待确认",
    "不能只依赖本地索引", "当年新批准/新获批项目检索结果",
]

FUNCTION3_RANK_ESTIMATION_POLICY_TERMS = [
    "功能 3：同档样本支持的排位估算规则", "B 普通招生基线", "A 同档普通—中外位次差样本",
    "B 粗略参照范围", "A→B 同档位次差迁移估算法", "功能 3 首次招生项目不得因无历史线被回避", "首次招生候选核验表",
    "样本不足", "弱参照", "同省同档", "位次差常见区间", "这不是今年录取预测",
    "功能 3 无历史线项目推测依据硬规则", "无历史线候选核验表", "不能只给一个推测数据",
    "完整推测依据", "计算公式", "样本强弱", "无历史线推测依据不完整", "推测依据数据缺少链接",
]

FUNCTION3_NEW_PROJECT_ESTIMATION_POLICY_TERMS = [
    "功能 3 新开/无历史线项目位次估算完整理由链", "新开项目", "本省首招", "项目状态",
    "官方/权威基础事实", "相似性维度", "计算公式", "非预测边界",
    "新开/无历史线项目位次估算理由链不完整", "function3-new-project-estimation-check",
]

KEY_DATA_EVIDENCE_POLICY_TERMS = [
    "关键数据证据最终核对", "各种排名", "就业率", "升学率", "保研率/推免率", "出国/境升学率",
    "学费", "分数线", "排位/位次", "招生人数", "QS 排名", "软科排名", "链接存在", "链接可用",
    "内容支持", "内容对应状态", "链接状态", "关键数据链接未核实或内容不支持", "key-data-evidence-check",
    "打开链接后内容必须真的支撑数字", "打不开或内容不对应必须删除数据", "open mode",
]

POSTGRAD_RECOMMENDATION_POLICY_TERMS = [
    "保研率/推免率官方核验硬规则", "保研率/推免率属于高影响关键指标",
    "项目级保研率/推免率未核到官方公开数据", "推免工作办法", "推免实施细则",
    "推免名额分配", "推免资格公示", "推免名单", "postgraduate-recommendation-check",
    "保研率/推免率缺少官方来源依据",
]

PDF_TABLE_LAYOUT_POLICY_TERMS = [
    "功能 2/3 PDF 表格防挤叠硬规则", "PDF 表格自适应与拆表方法",
    "pdf-table-layout-check", "rowHeights", "自动换行", "自动高度", "VALIGN=TOP",
    "splitByRow=True", "卡片式布局", "PDF表格行高/单元格自适应存在挤叠风险",
    "PDF 视觉渲染复核", "pdf-visual-layout-check", "禁止普通 Markdown 宽表直转 PDF",
]


CLOSING_DISCLAIMER_POLICY_TERMS = [
    "最后一行非空内容也必须重复同一句固定免责声明",
    "closing-disclaimer-check",
    "必须重新生成报告",
]

PDF_DELIVERY_POLICY_TERMS = [
    "PDF 强制交付硬规则", "全功能 PDF 强制交付硬规则", "pdf-delivery-check",
    "completion-gate-check", "可点击 PDF 下载链接", "同一轮回答",
    "没有 PDF 链接", "不算完成", "请继续生成 PDF", "稍后生成 PDF",
]

HTML_DELIVERY_POLICY_TERMS = [
    "HTML 强制交付硬规则", "html-delivery-check", "html-consistency-check",
    "Markdown、PDF、HTML 三件套", "从同一份 Markdown 生成 HTML",
    "内容严格一致", "不得增加图片", "不能添加额外内容", "视觉样式只能来自 CSS",
    "HTML 不使用固定内容模板", "HTML 与 Markdown/PDF 内容一致性",
]

PDF_TEXT_WRAP_POLICY_TERMS = [
    "PDF 文本防截断硬规则", "pdf-text-wrap-check", "免责声明可视化换行",
    "每行固定字数上限", "CJK line breaking", "overflow-wrap:anywhere",
    "word-break:break-word", "line-break:anywhere", "不得截断文本",
    "发现截断必须重新生成",
]

MULTI_SOURCE_VERIFICATION_POLICY_TERMS = [
    "零假设核验", "多重确认机制", "存在性检查", "元信息一致", "内容支持", "双源校验", "双源确认",
    "Crossref", "OpenAlex", "Semantic Scholar", "source_existence_status", "metadata_match_status",
    "independent_source_count", "contradiction_action", "L1 一级官方直接支持", "搜索摘要", "AI 生成的引用",
]

APPROX_PREFIX_POLICY_TERMS = [
    "数值数据“约”字硬规则", "所有面向用户展示的数值数据前加“约”",
    "约589分", "约第133名", "约30%", "约4.8万元/年", "约120人",
    "区间两端都要加“约”", "PDF 中所有数值型数据必须继续带“约”",
]

CLICKABLE_SOURCE_POLICY_TERMS = [
    "参考来源不能只用文字", "可点击超链接", "参考来源与核验说明",
    "不能聊天里无链接、PDF 里补链接", "报告末尾统一参考来源",
]

NUMERIC_SELF_LINK_POLICY_TERMS = [
    "重要数字指标“数字即链接”硬规则", "数字本身", "数字即链接",
    "每个重要数字指标必须", "numeric-link-check",
    "【未满足：数字未直接链接来源】", "数字未直接链接来源",
]

RUNTIME_DATE_POLICY_TERMS = [
    "运行时日期获取硬规则", "先通过工具获取执行时日期", "检索执行日期",
    "date_source_tool", "current_year", "runtime_context", "python scripts/cooplens_core.py runtime-date",
    "不得依赖模型记忆", "最新完成招生年度", "通过工具获取",
]

MAJOR_INDUSTRY_AI_POLICY_TERMS = [
    "专业与行业前景分析", "功能 1 和功能 2", "专业所属行业", "行业规模",
    "景气程度", "龙头企业业绩", "人工智能对行业的影响", "行业员工招聘的影响",
    "学生如何应对", "专业/行业景气与AI适应度排序", "AI 影响不能泛泛而谈",
    "行业规模、市场规模、营收、利润、招聘人数",
]

FUTURE_EMPLOYMENT_HORIZON_POLICY_TERMS = [
    "约 4–8 年", "约4–8年", "未来人才需求", "AI 对生产率", "生产率/人效",
    "入门岗位", "岗位压缩", "结构升级", "毕业和早期职业阶段", "不是确定预测",
]

FUNCTION2_FUTURE_COMPARISON_POLICY_TERMS = [
    "功能 2 固定十一章", "第 6 章", "专业与行业前景对比",
    "约 4–8 年后的行业人才需求", "AI 对生产率", "龙头企业经营变化",
    "校招/JD 信号", "专业/行业景气与AI适应度排序", "function2-check",
]

STARTUP_PAGE_POLICY_TERMS = [
    "启动页三功能卡片硬规则", "只输出启动页", "只有 **3 个核心功能**",
    "① 单项目分析", "② 多项目对比", "③ 按所在省份 + 分数/位次 + 考试科目检索可参考项目",
    "材料提醒", "招生章程", "招生计划", "宣传册", "培养方案", "项目网页截图",
    "不展示版本号", "不展示版本", "校验状态", "内部规则", "目录长清单", "数据来源规则",
    "安装页或验证页口吻", "已成功启动", "安装完成", "验证结果", "必需文件完整", "包结构有效", "Skill 功能概览", "如何使用",
    "startup-check", "clean startup page", "three function cards", "启动页统一使用“所在省份”", "未写时默认按中方高校所在省份",
]

STARTUP_REQUIRED_FUNCTIONS = [
    "① 单项目分析",
    "② 多项目对比",
    "③ 按所在省份 + 分数/位次 + 考试科目检索可参考项目",
]

STARTUP_FORBIDDEN_TERMS = [
    "当前版本", "版本号", "模式名", "当前模式", "校验通过", "validate", "report-check", "numeric-link-check", "function2-check",
    "脚本状态", "内部规则", "所有数字加约", "数字即链接", "红色数据来源", "后台规则", "完整报告目录", "目录长清单",
    "本地索引", "候选召回", "结构化抽取", "claim_id", "audit_status", "unresolved", "verified",
    "数据来源：", "来源链接", "原文链接", "QS", "软科", "最低分", "最低位次", "优先关注", "候选列表",
    "请稍等", "后台处理", "后续我会", "稍后给你", "目标省份", "所在省份/选科/分数或位次", "所在省份 / 选科 / 分数或位次", "江西，物理类", "约580分", "预算约多少",
    "已成功启动", "安装完成", "验证结果", "必需文件完整", "包结构有效", "无错误", "Skill 功能概览", "功能概览",
    "CoopLens 是一个", "中外合作办学项目分析工具", "专为家长择校场景设计", "表格", "官方核验", "家长版报告", "如何使用",
    "你可以直接告诉我", "帮我分析一下", "江西考生", "位次 2 万名", "物化", "Markdown + PDF", "Markdown/PDF", "PDF 双格式", "核心结论", "完整的 Markdown/PDF 报告",
]

POSTGRAD_NUMERIC_CONTEXT_PATTERN = re.compile(
    r"(?:保研率|推免率|保研/推免率|推免比例|保研比例|推荐免试人数|推免名额|保研名额)[^。；;\n|]{0,80}(?:约\s*)?\d+(?:\.\d+)?\s*(?:%|％|人|名|个|项)?"
)
POSTGRAD_OFFICIAL_SOURCE_TERMS = [
    "推免工作办法", "推免办法", "推荐优秀应届本科毕业生免试攻读研究生", "推免实施细则",
    "推免名额", "名额分配", "推免资格公示", "推免名单", "就业质量报告", "本科教学质量报告",
    "教务处", "研究生院", "学院官网", "学校官网", "官方", "公示", "实施办法",
]
POSTGRAD_BOUNDARY_TERMS = [
    "项目级保研率/推免率未核到官方公开数据", "项目级保研率未核到官方公开数据",
    "项目级推免率未核到官方公开数据", "未核到官方公开", "未查到项目级", "未公开",
    "不能等同于这个专业", "不能套到该项目", "需要向学校确认",
]
PDF_TABLE_RISK_MARKER = "【未满足：PDF表格行高/单元格自适应存在挤叠风险】"
POSTGRAD_RISK_MARKER = "【未满足：保研率/推免率缺少官方来源依据】"
PDF_LINK_PATTERN = re.compile(r"\[[^\]]*(?:PDF|pdf|报告|下载)[^\]]*\]\((?:sandbox:/|https?://|\./|/)[^)]+?\.pdf(?:[?#][^)]+)?\)|(?:sandbox:/|https?://|\./|/)\S+?\.pdf(?:[?#]\S+)?", re.IGNORECASE)
PDF_DELAY_PATTERN = re.compile(r"(?:稍后|之后|后续|待会|下次).{0,12}(?:生成|补充|提供|输出).{0,8}PDF|(?:请|需要|可|可以|人工).{0,10}(?:继续|追加|再).{0,10}(?:生成|输出|提供).{0,8}PDF|(?:如果|若).{0,10}(?:没|未).{0,6}生成.{0,12}(?:继续|追加|再).{0,8}(?:生成|输出).{0,8}PDF|见\s*PDF|PDF里有详细内容|PDF\s*生成失败|无法生成\s*PDF|未生成PDF报告", re.IGNORECASE)
HTML_LINK_PATTERN = re.compile(r"\[[^\]]*(?:HTML|html|网页|可视化|在线阅读)[^\]]*\]\((?:sandbox:/|https?://|\./|/)[^)]+?\.html(?:[?#][^)]+)?\)|(?:sandbox:/|https?://|\./|/)\S+?\.html(?:[?#]\S+)?", re.IGNORECASE)
MARKDOWN_LINK_PATTERN = re.compile(r"\[[^\]]*(?:Markdown|markdown|MD|md|报告|下载)[^\]]*\]\((?:sandbox:/|https?://|\./|/)[^)]+?\.md(?:[?#][^)]+)?\)|(?:sandbox:/|https?://|\./|/)\S+?\.md(?:[?#]\S+)?", re.IGNORECASE)
HTML_FORBIDDEN_EXTRA_PATTERN = re.compile(r"<\s*img\b|background-image\s*:|<\s*svg\b|<\s*canvas\b|<\s*script\b|<\s*iframe\b", re.IGNORECASE)
PDF_TEXT_CLIP_RISK_MARKER = "【未满足：PDF存在文本截断/换行风险，必须重新生成】"
HTML_DELIVERY_MISSING_MARKER = "【未满足：未生成HTML可视化报告】"
HTML_CONSISTENCY_MARKER = "【未满足：HTML与Markdown/PDF内容不一致或添加了额外内容】"


BLANKET_SOURCE_CLAIM_PATTERNS = [
    re.compile(r"(?:本报告|报告)?\s*(?:所有|全部|每一[条项]|全部的|所有的).{0,12}(?:数据|信息|事实|资料|来源).{0,10}(?:均|都|全部|皆)?\s*(?:来自|来源于|取自).{0,18}(?:公开可访问|公开可查|公开渠道|公开资料|网络信息|网络公开信息|公开网络信息|官方来源|权威来源|公开页面|公开网页|公开网站)"),
    re.compile(r"(?:所有|全部|每一[条项]|全部的|所有的).{0,12}(?:数据|信息|事实|资料|来源).{0,12}(?:已|都已|均已|全部)?\s*(?:核实|核验|验证|确认|审查)(?:完毕|完成)?"),
    re.compile(r"(?:数据|信息|资料|来源).{0,8}(?:均|都|全部|皆).{0,8}(?:来自|来源于|取自).{0,18}(?:公开可访问|公开可查|公开渠道|公开资料|网络信息|网络公开信息|公开网络信息|官方来源|权威来源|公开页面|公开网页|公开网站)"),
    re.compile(r"公开可(?:访问|查)(?:的)?(?:网络)?(?:信息|页面|网页|网站|资料)"),
    re.compile(r"(?:完整|全面).{0,6}(?:覆盖|核验).{0,8}(?:公开资料|公开信息|所有资料|所有信息|所有数据)"),
    re.compile(r"(?:由|经)\s*AI\s*(?:整理|汇总).{0,6}(?:生成|整理)?"),
    re.compile(r"AI\s*整理生成"),
]
BLANKET_SOURCE_CLAIM_MARKER = "【未满足：存在绝对化来源承诺，必须重新生成报告】"
CLOSING_DISCLAIMER_MARKER = "【未满足：报告结尾未重复固定免责声明，必须重新生成报告】"

SOURCE_LINK_PATTERN = re.compile(
    r"https?://|\[[^\]]+\]\(https?://[^)]+\)|citeturn\d+\w+\d+|fileciteturn\d+file\d+L\d+-L\d+"
)

NUMERIC_OR_RANKING_FACT_PATTERN = re.compile(
    r"(?:\d{4}\s*年|\d+(?:\.\d+)?\s*(?:分|位|名|人|万人|元|万元|亿元|万亿元|亿|万|%|/年|所|个|届|组)|"
    r"4\+0|3\+1|2\+2|1\+3|QS|软科|排名|985|211|双一流|C9|CRS)"
)

KEY_FACT_TERMS_REQUIRING_LINK = [
    "最低分", "最低位次", "位次区间", "计划数", "招生人数", "选科",
    "学费", "住宿费", "注册费", "教材费", "语言考试", "签证", "保险", "机票", "生活费", "四年总投入",
    "办学有效期", "审批", "备案", "统招", "毕业证", "学位证", "外方学位", "证书",
    "培养模式", "外方课程占比", "英文授课", "转专业",
    "就业率", "升学率", "深造率", "出国/境升学率", "境外升学", "保研", "推免",
    "专业所属行业", "行业规模", "市场规模", "产业规模", "营业收入", "营收", "净利润", "利润", "增速", "景气程度", "龙头企业", "龙头企业业绩", "人工智能", "AI", "招聘", "校招", "岗位JD", "员工人数", "研发投入",
    "QS", "软科", "985", "211", "双一流", "C9",
]

DATA_VALUE_HEADERS_REQUIRING_APPROX = [
    "最低分", "分数", "最低位次", "位次", "位次区间", "计划数", "招生人数", "人数",
    "学费", "费用", "住宿费", "注册费", "教材费", "生活费", "总投入", "成本",
    "排名", "名次", "QS", "软科", "就业率", "升学率", "深造率", "出国", "境外", "考研率", "保研率", "推免率",
    "课程比例", "外方课程占比", "位次差", "差距", "区间",
    "行业规模", "市场规模", "产业规模", "营业收入", "营收", "净利润", "利润", "增速", "增长率", "研发投入", "员工人数", "招聘人数", "从业人数", "景气指数",
]

APPROX_EXEMPT_HEADERS = ["年份", "年度", "省份", "科类", "选科", "批次", "专业组", "学校", "项目", "专业", "类型", "作用", "来源", "链接", "获取方法", "关系", "数据口径"]

APPROX_UNIT_VALUE_PATTERN = re.compile(
    r"(?<!约)(?<![A-Za-z0-9.])(?:第\s*)?\d+(?:\.\d+)?\s*(?:分|位|名|人|万人|元|万元|亿元|万亿元|亿|万|%|％|/年|所|个|项|门|次|倍)"
)
APPROX_VALUE_OK_PATTERN = re.compile(
    r"约\s*(?:第\s*)?\d+(?:\.\d+)?(?:\+)?\s*(?:分|位|名|人|万人|元|万元|亿元|万亿元|亿|万|%|％|/年|所|个|项|门|次|倍)?"
)
APPROX_CONTEXT_VALUE_PATTERN = re.compile(
    r"(?:最低分|分数|最低位次|位次|计划数|招生人数|人数|学费|费用|总投入|排名|名次|就业率|升学率|深造率|出国(?:/境)?升学率|考研率|保研率|推免率|位次差|课程比例|外方课程占比|行业规模|市场规模|产业规模|营业收入|营收|净利润|利润|增速|增长率|研发投入|员工人数|招聘人数|从业人数|景气指数)"
    r"[^。；;\n|]{0,12}(?<!约)(?<![A-Za-z0-9.])(?:第\s*)?\d+(?:\.\d+)?(?:\+)?(?:\s*(?:分|位|名|人|万人|元|万元|亿元|万亿元|亿|万|%|％|/年))?"
)
APPROX_BARE_NUMBER_PATTERN = re.compile(r"(?<!约)(?<![A-Za-z0-9.])(?:第\s*)?\d+(?:\.\d+)?(?:\+)?(?![A-Za-z0-9])")
YEAR_ONLY_PATTERN = re.compile(r"^(?:约)?20\d{2}\s*年?$|^20\d{2}\s*[-/.]\s*\d{1,2}(?:\s*[-/.]\s*\d{1,2})?$")
STUDY_MODE_PATTERN = re.compile(r"^(?:约)?[1-4]\s*\+\s*[0-4]$")

DISCLAIMER_REQUIRED = "重要声明：CoopLens Skill产出的内容由AI 生成，真实性需要使用者自行核实，不代表任何官方意见，不能作为任何决策依据或参考。"
DATA_SOURCE_REQUIRED_NOTICE = "数据来源：上述信息务必需要用户自行确认，本报告为AI生成，不对真实性负责"
RED_DATA_SOURCE_PATTERN = re.compile(
    r"(?:<span[^>]*(?:color\s*:\s*red|color\s*:\s*#(?:f00|ff0000)|class\s*=\s*[\"'][^\"']*red)[^>]*>.*?数据来源：.*?</span>|"
    r"<font[^>]*color\s*=\s*[\"']?(?:red|#(?:f00|ff0000))[\"']?[^>]*>.*?数据来源：.*?</font>|"
    r"\\textcolor\{red\}\{.*?数据来源：.*?\})",
    flags=re.IGNORECASE | re.DOTALL,
)
DISCLAIMER_FOOTER = ""

LOCAL_SOURCE_TERMS = ["本地索引", "本地排名库", "本地库", "旧报告", "缓存文件", "local cache", "local ranking"]
URL_EXTRACT_PATTERN = re.compile(r"https?://[^\s)\]}>\"'，。；、]+")
TEXT_ONLY_SOURCE_LABEL_PATTERN = re.compile(r"(?:参考来源|来源链接|原文链接|数据来源|来源)\s*[:：|]")

CONSOLIDATED_SOURCE_SECTION_HEADERS = ["参考来源与核验说明", "统一参考来源", "报告参考来源", "参考来源"]
PER_MODULE_SOURCE_BLOCK_PATTERN = re.compile(r"(?:^|[|\s])(?:数据来源|来源链接|原文链接|参考来源|来源)\s*[:：|]", flags=re.IGNORECASE)
RUNTIME_DATE_LINE_PATTERN = re.compile(r"(?:检索执行日期|执行日期|运行时日期|资料检索日期)\s*[:：].*(?:工具获取|系统时间|user_info|runtime-date|date_source_tool|当前环境未能通过工具)")
RUNTIME_DATE_EXEMPT_TERMS = ["检索执行日期", "执行日期", "运行时日期", "资料检索日期", "checked_at", "date_source_tool", "runtime_context"]

IMPORTANT_NUMERIC_VALUE_PATTERN = re.compile(
    r"约\s*(?:第\s*)?\d+(?:\.\d+)?(?:\+)?"
    r"(?:\s*(?:万元/年|万元|亿元/年|亿元|万亿元|元/年|元|分|位|名|人|万人|%|％|所|个|项|门|组|次|倍)|\s*[万亿](?:\s*(?:元/年|元|位|人|名))?)"
)
# Ranking shorthand such as "QS前100" or "QS 65" is still a key numeric claim.
# It must be linked and evidence-checked just like "约第65位".
RANKING_SHORTHAND_VALUE_PATTERN = re.compile(
    r"(?:QS|软科|ShanghaiRanking)\s*(?:前\s*\d+|第\s*\d+|\d+(?:\+)?(?:\s*[-–—]\s*\d+)?)",
    flags=re.IGNORECASE,
)
MARKDOWN_INLINE_LINK_PATTERN = re.compile(r"\[([^\]]+)\]\((?:https?://|file://)[^)]+\)")
MARKDOWN_INLINE_LINK_WITH_URL_PATTERN = re.compile(r"\[([^\]]+)\]\(((?:https?://|file://)[^)]+)\)")
HTML_ANCHOR_URL_TEXT_PATTERN = re.compile(r'''<a\b[^>]*href\s*=\s*[\'"](https?://[^\'"]+)[\'"][^>]*>(.*?)</a>''', flags=re.IGNORECASE | re.DOTALL)
MARKDOWN_REFERENCE_LINK_PATTERN = re.compile(r"\[([^\]]+)\]\[[^\]]+\]")
HTML_ANCHOR_PATTERN = re.compile(r"<a\b[^>]*href\s*=\s*['\"](?:https?://|file://)[^'\"]+['\"][^>]*>.*?</a>", flags=re.IGNORECASE | re.DOTALL)
IMMEDIATE_CITATION_PATTERN = re.compile(r"^\s*(?:citeturn\d+\w+\d+|fileciteturn\d+file\d+L\d+-L\d+)")
UNLINKED_NUMERIC_MARKER = "【未满足：数字未直接链接来源】"
NO_HISTORY_ESTIMATION_INCOMPLETE_MARKER = "【未满足：无历史线推测依据不完整】"
ESTIMATION_NUMERIC_LINK_MISSING_MARKER = "【未满足：推测依据数据缺少链接】"
NEW_PROJECT_ESTIMATION_INCOMPLETE_MARKER = "【未满足：新开/无历史线项目位次估算理由链不完整】"
KEY_DATA_EVIDENCE_UNVERIFIED_MARKER = "【未满足：关键数据链接未核实或内容不支持】"
PDF_KEY_DATA_LINK_MISSING_MARKER = "【未满足：PDF关键数据未保留可点击链接，必须重新生成PDF】"
NEW_PROJECT_NO_RANGE_MARKER = "【未满足：新开/无历史线项目未给出用户可用的粗略位次范围】"

NO_HISTORY_ESTIMATION_TRIGGER_TERMS = [
    "之前没有招生信息", "没有招生信息", "没有本项目历史", "暂无本项目历史", "无本项目历史",
    "没有本项目历史线", "暂无本项目历史线", "无历史线", "暂无历史线", "首次招生", "首招", "新获批", "当年新批准",
    "新开项目", "新设项目", "新项目", "本省首招", "本省首次招生", "首次在本省招生", "新增项目", "新增专业",
]
NO_HISTORY_ESTIMATION_ACTION_TERMS = [
    "推测", "估算", "预估", "估计", "预测", "粗略参照范围", "历史参照范围", "位次空间", "相对排位", "候选排序", "排序位置", "A→B", "B 普通招生基线", "A 同档",
]
ESTIMATION_BASIS_LINE_TERMS = [
    "推测依据", "推测", "估算", "排位", "相对排位", "排序位置", "B 普通", "普通招生基线", "A 同档", "同省同档", "位次差", "粗略参照范围", "历史参照范围",
    "适配表", "样本", "公式", "无历史线候选", "普通招生最低位次", "中外/国际路径最低位次",
]



@dataclass
class Candidate:
    score: float
    row: dict[str, Any]
    reasons: list[str]


@dataclass
class RankCandidate:
    score: float
    source: str
    record: dict[str, Any]
    reasons: list[str]


def get_runtime_date_context() -> dict[str, Any]:
    """Return current date/time from the runtime as a machine-readable tool result.

    This command exists so CoopLens executions can ground “今年/当前年份/最新”
    in an explicit tool call rather than model memory, cached files, or index years.
    """
    now = _dt.datetime.now().astimezone()
    tzinfo = now.tzinfo
    timezone = getattr(tzinfo, "key", None) or (tzinfo.tzname(now) if tzinfo else None) or "system-local"
    current_date = now.date().isoformat()
    return {
        "current_date": current_date,
        "current_year": str(now.year),
        "timezone": timezone,
        "checked_at": now.isoformat(timespec="seconds"),
        "date_source_tool": "scripts/cooplens_core.py runtime-date",
        "user_visible_line": f"检索执行日期：{now.year}年{now.month:02d}月{now.day:02d}日（时区：{timezone}；通过工具获取）",
        "instruction": "Use this runtime date before source collection; do not rely on model memory, file timestamps, local index years, or cached reports as the current-year basis.",
    }


def load_index(path: Path = INDEX_PATH) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Missing local candidate index: {path}")
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict) or "rows" not in data or not isinstance(data["rows"], list):
        raise ValueError("project_major_index.json must be an object with a rows list")
    return data


def load_rankings(path: Path = RANKINGS_PATH) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Missing compact ranking DB: {path}")
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict) or "qs_world_university_rankings" not in data or "softke_2026" not in data:
        raise ValueError("rankings_local_compact.json must contain qs_world_university_rankings and softke_2026")
    return data


def norm(text: Any) -> str:
    if text is None:
        return ""
    return re.sub(r"\s+", "", str(text).lower())


def tokens(query: str) -> list[str]:
    raw = re.split(r"[\s,，;；/|、]+", query.strip().lower())
    result = []
    for item in raw:
        item = item.strip()
        if not item:
            continue
        result.append(item)
    # Keep useful Chinese chunks even when user enters a sentence without spaces.
    for key in [
        "计算机", "人工智能", "软件", "数据", "电子信息", "电气", "医学", "金融", "经济",
        "985", "211", "双一流", "双非", "港校", "香港", "澳门", "英国", "美国", "澳大利亚",
        "深圳", "广东", "北京", "上海", "江苏", "浙江", "4+0", "3+1", "2+2",
        "分数", "位次", "录取门槛", "位次空间", "平台", "雇主", "就业", "大厂", "央国企", "国内证书", "统招", "学信网",
        "竞品", "相似项目", "同类平台", "更高中方平台", "略低中方平台", "费用", "证书", "排序",
        "未来四年", "保研", "考研", "出国申硕", "就业", "大一", "大二", "大三", "大四", "真实性核验", "来源链接", "普通招生基线", "同省同档", "位次差样本",
    ]:
        if key.lower() in query.lower() and key.lower() not in result:
            result.append(key.lower())
    return result


def row_search_text(row: dict[str, Any]) -> str:
    parts: list[str] = []
    fields = [
        "canonical_project_or_institution_name", "chinese_partner", "foreign_partner",
        "country_region", "project_level", "province_of_chinese_partner_or_entity", "city",
    ]
    for f in fields:
        parts.append(str(row.get(f, "")))
    major = row.get("major_or_category") or {}
    parts.extend([str(major.get("name", "")), str(major.get("major_group", "")), str(major.get("industry_group", ""))])
    cpf = row.get("chinese_partner_level") or {}
    parts.append(str(cpf.get("school_level_exact", "")))
    adm = row.get("admissions") or {}
    parts.append(str(adm.get("study_mode_text", "")))
    rec = row.get("recommendation_features") or {}
    parts.extend(str(v) for v in rec.values())
    return norm(" ".join(parts))


def score_row(row: dict[str, Any], query: str) -> Candidate:
    q_tokens = tokens(query)
    text = row_search_text(row)
    score = 0.0
    reasons: list[str] = []

    for t in q_tokens:
        nt = norm(t)
        if nt and nt in text:
            score += 2.0
            reasons.append(f"命中:{t}")

    qn = norm(query)
    name = norm(row.get("canonical_project_or_institution_name", ""))
    major = norm((row.get("major_or_category") or {}).get("name", ""))
    if name and name in qn:
        score += 8
        reasons.append("项目/机构精确命中")
    if major and major in qn:
        score += 5
        reasons.append("专业精确命中")

    if row.get("recommendation_eligible") is True:
        score += 1.5
        reasons.append("可作为候选召回")
    else:
        score -= 2
        reasons.append("非精确专业候选")

    missing = set((row.get("data_quality") or {}).get("missing_or_unverified_fields", []))
    if "学费" in "".join(missing) or "证书原文" in "".join(missing):
        score -= 0.5
    if (row.get("major_or_category") or {}).get("verification_status", "").startswith("not_a_verified"):
        score -= 3

    return Candidate(score=score, row=row, reasons=reasons)


def query_candidates(query: str, top: int = 8, eligible_only: bool = False) -> list[Candidate]:
    data = load_index()
    cands: list[Candidate] = []
    for row in data["rows"]:
        if eligible_only and row.get("recommendation_eligible") is not True:
            continue
        c = score_row(row, query)
        if c.score > 0:
            cands.append(c)
    cands.sort(key=lambda c: c.score, reverse=True)
    return cands[:top]


def summarize_candidate(c: Candidate, rank_order: int | None = None) -> dict[str, Any]:
    row = c.row
    major = row.get("major_or_category") or {}
    adm = row.get("admissions") or {}
    cert = adm.get("certificates") or {}
    ranks = row.get("rankings") or {}
    foreign_qs = ranks.get("foreign_qs_world_university_2027") or {}
    softke_school = ranks.get("softke_chinese_school_2026") or {}
    softke_major = ranks.get("softke_chinese_major_2026") or {}
    quality = row.get("data_quality") or {}
    return {
        "rank_order": rank_order,
        "reasons": c.reasons[:8],
        "index_id": row.get("index_id"),
        "name": row.get("canonical_project_or_institution_name"),
        "major": major.get("name"),
        "major_verification_status": major.get("verification_status"),
        "chinese_partner": row.get("chinese_partner"),
        "foreign_partner": row.get("foreign_partner"),
        "school_level": (row.get("chinese_partner_level") or {}).get("school_level_exact"),
        "location": row.get("province_of_chinese_partner_or_entity"),
        "country_region": row.get("country_region"),
        "study_mode": adm.get("study_mode_text"),
        "tuition": adm.get("tuition_domestic_rmb_per_year_text"),
        "certificate_summary": cert.get("award_summary_text"),
        "foreign_qs_2027": foreign_qs.get("rank") if foreign_qs.get("match_status") == "matched_local_qs_2027" else None,
        "softke_school_2026": softke_school.get("rank") if str(softke_school.get("match_status", "")).startswith("matched") else None,
        "softke_major_2026_status": softke_major.get("match_status"),
        "needs_live_recheck": quality.get("needs_human_or_live_web_recheck_before_final_recommendation", True),
        "missing_or_unverified_fields": quality.get("missing_or_unverified_fields", []),
    }


def _alias_text_for_qs(record_name: str, aliases: list[dict[str, Any]]) -> str:
    parts: list[str] = []
    nr = norm(record_name)
    for a in aliases:
        canonical = norm(a.get("canonical_english", ""))
        alias_values = [norm(x) for x in a.get("aliases", [])]
        if nr == canonical or nr in alias_values or canonical in nr or nr in canonical:
            parts.append(str(a.get("query_cn", "")))
            parts.append(str(a.get("canonical_english", "")))
            parts.extend(str(x) for x in a.get("aliases", []))
    return " ".join(parts)


def query_rankings(query: str, top: int = 8) -> list[RankCandidate]:
    data = load_rankings()
    q_tokens = tokens(query)
    results: list[RankCandidate] = []
    aliases = (data.get("qs_world_university_rankings") or {}).get("alias_map", [])

    for ed in (data.get("qs_world_university_rankings") or {}).get("editions", []):
        year = ed.get("edition_year")
        for rec in ed.get("records", []):
            text = norm(" ".join([
                str(rec.get("institution_name", "")),
                str(rec.get("country_territory", "")),
                str(rec.get("region", "")),
                _alias_text_for_qs(str(rec.get("institution_name", "")), aliases),
                "QS", str(year), "雇主声誉", "Employer Reputation",
            ]))
            score = 0.0
            reasons: list[str] = []
            for t in q_tokens:
                nt = norm(t)
                if nt and nt in text:
                    score += 2.0
                    reasons.append(f"命中:{t}")
            if norm(str(rec.get("institution_name", ""))) in norm(query):
                score += 6
                reasons.append("QS英文名精确命中")
            if score > 0:
                out = dict(rec)
                out["edition_year"] = year
                out["ranking_name"] = f"QS World University Rankings {year}"
                results.append(RankCandidate(score, "qs_world_university_rankings", out, reasons))

    softke = data.get("softke_2026") or {}

    for rec in softke.get("project_index_rank_records", []):
        text = norm(" ".join(str(rec.get(k, "")) for k in [
            "project_or_institution_name", "chinese_partner", "foreign_partner", "major", "country_region", "school_level",
            "foreign_qs_2027_name", "foreign_qs_2027_rank", "softke_school_2026_rank", "softke_school_2026_ranking_name",
            "softke_major_2026_rank", "softke_major_2026_status", "softke_major_query",
        ]) + " QS 软科 2027 2026 项目索引排名线索")
        score = 0.0
        reasons: list[str] = []
        for t in q_tokens:
            nt = norm(t)
            if nt and nt in text:
                score += 2.2
                reasons.append(f"命中:{t}")
        if norm(str(rec.get("chinese_partner", ""))) in norm(query):
            score += 4
            reasons.append("中方学校精确命中")
        if norm(str(rec.get("major", ""))) in norm(query):
            score += 3
            reasons.append("专业精确命中")
        if score > 0:
            out = dict(rec)
            out["ranking_name"] = "项目索引内安全命中的QS/软科排名线索"
            results.append(RankCandidate(score, "project_index_rank_records", out, reasons))

    for rec in softke.get("master_project_major_records", []):
        text = norm(" ".join(str(rec.get(k, "")) for k in [
            "chinese_school", "foreign_partner", "country_region", "original_major_field", "candidate_major_name",
            "main_rank", "main_type", "main_province", "major_rank", "major_rating", "mapping_status", "official_match_status",
        ]) + " 软科 2026 中国大学排名 专业排名 主榜")
        score = 0.0
        reasons=[]
        for t in q_tokens:
            nt=norm(t)
            if nt and nt in text:
                score += 2.0
                reasons.append(f"命中:{t}")
        if score > 0:
            out=dict(rec)
            out["ranking_name"]="软科2026项目相关学校/专业派生记录"
            results.append(RankCandidate(score,"softke_2026_master_project_major_records",out,reasons))

    for rec in (softke.get("coop_school_ranking") or {}).get("records", []):
        text = norm(" ".join(str(rec.get(k, "")) for k in ["school_name", "english_name", "province", "school_type", "rank", "main_reference_rank"]) + " 软科 2026 合作办学大学排名")
        score=0.0; reasons=[]
        for t in q_tokens:
            nt=norm(t)
            if nt and nt in text:
                score += 2.0
                reasons.append(f"命中:{t}")
        if score>0:
            out=dict(rec); out["ranking_name"]="软科2026中国合作办学大学排名"
            results.append(RankCandidate(score,"softke_2026_coop_school_ranking",out,reasons))

    for rec in (softke.get("bcmr_major_index") or {}).get("majors", []):
        text = norm(" ".join(str(rec.get(k, "")) for k in ["major", "lookup_name", "code", "url"]) + " 软科 2026 中国大学专业排名 专业目录")
        score=0.0; reasons=[]
        for t in q_tokens:
            nt=norm(t)
            if nt and nt in text:
                score += 1.5
                reasons.append(f"命中:{t}")
        if score>0:
            out=dict(rec); out["ranking_name"]="软科2026中国大学专业排名目录索引"
            results.append(RankCandidate(score,"softke_2026_bcmr_major_index",out,reasons))

    results.sort(key=lambda c: c.score, reverse=True)
    return results[:top]


def summarize_rank_candidate(c: RankCandidate, rank_order: int | None = None) -> dict[str, Any]:
    rec = c.record
    keep = [
        "ranking_name", "edition_year", "institution_name", "rank", "previous_rank", "country_territory",
        "academic_reputation_rank", "employer_reputation_rank", "employment_outcomes_rank",
        "chinese_school", "foreign_partner", "original_major_field", "candidate_major_name", "main_rank", "main_province",
        "main_type", "major_rank", "major_rating", "mapping_status", "official_match_status",
        "school_name", "english_name", "province", "school_type", "main_reference_rank",
        "major", "lookup_name", "code", "url",
        "project_or_institution_name", "chinese_partner", "foreign_partner", "country_region", "school_level",
        "foreign_qs_2027_rank", "foreign_qs_2027_name", "foreign_qs_match_status",
        "softke_school_2026_rank", "softke_school_2026_ranking_name", "softke_school_match_status",
        "softke_major_2026_rank", "softke_major_2026_status", "softke_major_query",
    ]
    return {
        "rank_order": rank_order,
        "source": c.source,
        "reasons": c.reasons[:8],
        "record": {k: rec.get(k) for k in keep if rec.get(k) not in (None, "")},
        "policy_note": "本地压缩库仅用于名称匹配和线索定位；排名数字写入报告前必须再打开 QS/软科官方或权威原文核验。招生/证书/学费/分数线仍需官方核验。",
    }


def iter_files(root: Path = ROOT) -> Iterable[Path]:
    for p in root.rglob("*"):
        if p.is_file():
            yield p


def validate_package(max_files: int = 20) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []

    for rel in REQUIRED_FILES:
        if not (ROOT / rel).exists():
            errors.append(f"missing required file: {rel}")

    file_list = list(iter_files())
    if len(file_list) > max_files:
        errors.append(f"file count {len(file_list)} exceeds max_files={max_files}")

    for p in ROOT.rglob("*"):
        if p.is_dir() and p.name in FORBIDDEN_TREE_NAMES:
            errors.append(f"forbidden directory present: {p.relative_to(ROOT)}")

    for p in file_list:
        rel = str(p.relative_to(ROOT))
        if "generated_reports" in rel or "imports/" in rel or "runtime_indexes" in rel:
            errors.append(f"forbidden legacy artifact present: {rel}")

    skill_text = SKILL_PATH.read_text("utf-8") if SKILL_PATH.exists() else ""
    license_text = (ROOT / "license.txt").read_text("utf-8") if (ROOT / "license.txt").exists() else ""
    core_workflow_text = CORE_WORKFLOW_PATH.read_text("utf-8") if CORE_WORKFLOW_PATH.exists() else ""
    prompts_text = PROMPTS_PATH.read_text("utf-8") if PROMPTS_PATH.exists() else ""
    source_methods_text = SOURCE_METHODS_PATH.read_text("utf-8") if SOURCE_METHODS_PATH.exists() else ""
    policy_text = skill_text + "\n" + core_workflow_text + "\n" + prompts_text + "\n" + source_methods_text
    for term in COMMUNITY_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"community policy term missing: {term}")
    for term in OFFICIAL_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"official policy term missing: {term}")
    for term in VALUE_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"platform-value policy term missing: {term}")
    for term in FOUR_PATH_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"future-four-path policy term missing: {term}")
    for term in TRUST_AUDIT_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"trust-audit policy term missing: {term}")
    for term in EVIDENCE_LINK_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"evidence-link policy term missing: {term}")
    for term in AUDIT_ORCHESTRATION_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"audit-orchestration policy term missing: {term}")
    for term in RED_DATA_SOURCE_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"red-data-source policy term missing: {term}")
    for term in APPROX_PREFIX_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"approx-prefix policy term missing: {term}")
    for term in CLICKABLE_SOURCE_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"clickable-source policy term missing: {term}")
    for term in NUMERIC_SELF_LINK_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"numeric-self-link policy term missing: {term}")
    for term in RUNTIME_DATE_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"runtime-date policy term missing: {term}")
    for term in MAJOR_INDUSTRY_AI_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"major-industry-ai policy term missing: {term}")
    for term in FUTURE_EMPLOYMENT_HORIZON_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"future-employment-horizon policy term missing: {term}")
    for term in FUNCTION2_FUTURE_COMPARISON_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"function2-future-comparison policy term missing: {term}")
    for term in STARTUP_PAGE_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"startup-page policy term missing: {term}")
    for term in LEGAL_SAFE_WORDING_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"legal-safe wording policy term missing: {term}")
    for term in CURRENT_YEAR_APPROVAL_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"current-year approval policy term missing: {term}")
    for term in FUNCTION3_RANK_ESTIMATION_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"function3 rank-estimation policy term missing: {term}")
    for term in FUNCTION3_NEW_PROJECT_ESTIMATION_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"function3 new-project-estimation policy term missing: {term}")
    for term in KEY_DATA_EVIDENCE_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"key-data-evidence policy term missing: {term}")
    for term in POSTGRAD_RECOMMENDATION_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"postgraduate-recommendation policy term missing: {term}")
    for term in PDF_TABLE_LAYOUT_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"pdf-table-layout policy term missing: {term}")
    for term in PDF_DELIVERY_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"pdf-delivery policy term missing: {term}")
    for term in HTML_DELIVERY_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"html-delivery policy term missing: {term}")
    for term in PDF_TEXT_WRAP_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"pdf-text-wrap policy term missing: {term}")
    for term in CLOSING_DISCLAIMER_POLICY_TERMS:
        if term not in policy_text:
            errors.append(f"closing-disclaimer policy term missing: {term}")
    if DISCLAIMER_REQUIRED not in policy_text:
        errors.append("fixed one-sentence disclaimer missing or altered")
    if "高考志愿填报、费用、证书、培养方案" in policy_text:
        errors.append("legacy long disclaimer must not appear in policy text")
    if "AI生成内容，真实性需自行核实，不代表官方意见，不作为决策依据" in policy_text:
        errors.append("footer disclaimer must not appear; only one fixed sentence is allowed")
    if ("重要声明：" + "本作" + "品内容") in policy_text:
        errors.append("old fixed disclaimer must not appear; use the CoopLens Skill 1.0.12 disclaimer")
    if "SPDX-License-Identifier: MIT-0" not in license_text:
        errors.append("MIT-0 license marker missing from license.txt")
    for forbidden in ["EncodedCommand", "postinstall", "curl |", "Invoke-Expression", "iex ", "WriteAllBytes"]:
        if forbidden.lower() in policy_text.lower():
            errors.append(f"OpenClaw safety rule violation term present: {forbidden}")

    try:
        data = load_index()
        rows = data.get("rows", [])
        if not rows:
            errors.append("index rows empty")
        if data.get("metadata", {}).get("critical_caveat") is None:
            warnings.append("index metadata critical_caveat missing")
        eligible = sum(1 for r in rows if r.get("recommendation_eligible") is True)
        if eligible < 50:
            warnings.append(f"eligible rows unexpectedly low: {eligible}")
    except Exception as e:
        errors.append(f"index validation failed: {e}")

    try:
        rank_data = load_rankings()
        qs_editions = (rank_data.get("qs_world_university_rankings") or {}).get("editions", [])
        qs_count = sum(len(ed.get("records", [])) for ed in qs_editions)
        softke_count = len((rank_data.get("softke_2026") or {}).get("master_project_major_records", []))
        project_rank_count = len((rank_data.get("softke_2026") or {}).get("project_index_rank_records", []))
        alias_count = len((rank_data.get("qs_world_university_rankings") or {}).get("alias_map", []))
        if qs_count < 1000:
            errors.append(f"QS compact DB too small: {qs_count}")
        if softke_count < 100:
            errors.append(f"软科 compact DB too small: {softke_count}")
        if project_rank_count < 100:
            warnings.append(f"project index ranking records unexpectedly low: {project_rank_count}")
        if alias_count < 5:
            warnings.append(f"QS alias map unexpectedly small: {alias_count}")
        if not RANKINGS_SEMANTIC_PATH.exists():
            errors.append("rankings_semantic.md missing")
    except Exception as e:
        errors.append(f"ranking DB validation failed: {e}")

    return {
        "ok": not errors,
        "file_count": len(file_list),
        "max_files": max_files,
        "errors": errors,
        "warnings": warnings,
        "required_files": REQUIRED_FILES,
    }


def check_report_privacy(text: str, strict: bool = True) -> dict[str, Any]:
    """Check final-report text for banned platform/user references.

    Use on generated PDF/Markdown body, not on internal skill docs.
    """
    hits = []
    for term in FORBIDDEN_REPORT_PLATFORM_TERMS:
        pattern = re.escape(term)
        if re.search(pattern, text, flags=re.IGNORECASE):
            hits.append(term)
    # Handles and exact quote-like long lines are soft heuristics.
    if re.search(r"@\w{2,}", text):
        hits.append("possible_handle")
    if strict and re.search(r"[“\"].{18,}[”\"]", text):
        hits.append("possible_long_quote")
    return {"ok": not hits, "hits": sorted(set(hits))}


def check_report_disclaimer(text: str) -> dict[str, Any]:
    """Check that the fixed one-sentence disclaimer is first non-empty line and not expanded."""
    exact_present = DISCLAIMER_REQUIRED in text
    nonempty = [ln.strip() for ln in text.splitlines() if ln.strip()]
    first_nonempty = nonempty[0] if nonempty else ""
    starts_with_required = first_nonempty == DISCLAIMER_REQUIRED or first_nonempty == f"> {DISCLAIMER_REQUIRED}"
    legacy_long_hit = "高考志愿填报、费用、证书、培养方案" in text or "最终均应以教育部监管平台" in text
    footer_hit = "AI生成内容，真实性需自行核实，不代表官方意见，不作为决策依据" in text
    # allow exact quote marker if the report was copied from markdown block, but require it to be first
    return {
        "ok": exact_present and starts_with_required and not legacy_long_hit and not footer_hit,
        "has_exact_disclaimer": exact_present,
        "starts_with_required_disclaimer": starts_with_required,
        "first_nonempty_line": first_nonempty[:160],
        "legacy_long_disclaimer_hit": legacy_long_hit,
        "footer_disclaimer_hit": footer_hit,
        "required": DISCLAIMER_REQUIRED,
    }


def check_report_closing_disclaimer(text: str) -> dict[str, Any]:
    """Require analysis/report deliveries to end with the exact fixed disclaimer.

    Startup screens are exempt because they are entry pages. Function 1/2/3
    final chat answers, Markdown reports and PDF-visible text must close with
    the same disclaimer instead of a source-scope sentence.
    """
    startup_only = (
        "可以用下面 3 个入口开始" in text
        and all(term in text for term in ["① 单项目分析", "② 多项目对比", "③ 按所在省份"])
        and "参考来源与核验说明" not in text
        and "一句话结论" not in text
        and "AI分析报告" not in text
    )
    if startup_only:
        return {"ok": True, "triggered": False, "last_nonempty_line": "", "required": DISCLAIMER_REQUIRED}
    cues = [
        "一句话结论", "单项目分析", "多项目对比", "候选分组", "可参考项目",
        "参考来源与核验说明", "AI分析报告", "PDF", "pdf", "下载报告",
        "就业、升学、出国和保研", "专业与行业前景",
    ]
    triggered = any(term in text for term in cues)
    if not triggered:
        return {"ok": True, "triggered": False, "last_nonempty_line": "", "required": DISCLAIMER_REQUIRED}
    nonempty = [ln.strip() for ln in text.splitlines() if ln.strip() and ln.strip() not in ["```", "~~~"]]
    last = nonempty[-1] if nonempty else ""
    ok = last == DISCLAIMER_REQUIRED or last == f"> {DISCLAIMER_REQUIRED}"
    return {
        "ok": ok,
        "triggered": True,
        "last_nonempty_line": last[:180],
        "required": DISCLAIMER_REQUIRED,
        "marker": CLOSING_DISCLAIMER_MARKER,
    }


def check_report_tone(text: str) -> dict[str, Any]:
    """Check final-report text for overly blunt money/score wording."""
    hits = [term for term in FORBIDDEN_BLUNT_REPORT_TERMS if term in text]
    return {"ok": not hits, "hits": sorted(set(hits))}


def check_report_rating(text: str) -> dict[str, Any]:
    """Check final-report text for project scoring/rating language.

    Official Gaokao scores and ranks are allowed; project ratings, recommendation scores,
    star ratings and weighted scores are not.
    """
    hits = [term for term in FORBIDDEN_RATING_REPORT_TERMS if term in text]
    if RATING_PATTERN.search(text):
        hits.append("numeric_rating_pattern")
    return {"ok": not hits, "hits": sorted(set(hits))}


def check_report_clear_outcome_language(text: str) -> dict[str, Any]:
    """Final reports should use clear wording: 就业、升学、出国和保研情况."""
    hits = [term for term in FORBIDDEN_AMBIGUOUS_OUTCOME_TERMS if term in text]
    return {"ok": not hits, "hits": sorted(set(hits))}


def check_report_rates_module(text: str) -> dict[str, Any]:
    """Ensure reports do not omit employment/further-study/overseas-study/postgraduate recommendation items."""
    missing: list[str] = []
    for group, terms in RATE_MODULE_REQUIRED_GROUPS.items():
        if not any(term in text for term in terms):
            missing.append(group)
    has_clear_title = "就业、升学、出国和保研情况" in text or "就业/升学/出国/保研" in text
    if not has_clear_title:
        missing.append("清晰标题：就业、升学、出国和保研情况")
    return {"ok": not missing, "missing": missing}



def _final_source_tail(text: str) -> str:
    start = _consolidated_source_start_line(text)
    if start is None:
        return ""
    return "\n".join(text.splitlines()[start:])


def check_report_postgraduate_recommendation_evidence(text: str) -> dict[str, Any]:
    """Hard check for 保研率/推免率 evidence.

    Numeric postgraduate-recommendation indicators must be direct hyperlinks to
    official/authoritative sources. If project-level data is unavailable, the
    report must say so instead of inventing or borrowing a rate.
    """
    triggered = any(term in text for term in ["保研", "推免", "推荐免试"])
    if not triggered:
        return {"ok": True, "triggered": False, "missing": [], "numeric_lines": []}

    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    relevant_lines = [ln for ln in lines if any(term in ln for term in ["保研", "推免", "推荐免试"])]
    final_tail = _final_source_tail(text)
    combined_relevant = "\n".join(relevant_lines[:30]) + "\n" + final_tail
    missing: list[str] = []
    numeric_lines = [ln for ln in relevant_lines if POSTGRAD_NUMERIC_CONTEXT_PATTERN.search(ln)]

    has_boundary = any(term in combined_relevant for term in POSTGRAD_BOUNDARY_TERMS)
    has_official_source = _has_source_link(final_tail) and any(term in final_tail for term in POSTGRAD_OFFICIAL_SOURCE_TERMS)
    has_year = bool(YEAR_PATTERN.search(combined_relevant))

    if numeric_lines:
        if not has_year:
            missing.append("保研率/推免率数字缺少统计年份")
        if not has_official_source:
            missing.append("保研率/推免率数字缺少官方/权威来源链接或来源类型")
        for ln in numeric_lines:
            values = _find_important_numeric_values(ln)
            # If the numeric context contains digits but our generic important-number
            # parser misses a unitless value, still require a link on the line.
            if values:
                for value, start, end in values:
                    if not _numeric_value_is_directly_linked(ln, start, end):
                        missing.append(f"保研率/推免率数字未直接链接来源: {value}")
            elif not _has_source_link(ln):
                missing.append("保研率/推免率数字所在行缺少直接来源链接")
    else:
        # Reports may discuss qualification or missing data, but they must not
        # leave the field vague.
        if not has_boundary and not has_official_source:
            missing.append("保研/推免情况缺少官方政策来源或项目级数据缺口说明")

    if has_official_source and not any(term in final_tail for term in ["支持", "内容对应", "核验", "边界", "项目级", "学院级", "学校级"]):
        missing.append("保研/推免来源缺少支持字段或核验边界说明")

    return {
        "ok": not missing,
        "triggered": True,
        "missing": list(dict.fromkeys(missing)),
        "numeric_lines": numeric_lines[:12],
        "has_official_source": has_official_source,
        "has_boundary": has_boundary,
    }


def _visible_cell_text(cell: str) -> str:
    # Measure visible text, not URL targets, for PDF cell overflow risk.
    cell = re.sub(r"\[([^\]]+)\]\((?:https?://|file://)[^)]+\)", r"\1", cell)
    cell = re.sub(r"<a\b[^>]*>(.*?)</a>", r"\1", cell, flags=re.IGNORECASE | re.DOTALL)
    cell = re.sub(r"(?:https?://|file://)\S+", "", cell)
    cell = re.sub(r"<[^>]+>", "", cell)
    return cell.strip()


def _markdown_table_blocks(text: str) -> list[tuple[int, list[str]]]:
    lines = text.splitlines()
    blocks: list[tuple[int, list[str]]] = []
    i = 0
    while i < len(lines):
        if "|" in lines[i] and i + 1 < len(lines) and _is_markdown_table_separator(lines[i + 1]):
            start = i + 1
            block = [lines[i], lines[i + 1]]
            i += 2
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                block.append(lines[i])
                i += 1
            blocks.append((start, block))
        else:
            i += 1
    return blocks


def _is_function2_or_function3_text(text: str) -> bool:
    return any(term in text for term in [
        "多项目对比", "项目A", "项目 A", " vs ", "VS", "候选分组", "候选项目", "可参考项目",
        "总体排序", "优先关注", "功能 2", "功能2", "功能 3", "功能3", "同分段",
    ])




def _is_in_consolidated_source_section(text: str, line_no: int) -> bool:
    start = _consolidated_source_start_line(text)
    return bool(start is not None and line_no >= start + 1)


def _cjk_len(s: str) -> int:
    return sum(1 for ch in s if '\u4e00' <= ch <= '\u9fff')


def _has_dense_comparison_headers(headers: list[str]) -> bool:
    joined = "|".join(headers)
    header_terms = ["学校", "项目", "专业", "分数", "位次", "学费", "培养模式", "证书", "排序", "候选"]
    return sum(1 for term in header_terms if term in joined) >= 3

def check_pdf_table_layout(text: str) -> dict[str, Any]:
    """Check Markdown/HTML/ReportLab patterns that create PDF table overlap.

    1.0.12 is intentionally stricter: Function 2/3 and candidate/reference
    sections must not rely on dense Markdown pipe tables for PDF. The screenshot
    failure pattern is usually a 5-column table with long Chinese project names;
    therefore 5 columns are no longer considered safe for PDF.
    """
    table_blocks = _markdown_table_blocks(text)
    function23 = _is_function2_or_function3_text(text)
    triggered = function23 or bool(table_blocks) or "<table" in text.lower()
    if not triggered:
        return {"ok": True, "triggered": False, "risks": []}
    risks: list[dict[str, Any] | str] = []

    forbidden_patterns = {
        "white-space:nowrap": r"white-space\s*:\s*nowrap",
        "overflow:hidden": r"overflow\s*:\s*hidden",
        "fixed-height-css": r"(?:height|min-height|max-height)\s*:\s*\d+(?:px|pt|mm|cm)",
        "reportlab-rowHeights": r"rowHeights\s*=\s*[^None]|rowHeights\s*:\s*[^None]",
        "reportlab-nosplit": r"splitByRow\s*=\s*False",
        "tight-line-height": r"line-height\s*:\s*(?:0?\.\d+|1(?:\.0)?)(?:\s|;)",
        "table-layout-fixed": r"table-layout\s*:\s*fixed",
    }
    for label, pattern in forbidden_patterns.items():
        if re.search(pattern, text, flags=re.IGNORECASE):
            risks.append(f"禁止的PDF表格样式/参数: {label}")

    for start_line, block in table_blocks:
        header_cells = [c.strip() for c in block[0].strip("|").split("|")]
        col_count = len(header_cells)
        in_sources = _is_in_consolidated_source_section(text, start_line)
        dense_headers = _has_dense_comparison_headers(header_cells)

        if function23 and not in_sources and col_count >= 4:
            risks.append({
                "line": start_line,
                "risk": f"功能2/3正文 {col_count} 列 Markdown 表格不能直转PDF，应拆表或改项目卡片",
                "row": block[0][:220],
            })
        elif col_count >= 5:
            risks.append({"line": start_line, "risk": f"{col_count}列宽表存在PDF挤叠风险，应拆表/横向/卡片化", "row": block[0][:220]})

        if dense_headers and col_count >= 4:
            risks.append({"line": start_line, "risk": "学校/项目+专业+分数/位次+学费/培养模式类对比表必须卡片化，不能作为普通Markdown表格转PDF", "row": block[0][:220]})

        for offset, row in enumerate(block[2:], start=2):
            cells = [c.strip() for c in row.strip("|").split("|")]
            visible_cells = [_visible_cell_text(c) for c in cells]
            max_len = max((len(c) for c in visible_cells), default=0)
            max_cjk = max((_cjk_len(c) for c in visible_cells), default=0)
            row_len = sum(len(c) for c in visible_cells)
            long_cells = [c[:100] for c in visible_cells if len(c) > 22 or _cjk_len(c) > 12]
            # Chinese text does not wrap reliably in many markdown-to-PDF pipelines.
            if (function23 and not in_sources and (max_cjk > 10 or max_len > 18 or row_len > 70)) or max_len > 30 or row_len > 110:
                risks.append({
                    "line": start_line + offset,
                    "risk": "长中文单元格/长行，PDF中容易出现同一单元格文字重叠；应改成项目卡片或一项多行",
                    "max_cell_len": max_len,
                    "max_cjk_len": max_cjk,
                    "row_visible_len": row_len,
                    "sample_cells": long_cells[:3],
                })
            if any(term in row for term in ["来源链接", "原文链接", "数据来源", "https://", "http://"]):
                risks.append({"line": start_line + offset, "risk": "正文表格含来源/长链接，PDF易挤叠；来源应放末尾统一来源章节，数字本身保留链接", "row": row[:220]})

    # If explicit PDF CSS/table config appears, require safe wrapping terms.
    if any(term in text for term in ["<table", "table-layout", "ReportLab", "TableStyle", "rowHeights"]):
        wrap_terms = ["overflow-wrap", "word-break", "white-space: normal", "VALIGN", "Paragraph", "splitByRow=True", "auto row height", "自动行高"]
        if not any(term in text for term in wrap_terms):
            risks.append("PDF表格配置缺少自动换行/顶部对齐/自动行高说明")

    return {"ok": not risks, "triggered": True, "risks": risks[:60]}

def annotate_pdf_table_layout(text: str) -> tuple[str, dict[str, Any]]:
    result = check_pdf_table_layout(text)
    if result.get("ok"):
        return text, result
    lines = text.splitlines()
    risk_lines: set[int] = set()
    for item in result.get("risks", []):
        if isinstance(item, dict) and isinstance(item.get("line"), int):
            risk_lines.add(item["line"])
    out: list[str] = []
    for idx, line in enumerate(lines, start=1):
        out.append(line)
        if idx in risk_lines:
            out.append(PDF_TABLE_RISK_MARKER)
    if not risk_lines:
        out.append("\n" + PDF_TABLE_RISK_MARKER)
    return "\n".join(out), result


def check_pdf_delivery(text: str) -> dict[str, Any]:
    """Require a visible PDF download/link in final Function 1/2/3 delivery.

    This intentionally treats Markdown-only fallbacks and delayed/failure language as incomplete.
    Startup pages and short operational messages should not trigger the check.
    """
    startup_only = (
        "可以用下面 3 个入口开始" in text
        and all(term in text for term in ["① 单项目分析", "② 多项目对比", "③ 按所在省份"])
        and "参考来源与核验说明" not in text
        and "一句话结论" not in text
        and "AI分析报告" not in text
    )
    if startup_only:
        return {"ok": True, "triggered": False, "has_pdf_link": False, "delay_language": [], "missing": []}

    function_final_cues = [
        "功能 1", "功能1", "单项目分析", "一句话结论", "资质与备案",
        "功能 2", "功能2", "多项目对比", "总体排序", "对比结论",
        "功能 3", "功能3", "候选分组", "可参考项目", "同分段", "候选项目",
        "AI分析报告", "参考来源与核验说明", "就业、升学、出国和保研", "专业与行业前景",
    ]
    looks_like_final = any(term in text for term in function_final_cues)
    if not looks_like_final:
        return {"ok": True, "triggered": False, "has_pdf_link": False, "delay_language": [], "missing": []}

    has_pdf = bool(PDF_LINK_PATTERN.search(text))
    delay_hits = [m.group(0)[:120] for m in PDF_DELAY_PATTERN.finditer(text)]
    missing = []
    if not has_pdf:
        missing.append("未生成PDF报告或未给出PDF下载链接")
    if delay_hits:
        missing.append("出现延迟/失败/要求用户继续生成PDF的表达")
    return {
        "ok": has_pdf and not delay_hits,
        "triggered": True,
        "has_pdf_link": has_pdf,
        "delay_language": delay_hits[:8],
        "missing": missing,
        "required": "同一轮最终回复必须包含可点击PDF下载链接；Markdown或失败说明不能替代PDF交付",
    }

def check_function1_completeness(text: str) -> dict[str, Any]:
    triggered = any(term in text for term in ["单项目分析", "一句话结论", "资质与备案"]) and not any(term in text for term in ["多项目对比", "候选分组"])
    if not triggered:
        return {"ok": True, "triggered": False, "missing": []}
    groups = {
        "一句话结论": ["一句话结论"],
        "资质与备案": ["资质与备案", "审批", "备案", "CRS"],
        "所在省份录取门槛与位次空间": ["录取门槛", "位次空间", "最低分", "最低位次"],
        "普通—中外/国际路径位次参照": ["普通—中外", "位次差", "国际路径", "位次参照"],
        "证书与认可度": ["证书", "认可度", "毕业证", "学位证"],
        "费用与四年总投入": ["费用", "四年总投入", "学费"],
        "培养模式与课程/培养方案": ["培养模式", "课程", "培养方案"],
        "专业与行业前景分析": ["专业与行业前景分析", "行业规模", "AI", "人工智能"],
        "未来四年四条路径": ["未来四年", "保研", "考研", "出国", "就业"],
        "就业、升学、出国和保研情况": ["就业、升学、出国和保研情况", "就业率", "升学率", "保研"],
        "同省同分段竞品坐标": ["同省", "竞品", "同分段", "可参考项目"],
        "核对提醒与参考来源": ["核对提醒", "参考来源与核验说明"],
    }
    missing = [name for name, terms in groups.items() if not any(term in text for term in terms)]
    return {"ok": not missing, "triggered": True, "missing": missing}


def check_function3_completeness(text: str) -> dict[str, Any]:
    triggered = any(term in text for term in ["候选分组", "可参考项目", "同分段", "优先关注", "预算"])
    if not triggered:
        return {"ok": True, "triggered": False, "missing": []}
    groups = {
        "候选分组/总体排序": ["候选分组", "总体排序", "优先关注", "备选"],
        "录取位次参照": ["位次", "录取门槛", "分数", "同分段"],
        "证书费用培养": ["证书", "费用", "培养模式"],
        "专业与行业前景/AI": ["专业与行业前景", "AI", "人工智能", "未来人才需求"],
        "就业升学出国保研": ["就业", "升学", "出国", "保研"],
        "无历史线推测依据或边界": ["推测依据", "无历史线", "历史参照", "这不是今年录取预测", "没有历史线"],
        "参考来源与核验说明": ["参考来源与核验说明"],
    }
    missing = [name for name, terms in groups.items() if not any(term in text for term in terms)]
    return {"ok": not missing, "triggered": True, "missing": missing}


def check_completion_gate(text: str) -> dict[str, Any]:
    """All-function delivery gate used after drafting the final answer."""
    report = check_report_policy(text)
    closing_disclaimer = check_report_closing_disclaimer(text)
    pdf_delivery = check_pdf_delivery(text)
    artifact_delivery = check_three_artifact_delivery(text)
    html_consistency = check_html_consistency_from_final_answer(text) if HTML_LINK_PATTERN.search(text) and MARKDOWN_LINK_PATTERN.search(text) else {"ok": False, "triggered": False, "missing": ["没有HTML或Markdown链接，无法检查HTML一致性"]}
    pdf_text_wrap = check_pdf_text_wrap_policy(text)
    function1 = check_function1_completeness(text)
    function2 = check_function2_delivery_quality(text)
    function3 = check_function3_completeness(text)
    pdf_layout = check_pdf_table_layout(text)
    pdf_visual = check_pdf_visual_from_final_answer(text) if PDF_LINK_PATTERN.search(text) else {"ok": False, "triggered": False, "missing": ["没有PDF链接，无法视觉复核"]}
    pdf_key_links = check_pdf_key_data_links_from_final_answer(text) if PDF_LINK_PATTERN.search(text) else {"ok": False, "triggered": False, "missing": ["没有PDF链接，无法核对PDF关键数据链接"]}
    postgrad = check_report_postgraduate_recommendation_evidence(text)
    key_data_evidence = check_key_data_evidence_links(text, open_links=True, timeout=8, max_urls=40)
    new_project_estimation = check_function3_new_project_estimation_basis(text)
    final_product_audit = check_final_product_audit(text)
    ok = report["ok"] and closing_disclaimer["ok"] and pdf_delivery["ok"] and artifact_delivery["ok"] and html_consistency["ok"] and pdf_text_wrap["ok"] and function1["ok"] and function2["ok"] and function3["ok"] and pdf_layout["ok"] and pdf_visual["ok"] and pdf_key_links["ok"] and postgrad["ok"] and key_data_evidence["ok"] and new_project_estimation["ok"] and final_product_audit["ok"]
    return {
        "ok": ok,
        "report_policy": report,
        "closing_disclaimer": closing_disclaimer,
        "pdf_delivery": pdf_delivery,
        "artifact_delivery": artifact_delivery,
        "html_consistency": html_consistency,
        "pdf_text_wrap": pdf_text_wrap,
        "function1_completeness": function1,
        "function2_delivery_quality": function2,
        "function3_completeness": function3,
        "pdf_table_layout": pdf_layout,
        "pdf_visual_layout": pdf_visual,
        "pdf_key_data_links": pdf_key_links,
        "postgraduate_recommendation_evidence": postgrad,
        "key_data_evidence": key_data_evidence,
        "function3_new_project_estimation_basis": new_project_estimation,
        "final_product_audit": final_product_audit,
    }

def check_report_rate_year_source_validity(text: str) -> dict[str, Any]:
    """Ensure 升学率、出国率、考研率、保研率 have year, source and source-validity evidence."""
    missing: dict[str, list[str]] = {}
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    for group, terms in RATE_YEAR_SOURCE_VALIDITY_GROUPS.items():
        matched = [line for line in lines if any(term in line for term in terms)]
        if not matched:
            missing[group] = ["字段或未公开说明"]
            continue
        joined = "\n".join(matched[:10])
        lacks: list[str] = []
        if not YEAR_PATTERN.search(joined):
            lacks.append("年份")
        if not (_has_source_link(joined) or any(term in joined for term in RATE_SOURCE_TERMS)):
            lacks.append("数据来源/链接")
        if not any(term in joined for term in RATE_SOURCE_VALIDITY_TERMS):
            lacks.append("来源有效性/内容对应核验")
        if lacks:
            missing[group] = lacks
    return {"ok": not missing, "missing": missing}


def check_report_future_four_paths(text: str) -> dict[str, Any]:
    """Ensure reports include the mandatory four-year, four-path action plan."""
    missing: list[str] = []
    for group, terms in FUTURE_FOUR_PATH_REQUIRED_GROUPS.items():
        if group == "年级动作":
            absent_years = [t for t in terms if t not in text]
            if absent_years:
                missing.append(f"年级动作缺少:{','.join(absent_years)}")
        elif not any(term in text for term in terms):
            missing.append(group)
    return {"ok": not missing, "missing": missing}


def check_report_major_industry_ai_analysis(text: str) -> dict[str, Any]:
    """Ensure reports include major-to-industry, industry scale, AI and hiring impact analysis."""
    missing: list[str] = []
    for group, terms in MAJOR_INDUSTRY_AI_REQUIRED_GROUPS.items():
        if not any(term in text for term in terms):
            missing.append(group)
    has_clear_title = (
        "专业与行业前景分析" in text
        or "专业与行业前景对比" in text
        or "专业/行业景气与AI适应度" in text
    )
    if not has_clear_title:
        missing.append("清晰标题：专业与行业前景分析")
    return {"ok": not missing, "missing": missing}

def check_report_future_employment_horizon(text: str) -> dict[str, Any]:
    """Ensure the major-industry module looks at 4-8 year employment demand, AI productivity and future hiring structure."""
    groups = {
        "约4-8年就业视角": ["4–8年", "4-8年", "四到八年", "毕业和早期职业", "毕业时", "早期职业", "孩子毕业"],
        "AI生产率/人效影响": ["生产率", "提效", "人效", "效率", "人均产出"],
        "未来人才需求方向": ["未来人才需求", "人才需求", "需求变化", "用人需求", "岗位需求", "招聘需求"],
        "岗位结构变化": ["入门岗位", "岗位压缩", "岗位收缩", "扩张", "收缩", "分化", "结构升级", "头部集中"],
        "学生对冲动作": ["如何应对", "学生如何应对", "作品集", "实习", "项目作品", "AI工具", "大一", "大二", "大三"],
        "非确定预测边界": ["情景判断", "不是确定预测", "不能写成确定预测", "不确定性", "需要继续"],
    }
    missing = [group for group, terms in groups.items() if not any(term in text for term in terms)]
    return {"ok": not missing, "missing": missing}


def check_report_function2_future_employment_comparison(text: str) -> dict[str, Any]:
    """If the text is a Function 2 comparison report, require the 11-chapter structure and Chapter 6 future-employment comparison."""
    trigger_terms = [
        "多项目对比", "对比结论与优先级排序", "第 1 章 对比结论", "第1章 对比结论",
        "项目A", "项目 A", "vs", " VS ", "综合优先级总排序",
    ]
    triggered = any(term in text for term in trigger_terms)
    if not triggered:
        return {"ok": True, "triggered": False, "missing": []}

    chapter_groups = {
        "第1章对比结论": ["对比结论与优先级排序", "综合优先级总排序"],
        "第2章录取门槛": ["录取门槛对比", "能不能上"],
        "第3章全成本": ["全成本对比", "四年到底要花多少钱"],
        "第4章文凭认可": ["文凭与认可度对比", "毕业证到底硬不硬"],
        "第5章毕业去向": ["毕业去向对比", "花了钱，出路怎么样"],
        "第6章专业与行业前景": ["专业与行业前景对比", "专业所在行业好不好", "这个专业未来还能不能"],
        "第7章培养难度": ["培养模式与学业难度对比", "孩子能不能跟上"],
        "第8章待确认事项": ["待确认事项对比", "逐项核对"],
        "第9章适配人群": ["适配人群对比", "哪个更适合"],
        "第10章招生办核实": ["招生办必核实问题", "招生办核实"],
        "第11章小屏总结": ["小屏总结", "最终建议"],
    }
    content_groups = {
        "第6章必须是横向对比": ["对比", "排序", "谁更", "项目A", "项目B", "专业/行业景气与AI适应度排序"],
        "约4-8年未来就业": ["4–8年", "4-8年", "四到八年", "毕业和早期职业", "孩子毕业"],
        "未来人才需求": ["未来人才需求", "人才需求", "需求变化", "岗位需求", "招聘需求", "结构升级"],
        "AI生产率影响": ["生产率", "提效", "人效", "人均产出", "效率"],
        "入门岗位变化": ["入门岗位", "岗位压缩", "岗位收缩", "扩张", "收缩", "分化"],
        "龙头企业业绩": ["龙头企业", "代表企业", "业绩", "营收", "净利润", "年报", "财报"],
        "招聘/JD信号": ["校招", "招聘", "JD", "岗位", "用人需求"],
        "学生应对动作": ["如何应对", "学生如何应对", "作品集", "实习", "项目作品", "AI工具"],
        "不只写当前去向": ["不能只看当下", "不是只看当前", "约 4–8 年", "4–8年", "未来人才需求"],
    }
    missing = []
    for name, terms in {**chapter_groups, **content_groups}.items():
        if not any(term in text for term in terms):
            missing.append(name)
    return {"ok": not missing, "triggered": True, "missing": missing}



def check_function2_delivery_quality(text: str) -> dict[str, Any]:
    """Function 2 must not pass if it keeps unsafe tables or unlinked key data.

    This aggregates the checks that used to be scattered across report-check,
    pdf-table-layout-check and key-data-evidence-check. It is deliberately
    stricter for Function 2 because multi-project reports are where PDF table
    overlap and missing links most often appear.
    """
    triggered = any(term in text for term in [
        "多项目对比", "三校", "项目对比", "对比分析", " vs ", " VS ", "功能 2", "功能2",
        "综合排序", "排序结论", "费用对比", "证书体系对比",
    ])
    if not triggered:
        return {"ok": True, "triggered": False, "issues": {}}

    structure = check_report_function2_future_employment_comparison(text)
    disclaimer = check_report_disclaimer(text)
    numeric_links = check_report_important_numeric_hyperlinks(text)
    key_data = check_key_data_evidence_links(text, open_links=False)
    pdf_layout = check_pdf_table_layout(text)
    pdf_text_wrap = check_pdf_text_wrap_policy(text)

    # Body Markdown pipe tables are banned for Function 2. Even two-column
    # tables can become clipped or lose clickable annotations in common PDF
    # exporters, so Function 2 must use card/list/HTML blocks instead.
    source_start = _consolidated_source_start_line(text)
    body_table_lines: list[dict[str, Any]] = []
    source_table_lines: list[dict[str, Any]] = []
    for start_line, block in _markdown_table_blocks(text):
        if source_start is not None and start_line >= source_start + 1:
            source_table_lines.append({"line": start_line, "header": block[0][:220]})
        else:
            body_table_lines.append({"line": start_line, "header": block[0][:220]})

    forbidden_qs_plain: list[dict[str, Any]] = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        if "QS" in line and re.search(r"(?:QS前\s*\d+|约第\s*\d+位|第\s*\d+位)", line):
            # If the ranking claim line has no inline link or HTML anchor, it is unsafe.
            if not (MARKDOWN_INLINE_LINK_WITH_URL_PATTERN.search(line) or HTML_ANCHOR_URL_TEXT_PATTERN.search(line)):
                forbidden_qs_plain.append({"line": line_no, "context": line.strip()[:240]})

    issues = {
        "structure": structure,
        "disclaimer": disclaimer,
        "numeric_links": numeric_links,
        "key_data_evidence_structural": key_data,
        "pdf_table_layout": pdf_layout,
        "pdf_text_wrap": pdf_text_wrap,
        "body_markdown_tables_forbidden": body_table_lines,
        "source_section_markdown_tables_forbidden": source_table_lines,
        "plain_qs_ranking_claims": forbidden_qs_plain,
    }
    ok = (
        structure["ok"]
        and disclaimer["ok"]
        and numeric_links["ok"]
        and key_data["ok"]
        and pdf_layout["ok"]
        and pdf_text_wrap["ok"]
        and not body_table_lines
        and not source_table_lines
        and not forbidden_qs_plain
    )
    return {
        "ok": ok,
        "triggered": True,
        "required": "Function 2 must start with the disclaimer, use no Markdown pipe tables in body/source sections, link every key number/QS/rank/fee/score, produce Markdown+HTML+PDF, and pass PDF layout/text-wrap checks before export.",
        "issues": issues,
    }

def check_report_source_authority_markers(text: str) -> dict[str, Any]:
    """Lightweight check that final reports distinguish official/authoritative facts from public discussion."""
    missing: list[str] = []
    for group, terms in SOURCE_AUTHORITY_REQUIRED_GROUPS.items():
        if not any(term in text for term in terms):
            missing.append(group)
    # A public-discussion section must not use discussion wording to prove official facts.
    risky_patterns = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if any(t in stripped for t in ["公开讨论", "网络讨论", "匿名聚合", "公开口碑"]):
            continue
        if re.search(r"(网友|帖子|评论区|小红书|知乎|抖音|Reddit).{0,30}(证明|说明|确认|显示)", stripped, flags=re.IGNORECASE):
            risky_patterns.append(stripped[:160])
    return {"ok": not missing and not risky_patterns, "missing": missing, "risky_patterns": risky_patterns[:8]}


def _has_source_link(fragment: str) -> bool:
    return bool(SOURCE_LINK_PATTERN.search(fragment))


def _is_unknown_or_pending(fragment: str) -> bool:
    return any(term in fragment for term in ["未查到", "暂无", "待确认", "需要问", "需要确认", "需官方复核", "待官方确认"])


def _looks_like_fact_requiring_link(fragment: str) -> bool:
    if NUMERIC_OR_RANKING_FACT_PATTERN.search(fragment):
        return True
    return any(term in fragment for term in KEY_FACT_TERMS_REQUIRING_LINK)


def _is_exempt_fact_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return True
    if stripped.startswith("#"):
        return True
    if re.fullmatch(r"[-:|\s]+", stripped):
        return True
    if stripped == DISCLAIMER_REQUIRED:
        return True
    if any(term in stripped for term in RUNTIME_DATE_EXEMPT_TERMS):
        return True
    if stripped.startswith("[PDF") or stripped.startswith("[Markdown") or "sandbox:/" in stripped:
        return True
    # Plain numbered checklist items are not factual numbers unless they contain units or key terms.
    if re.fullmatch(r"\d+[.、)]\s*[^0-9%]+", stripped) and not any(t in stripped for t in KEY_FACT_TERMS_REQUIRING_LINK):
        return True
    return False


def _is_markdown_table_separator(line: str) -> bool:
    stripped = line.strip()
    if "|" not in stripped:
        return False
    cells = [c.strip() for c in stripped.strip("|").split("|")]
    return bool(cells) and all(re.fullmatch(r":?-{2,}:?", c) for c in cells)


def _strip_links_for_numeric_check(fragment: str) -> str:
    # Drop URLs and markdown link targets so numbers inside URLs do not trigger the approximate-value rule.
    out = re.sub(r"\[[^\]]+\]\(https?://[^)]+\)", "", fragment)
    out = re.sub(r"(?:https?://|file://)\S+", "", out)
    out = re.sub(r"(?:cite|filecite)[^]+", "", out)
    return out


def _cell_needs_approx(header: str) -> bool:
    if any(t in header for t in APPROX_EXEMPT_HEADERS) and not any(t in header for t in DATA_VALUE_HEADERS_REQUIRING_APPROX):
        return False
    return any(t in header for t in DATA_VALUE_HEADERS_REQUIRING_APPROX)


def _remove_approx_values(fragment: str) -> str:
    return APPROX_VALUE_OK_PATTERN.sub("", fragment)


def _numeric_cell_missing_approx(cell: str) -> bool:
    clean = _strip_links_for_numeric_check(_strip_html_tags(cell)).strip()
    clean = clean.strip("`* _")
    if not clean or _is_unknown_or_pending(clean):
        return False
    if YEAR_ONLY_PATTERN.fullmatch(clean) or STUDY_MODE_PATTERN.fullmatch(clean):
        return False
    remainder = _remove_approx_values(clean)
    if YEAR_ONLY_PATTERN.fullmatch(remainder.strip()) or STUDY_MODE_PATTERN.fullmatch(remainder.strip()):
        return False
    if APPROX_UNIT_VALUE_PATTERN.search(remainder):
        return True
    return bool(APPROX_BARE_NUMBER_PATTERN.search(remainder))


def _line_missing_approx_prefix(line: str) -> bool:
    clean = _strip_links_for_numeric_check(_strip_html_tags(line)).strip()
    if not clean or _is_unknown_or_pending(clean) or _is_exempt_fact_line(clean):
        return False
    clean = re.sub(r"20\d{2}\s*年", "", clean)
    clean = re.sub(r"\b20\d{2}\b", "", clean)
    # Study-mode labels are names, not approximate data values.
    clean = re.sub(r"\b[1-4]\s*\+\s*[0-4]\b", "", clean)
    remainder = _remove_approx_values(clean)
    if not any(t in clean for t in DATA_VALUE_HEADERS_REQUIRING_APPROX):
        # Still catch obvious score/rate/rank/cost values with units.
        return bool(APPROX_UNIT_VALUE_PATTERN.search(remainder))
    return bool(APPROX_UNIT_VALUE_PATTERN.search(remainder) or APPROX_CONTEXT_VALUE_PATTERN.search(remainder))


def check_report_approx_numeric_prefix(text: str) -> dict[str, Any]:
    """Ensure user-facing numeric data values are displayed with 约 before the value."""
    hits: list[str] = []
    lines_all = text.splitlines()
    current_header: list[str] | None = None

    for i, raw_line in enumerate(lines_all):
        line = raw_line.strip()
        if not line:
            continue
        if "|" in line and not _is_exempt_fact_line(line):
            cells = [c.strip() for c in line.strip("|").split("|")]
            if not cells or all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                continue
            is_header = i + 1 < len(lines_all) and _is_markdown_table_separator(lines_all[i + 1])
            if is_header:
                current_header = cells
                continue
            if current_header:
                for idx, cell in enumerate(cells):
                    header = current_header[idx] if idx < len(current_header) else ""
                    if _cell_needs_approx(header) and _numeric_cell_missing_approx(cell):
                        hits.append(f"表格数值缺少约[{header}]: {cell[:120]}")
                continue
        else:
            current_header = None

        if _line_missing_approx_prefix(line):
            hits.append(line[:180])

    return {"ok": not hits, "missing_approx_prefix": hits[:30]}



def _consolidated_source_start_line(text: str) -> int | None:
    lines = text.splitlines()
    hits: list[int] = []
    for idx, line in enumerate(lines):
        stripped = line.strip().lstrip("#").strip()
        if any(header in stripped for header in CONSOLIDATED_SOURCE_SECTION_HEADERS):
            hits.append(idx)
    return hits[-1] if hits else None


def _has_consolidated_source_section(text: str) -> bool:
    start = _consolidated_source_start_line(text)
    if start is None:
        return False
    tail = "\n".join(text.splitlines()[start:])
    return _has_source_link(tail) and any(term in tail for term in ["官方", "教育部", "CRS", "招生", "省考试院", "学校", "QS", "软科", "培养方案", "就业质量", "核验", "支持"])


def check_report_consolidated_sources(text: str) -> dict[str, Any]:
    """Require one final consolidated source section instead of repeated per-module source blocks."""
    looks_like_report = any(term in text for term in ["AI分析报告", "一句话结论", "录取门槛", "中外合作", "候选分组", "项目对比"])
    if not looks_like_report:
        return {"ok": True, "triggered": False, "missing": [], "per_module_source_blocks": []}
    start = _consolidated_source_start_line(text)
    missing: list[str] = []
    if start is None:
        missing.append("缺少报告末尾统一“参考来源与核验说明”")
        source_tail = ""
    else:
        lines = text.splitlines()
        if start < max(0, int(len(lines) * 0.55)):
            missing.append("“参考来源与核验说明”不在报告末尾区域")
        source_tail = "\n".join(lines[start:])
        if not _has_source_link(source_tail):
            missing.append("统一参考来源章节缺少可点击链接")
        if not any(term in source_tail for term in ["来源类型", "年份", "发布时间", "支持", "核验", "边界", "确认"]):
            missing.append("统一参考来源章节缺少来源类型/年份/支持内容/核验边界说明")
    lines_before = text.splitlines()[:start if start is not None else len(text.splitlines())]
    per_module_hits: list[str] = []
    for raw in lines_before:
        line = raw.strip()
        if not line or _is_exempt_fact_line(line):
            continue
        if PER_MODULE_SOURCE_BLOCK_PATTERN.search(line):
            per_module_hits.append(line[:220])
    return {
        "ok": not missing and not per_module_hits,
        "triggered": True,
        "missing": missing,
        "per_module_source_blocks": per_module_hits[:20],
        "final_source_section_line": None if start is None else start + 1,
    }


def check_report_evidence_links(text: str) -> dict[str, Any]:
    """Check source display under the centralized-source policy.

    Current policy: do not repeat source blocks under every module. Important
    numeric indicators must be directly linked in the body; detailed source
    names, years, pages and boundaries are centralized in the final
    `参考来源与核验说明` section. If that final section exists and has clickable
    links, this check no longer requires a 来源链接 column in every table.
    """
    consolidated = check_report_consolidated_sources(text)
    if consolidated.get("ok"):
        return {
            "ok": True,
            "mode": "centralized_final_sources",
            "missing_source_near_fact": [],
            "table_rows_checked": 0,
            "factual_paragraphs_checked": 0,
            "consolidated_sources": consolidated,
        }

    missing: list[str] = []
    table_rows_checked = 0
    factual_paragraphs_checked = 0

    lines_all = text.splitlines()
    for i, raw_line in enumerate(lines_all):
        line = raw_line.strip()
        if "|" not in line or _is_exempt_fact_line(line):
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if not cells or all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
            continue
        is_header = i + 1 < len(lines_all) and _is_markdown_table_separator(lines_all[i + 1])
        if is_header:
            continue
        if _looks_like_fact_requiring_link(line) and not _is_unknown_or_pending(line):
            table_rows_checked += 1
            if not _has_source_link(line):
                missing.append(line[:220])

    paragraphs = re.split(r"\n\s*\n", text)
    for para in paragraphs:
        lines = [ln.strip() for ln in para.splitlines() if ln.strip()]
        if not lines:
            continue
        if all(_is_exempt_fact_line(ln) or "|" in ln for ln in lines):
            continue
        para_text = " ".join(ln for ln in lines if not ln.startswith("#"))
        if not para_text or _is_unknown_or_pending(para_text):
            continue
        if _looks_like_fact_requiring_link(para_text):
            factual_paragraphs_checked += 1
            if not _has_source_link(para_text):
                missing.append(para_text[:220])

    return {
        "ok": not missing and consolidated.get("ok"),
        "mode": "fallback_nearby_links_without_valid_final_sources",
        "missing_source_near_fact": missing[:20],
        "table_rows_checked": table_rows_checked,
        "factual_paragraphs_checked": factual_paragraphs_checked,
        "consolidated_sources": consolidated,
    }



def check_report_clickable_sources(text: str) -> dict[str, Any]:
    """Reject source labels that only name a source without a clickable link/citation."""
    hits: list[str] = []
    lines_all = text.splitlines()
    for i, raw_line in enumerate(lines_all):
        line = raw_line.strip()
        if not line or _is_exempt_fact_line(line):
            continue
        if "|" in line:
            is_header = i + 1 < len(lines_all) and _is_markdown_table_separator(lines_all[i + 1])
            if is_header or _is_markdown_table_separator(line):
                continue
        if TEXT_ONLY_SOURCE_LABEL_PATTERN.search(line) and not _has_source_link(line) and not _is_unknown_or_pending(line):
            hits.append(line[:220])
    return {"ok": not hits, "text_only_source_labels": hits[:20]}


def _ranges_from_pattern(fragment: str, pattern: re.Pattern[str], group: int | None = None) -> list[tuple[int, int]]:
    ranges: list[tuple[int, int]] = []
    for m in pattern.finditer(fragment):
        if group is None:
            ranges.append((m.start(), m.end()))
        else:
            ranges.append((m.start(group), m.end(group)))
    return ranges


def _span_within(span: tuple[int, int], ranges: list[tuple[int, int]]) -> bool:
    start, end = span
    return any(start >= r_start and end <= r_end for r_start, r_end in ranges)


def _source_url_ranges(fragment: str) -> list[tuple[int, int]]:
    return [(m.start(), m.end()) for m in URL_EXTRACT_PATTERN.finditer(fragment)]


def _direct_numeric_link_ranges(fragment: str) -> list[tuple[int, int]]:
    ranges: list[tuple[int, int]] = []
    # Markdown inline link: [约589分](https://...)
    ranges.extend(_ranges_from_pattern(fragment, MARKDOWN_INLINE_LINK_PATTERN, group=1))
    # Markdown reference-style link: [约589分][official-source]
    ranges.extend(_ranges_from_pattern(fragment, MARKDOWN_REFERENCE_LINK_PATTERN, group=1))
    # HTML/PDF path: <a href="https://...">约589分</a>
    ranges.extend(_ranges_from_pattern(fragment, HTML_ANCHOR_PATTERN, group=None))
    return ranges


def _numeric_value_has_immediate_citation(fragment: str, end: int) -> bool:
    # ChatGPT citations cannot always wrap text, so accept a citation immediately after the number.
    tail = fragment[end : end + 80]
    return bool(IMMEDIATE_CITATION_PATTERN.match(tail))


def _find_important_numeric_values(fragment: str) -> list[tuple[str, int, int]]:
    values: list[tuple[str, int, int]] = []
    seen: set[tuple[int, int]] = set()
    url_ranges = _source_url_ranges(fragment)
    patterns = [IMPORTANT_NUMERIC_VALUE_PATTERN, RANKING_SHORTHAND_VALUE_PATTERN]
    for pattern in patterns:
        for m in pattern.finditer(fragment):
            value = m.group(0).strip()
            if not value:
                continue
            span = (m.start(), m.end())
            if span in seen:
                continue
            if _span_within(span, url_ranges):
                continue
            if _is_unknown_or_pending(fragment):
                continue
            values.append((value, m.start(), m.end()))
            seen.add(span)
    values.sort(key=lambda x: x[1])
    return values


def _numeric_value_is_directly_linked(fragment: str, start: int, end: int) -> bool:
    span = (start, end)
    if _span_within(span, _direct_numeric_link_ranges(fragment)):
        return True
    if _numeric_value_has_immediate_citation(fragment, end):
        return True
    return False


def check_report_important_numeric_hyperlinks(text: str) -> dict[str, Any]:
    """Ensure important numeric indicators are hyperlinks themselves.

    A separate source column or paragraph source is not enough for this check.
    Acceptable forms include [约589分](https://...), HTML <a href="...">约589分</a>,
    or an immediately adjacent ChatGPT citation as a direct-chat fallback.
    """
    hits: list[dict[str, Any]] = []
    total_values = 0
    linked_values = 0
    for line_no, raw_line in enumerate(text.splitlines(), start=1):
        line = raw_line.strip()
        if not line or _is_exempt_fact_line(line) or _is_markdown_table_separator(line):
            continue
        # Reference definitions and attachment links are source infrastructure, not data values.
        if re.fullmatch(r"\[[^\]]+\]:\s*(?:https?://|file://)\S+", line):
            continue
        for value, start, end in _find_important_numeric_values(raw_line):
            total_values += 1
            if _numeric_value_is_directly_linked(raw_line, start, end):
                linked_values += 1
                continue
            hits.append({
                "line": line_no,
                "value": value,
                "issue": "数字未直接链接来源",
                "suggested_fix": f"把 {value} 改写成 [{value}](原始来源URL)，或标注 {UNLINKED_NUMERIC_MARKER}",
                "context": raw_line.strip()[:240],
            })
    return {
        "ok": not hits,
        "checked_numeric_values": total_values,
        "directly_linked_numeric_values": linked_values,
        "unlinked_numeric_count": len(hits),
        "unlinked_numeric_values": hits[:50],
        "required_marker": UNLINKED_NUMERIC_MARKER,
    }


def annotate_unlinked_numeric_values(text: str) -> tuple[str, list[dict[str, Any]]]:
    """Return Markdown with markers inserted after unlinked important numeric indicators."""
    annotated_lines: list[str] = []
    hits: list[dict[str, Any]] = []
    for line_no, raw_line in enumerate(text.splitlines(), start=1):
        line = raw_line
        if not line.strip() or _is_exempt_fact_line(line.strip()) or _is_markdown_table_separator(line):
            annotated_lines.append(raw_line)
            continue
        matches: list[tuple[str, int, int]] = []
        for value, start, end in _find_important_numeric_values(raw_line):
            if _numeric_value_is_directly_linked(raw_line, start, end):
                continue
            matches.append((value, start, end))
            hits.append({"line": line_no, "value": value, "context": raw_line.strip()[:240]})
        if matches:
            # Insert from right to left so positions stay valid.
            new_line = raw_line
            for value, start, end in sorted(matches, key=lambda x: x[1], reverse=True):
                # Avoid double-marking if a previous run already inserted the marker.
                if new_line[end : end + len(UNLINKED_NUMERIC_MARKER)] == UNLINKED_NUMERIC_MARKER:
                    continue
                new_line = new_line[:end] + UNLINKED_NUMERIC_MARKER + new_line[end:]
            annotated_lines.append(new_line)
        else:
            annotated_lines.append(raw_line)
    return "\n".join(annotated_lines), hits



def check_report_no_blanket_source_claims(text: str) -> dict[str, Any]:
    """Reject absolute claims that all data/source material is public, official, or fully verified."""
    hits: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        # Ignore the required fixed disclaimer and internal rule text if someone runs the checker on the skill docs themselves.
        if stripped in {DISCLAIMER_REQUIRED, f"> {DISCLAIMER_REQUIRED}"}:
            continue
        if stripped.startswith("-") and any(term in stripped for term in ["禁止", "不得写", "Do not write", "Blanket-source-claim ban"]):
            continue
        for pat in BLANKET_SOURCE_CLAIM_PATTERNS:
            if pat.search(stripped):
                hits.append(stripped[:220])
                break
    return {"ok": not hits, "forbidden_hits": hits[:20], "marker": BLANKET_SOURCE_CLAIM_MARKER}


def check_final_product_audit(text: str) -> dict[str, Any]:
    """Deterministic companion to the required internal executor/agent final review."""
    disclaimer = check_report_disclaimer(text)
    closing_disclaimer = check_report_closing_disclaimer(text)
    runtime_date_basis = check_report_runtime_date_basis(text)
    blanket_claims = check_report_no_blanket_source_claims(text)
    consolidated_sources = check_report_consolidated_sources(text)
    important_numeric_hyperlinks = check_report_important_numeric_hyperlinks(text)
    key_data_evidence = check_key_data_evidence_links(text, open_links=True, timeout=8, max_urls=40)
    new_project_estimation = check_function3_new_project_estimation_basis(text)
    postgrad = check_report_postgraduate_recommendation_evidence(text)
    pdf_delivery = check_pdf_delivery(text)
    artifact_delivery = check_three_artifact_delivery(text)
    html_consistency = check_html_consistency_from_final_answer(text) if HTML_LINK_PATTERN.search(text) and MARKDOWN_LINK_PATTERN.search(text) else {"ok": False, "triggered": False, "missing": ["没有HTML或Markdown链接，无法检查HTML一致性"]}
    pdf_text_wrap = check_pdf_text_wrap_policy(text)
    function2_delivery = check_function2_delivery_quality(text)
    pdf_layout = check_pdf_table_layout(text)
    pdf_visual = check_pdf_visual_from_final_answer(text) if PDF_LINK_PATTERN.search(text) else {"ok": False, "triggered": False, "missing": ["没有PDF链接，无法视觉复核"]}
    pdf_key_links = check_pdf_key_data_links_from_final_answer(text) if PDF_LINK_PATTERN.search(text) else {"ok": False, "triggered": False, "missing": ["没有PDF链接，无法核对PDF关键数据链接"]}
    ok = (disclaimer["ok"] and closing_disclaimer["ok"] and runtime_date_basis["ok"] and blanket_claims["ok"] and consolidated_sources["ok"]
          and important_numeric_hyperlinks["ok"] and key_data_evidence["ok"] and new_project_estimation["ok"] and postgrad["ok"] and pdf_delivery["ok"] and artifact_delivery["ok"] and html_consistency["ok"] and pdf_text_wrap["ok"] and function2_delivery["ok"] and pdf_layout["ok"] and pdf_visual["ok"] and pdf_key_links["ok"])
    return {
        "ok": ok,
        "disclaimer": disclaimer,
        "closing_disclaimer": closing_disclaimer,
        "runtime_date_basis": runtime_date_basis,
        "no_blanket_source_claims": blanket_claims,
        "consolidated_sources": consolidated_sources,
        "important_numeric_hyperlinks": important_numeric_hyperlinks,
        "key_data_evidence": key_data_evidence,
        "function3_new_project_estimation_basis": new_project_estimation,
        "postgraduate_recommendation_evidence": postgrad,
        "review_mode": {
            "default": "current_executor_or_agent",
            "external_model_api": "optional_only_when_quota_and_permission_exist",
            "api_required": False,
        },
        "pdf_delivery": pdf_delivery,
        "artifact_delivery": artifact_delivery,
        "html_consistency": html_consistency,
        "pdf_text_wrap": pdf_text_wrap,
        "function2_delivery_quality": function2_delivery,
        "pdf_table_layout": pdf_layout,
        "pdf_visual_layout": pdf_visual,
        "pdf_key_data_links": pdf_key_links,
    }

def check_report_no_invalid_sources_for_data(text: str) -> dict[str, Any]:
    """Reject data lines that rely on empty, failed, or non-matching sources."""
    hits: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if any(term in stripped for term in RUNTIME_DATE_EXEMPT_TERMS):
            continue
        has_data = _looks_like_fact_requiring_link(stripped) or any(term in stripped for terms in RATE_YEAR_SOURCE_VALIDITY_GROUPS.values() for term in terms)
        if not has_data:
            continue
        if EMPTY_SOURCE_PATTERN.search(stripped):
            hits.append(stripped[:220])
            continue
        if any(term in stripped for term in FAILED_SOURCE_TERMS):
            # It is acceptable to say no valid source was found only when no data value is being asserted.
            if not _is_unknown_or_pending(stripped):
                hits.append(stripped[:220])
    return {"ok": not hits, "hits": hits[:20]}





def _strip_html_tags(fragment: str) -> str:
    return re.sub(r"<[^>]+>", "", fragment)


def check_report_red_data_source_notice(text: str) -> dict[str, Any]:
    """Ensure every standalone `数据来源：` block is red and carries the required AI/human-check notice.

    Table headers/cells using `数据来源` without a colon are handled by evidence-link checks;
    this check only targets the literal label `数据来源：` requested for source blocks.
    """
    hits_missing_notice: list[str] = []
    hits_missing_red: list[str] = []
    lines = text.splitlines()
    for idx, raw_line in enumerate(lines):
        if "数据来源：" not in raw_line:
            continue
        # If a Markdown table uses the label inside a cell, still require notice/red because the literal colon was used.
        logical = raw_line.strip()
        context = "\n".join(lines[max(0, idx - 1): min(len(lines), idx + 2)])
        plain = _strip_html_tags(logical)
        if DATA_SOURCE_REQUIRED_NOTICE not in plain:
            hits_missing_notice.append(logical[:220])
        # Accept HTML span/font or LaTeX textcolor around the label. The context check allows multi-line span wrappers.
        if not RED_DATA_SOURCE_PATTERN.search(context) and not RED_DATA_SOURCE_PATTERN.search(logical):
            hits_missing_red.append(logical[:220])
    return {
        "ok": not hits_missing_notice and not hits_missing_red,
        "required_notice": DATA_SOURCE_REQUIRED_NOTICE,
        "missing_notice": hits_missing_notice[:20],
        "missing_red_style": hits_missing_red[:20],
    }


def check_report_no_local_sources_as_evidence(text: str) -> dict[str, Any]:
    """Final reports must not cite local indexes/caches as evidence sources."""
    hits: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if any(term.lower() in stripped.lower() for term in LOCAL_SOURCE_TERMS):
            if any(src_word in stripped for src_word in ["来源", "数据来源", "来源链接", "官方显示", "显示", "证据", "依据"]):
                hits.append(stripped[:220])
            elif "不能作为" not in stripped and "只用于" not in stripped and "不是" not in stripped:
                hits.append(stripped[:220])
    return {"ok": not hits, "hits": hits[:20]}


def extract_urls_from_text(text: str) -> list[str]:
    """Extract plain URLs and markdown-link URLs from a report."""
    urls = URL_EXTRACT_PATTERN.findall(text)
    # de-duplicate while preserving order
    seen = set()
    out = []
    for url in urls:
        cleaned = url.rstrip('.,;:，。；、')
        if cleaned not in seen:
            seen.add(cleaned)
            out.append(cleaned)
    return out


def check_urls_open(urls: list[str], timeout: int = 8, max_urls: int | None = None) -> dict[str, Any]:
    """Best-effort URL open check using stdlib urllib.

    This checks whether URLs are reachable from the current runtime. It does not
    prove content match; content match must be verified during web/source reading.
    """
    results = []
    target_urls = urls[:max_urls] if max_urls else urls
    for url in target_urls:
        status = None
        final_url = None
        error = None
        title_hint = None
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 CoopLens link-check"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                status = getattr(resp, "status", None) or resp.getcode()
                final_url = resp.geturl()
                chunk = resp.read(2048)
                title_match = re.search(rb"<title[^>]*>(.*?)</title>", chunk, flags=re.I | re.S)
                if title_match:
                    title_hint = re.sub(r"\s+", " ", title_match.group(1).decode("utf-8", "ignore")).strip()[:160]
        except Exception as e:  # noqa: BLE001 - CLI diagnostic
            error = f"{type(e).__name__}: {e}"
        results.append({"url": url, "opened": bool(status and 200 <= int(status) < 400), "status": status, "final_url": final_url, "title_hint": title_hint, "error": error})
    failed = [r for r in results if not r["opened"]]
    return {"ok": not failed, "checked": len(results), "failed_count": len(failed), "results": results}


def _plain_text_from_html_or_bytes(data: bytes, content_type: str | None = None) -> str:
    # Best-effort only. For PDFs this may catch embedded text but is not OCR.
    decoded = data.decode("utf-8", "ignore")
    decoded = re.sub(r"<script[\s\S]*?</script>", " ", decoded, flags=re.I)
    decoded = re.sub(r"<style[\s\S]*?</style>", " ", decoded, flags=re.I)
    decoded = re.sub(r"<[^>]+>", " ", decoded)
    decoded = re.sub(r"\s+", " ", decoded)
    return decoded[:500000]


def _normalize_digits_for_evidence(s: str) -> str:
    s = s.replace("，", ",").replace("％", "%")
    s = re.sub(r"约|第|名|位|分|人|万元|亿元|万亿元|元|/年|%|％|所|个|项|门|次|倍|\s|,", "", s)
    return s.strip()


def _candidate_numeric_tokens(anchor_text: str) -> list[str]:
    tokens: list[str] = []
    for m in re.finditer(r"\d+(?:\.\d+)?", anchor_text):
        tok = m.group(0)
        if tok not in tokens:
            tokens.append(tok)
    # For values like 2.5万, also try 25000.
    m = re.search(r"(\d+(?:\.\d+)?)\s*万", anchor_text)
    if m:
        try:
            val = str(int(float(m.group(1)) * 10000))
            if val not in tokens:
                tokens.append(val)
        except Exception:
            pass
    return tokens


def _line_critical_data_terms(line: str) -> bool:
    return any(term in line for term in KEY_FACT_TERMS_REQUIRING_LINK + ["QS排名", "软科排名", "QS 排名", "软科 排名", "排位", "分数线", "招生人数"])


def _linked_numeric_url_for_span(line: str, start: int, end: int) -> dict[str, Any] | None:
    span = (start, end)
    for m in MARKDOWN_INLINE_LINK_WITH_URL_PATTERN.finditer(line):
        text_span = (m.start(1), m.end(1))
        if _span_within(span, [text_span]):
            return {"kind": "markdown", "url": m.group(2), "anchor_text": m.group(1)}
    for m in HTML_ANCHOR_URL_TEXT_PATTERN.finditer(line):
        if start >= m.start() and end <= m.end():
            return {"kind": "html", "url": m.group(1), "anchor_text": _strip_html_tags(m.group(2))}
    if _numeric_value_has_immediate_citation(line, end):
        return {"kind": "citation", "url": None, "anchor_text": line[start:end]}
    return None


def _fetch_url_text(url: str, timeout: int = 8) -> dict[str, Any]:
    status = None
    final_url = None
    error = None
    content_text = ""
    try:
        parsed = urlparse(url)
        if parsed.scheme == "file":
            local_path = Path(parsed.path)
            data = local_path.read_bytes()
            status = 200
            final_url = url
            content_text = _plain_text_from_html_or_bytes(data, None)
        elif parsed.scheme in {"http", "https"}:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 CoopLens key-data-evidence-check"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                status = getattr(resp, "status", None) or resp.getcode()
                final_url = resp.geturl()
                data = resp.read(800000)
                content_text = _plain_text_from_html_or_bytes(data, resp.headers.get("content-type"))
        else:
            error = f"unsupported URL scheme: {parsed.scheme or 'empty'}"
    except Exception as e:  # noqa: BLE001 - CLI diagnostic
        error = f"{type(e).__name__}: {e}"
    opened = bool(status and 200 <= int(status) < 400)
    return {"opened": opened, "status": status, "final_url": final_url, "error": error, "content_text": content_text}


def _content_supports_anchor(anchor_text: str, context: str, content_text: str) -> dict[str, Any]:
    # Content match is best-effort; final human/agent review remains required for PDF tables and dynamic pages.
    normalized_content = content_text.replace(",", "")
    tokens = _candidate_numeric_tokens(anchor_text)
    token_hits = [tok for tok in tokens if tok and tok in normalized_content]
    context_terms = [term for term in KEY_FACT_TERMS_REQUIRING_LINK if term in context]
    context_hits = [term for term in context_terms if term in content_text]
    supported = bool(token_hits) and (bool(context_hits) or len(token_hits) >= 1)
    return {"supported": supported, "numeric_token_hits": token_hits[:5], "context_term_hits": context_hits[:5]}


def _key_data_evidence_items(text: str) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    source_start = _consolidated_source_start_line(text)
    for line_no, raw_line in enumerate(text.splitlines(), start=1):
        if source_start is not None and line_no >= source_start + 1:
            # The final source section records links/status/boundaries. It may repeat values
            # descriptively, but body data values are what need direct numeric anchors here.
            continue
        line = raw_line.strip()
        if not line or _is_exempt_fact_line(line) or _is_markdown_table_separator(line):
            continue
        if re.fullmatch(r"\[[^\]]+\]:\s*(?:https?://|file://)\S+", line):
            continue
        values = _find_important_numeric_values(raw_line)
        if not values:
            continue
        if not _line_critical_data_terms(raw_line) and not any(unit in raw_line for unit in ["分", "位", "%", "万元", "排名", "QS", "软科", "招生", "学费", "就业", "升学", "保研", "出国"]):
            continue
        for value, start, end in values:
            link = _linked_numeric_url_for_span(raw_line, start, end)
            items.append({
                "line": line_no,
                "value": value,
                "context": raw_line.strip()[:260],
                "link": link,
            })
    return items


def check_key_data_evidence_links(text: str, open_links: bool = False, timeout: int = 8, max_urls: int | None = None) -> dict[str, Any]:
    """Check key data values have source links and, optionally, open/content-match them.

    Structural mode checks that key values are directly linked and that the final
    source section records link/content-match status. Open mode performs a
    best-effort URL fetch and checks that the opened content contains the numeric
    value and at least one related context term.
    """
    items = _key_data_evidence_items(text)
    missing_or_non_url: list[dict[str, Any]] = []
    url_items: list[dict[str, Any]] = []
    citation_items: list[dict[str, Any]] = []
    for item in items:
        link = item.get("link")
        if not link:
            missing_or_non_url.append({**item, "issue": "关键数据没有直接来源链接"})
        elif link.get("kind") == "citation":
            citation_items.append(item)
        elif not link.get("url"):
            missing_or_non_url.append({**item, "issue": "链接为空"})
        else:
            url_items.append(item)

    source_tail = _final_source_tail(text)
    final_source_status_ok = bool(source_tail) and any(term in source_tail for term in ["链接状态", "可打开", "已打开", "打开状态"]) and any(term in source_tail for term in ["内容对应", "内容匹配", "支持的数据", "支持事实", "核验边界"])

    opened_results: list[dict[str, Any]] = []
    cache: dict[str, dict[str, Any]] = {}
    if open_links:
        limited = url_items[:max_urls] if max_urls else url_items
        for item in limited:
            url = item["link"]["url"]
            fetched = cache.get(url)
            if fetched is None:
                fetched = _fetch_url_text(url, timeout=timeout)
                cache[url] = fetched
            content_match = _content_supports_anchor(item["link"].get("anchor_text") or item["value"], item["context"], fetched.get("content_text", "")) if fetched.get("opened") else {"supported": False, "numeric_token_hits": [], "context_term_hits": []}
            ok = bool(fetched.get("opened")) and bool(content_match.get("supported"))
            opened_results.append({
                "line": item["line"],
                "value": item["value"],
                "url": url,
                "opened": fetched.get("opened"),
                "status": fetched.get("status"),
                "final_url": fetched.get("final_url"),
                "error": fetched.get("error"),
                "content_match": content_match,
                "ok": ok,
                "context": item["context"],
            })

    failed_open_or_match = [r for r in opened_results if not r.get("ok")]
    # In structural mode, citations are allowed only as direct-chat fallback, but the final source section must show content-match status.
    ok = not missing_or_non_url and final_source_status_ok and not failed_open_or_match
    return {
        "ok": ok,
        "checked_key_data_values": len(items),
        "direct_url_values": len(url_items),
        "citation_values_needing_agent_review": len(citation_items),
        "missing_or_invalid_link_values": missing_or_non_url[:50],
        "final_source_section_has_link_and_content_status": final_source_status_ok,
        "open_links": open_links,
        "opened_results": opened_results[:50],
        "failed_open_or_content_match": failed_open_or_match[:50],
        "required_marker": KEY_DATA_EVIDENCE_UNVERIFIED_MARKER,
    }



NEW_PROJECT_RANGE_PATTERN = re.compile(
    r"约\s*\d+(?:\.\d+)?\s*(?:万)?\s*位?\s*(?:[-—~至到]|—)\s*约?\s*\d+(?:\.\d+)?\s*(?:万)?\s*位|"
    r"(?:乐观|中性|保守)[^。；;\n]{0,60}约\s*\d+(?:\.\d+)?\s*(?:万)?\s*位?\s*(?:[-—~至到]|—)\s*约?\s*\d+(?:\.\d+)?\s*(?:万)?\s*位"
)
NEW_PROJECT_BAD_ESTIMATION_PHRASES = [
    "待补充具体数据", "待补充样本数据", "暂无法给出准确的位次估算范围", "暂无法给出准确", "无法给出准确的位次估算范围",
    "无法给出位次估算范围", "建议考生和家长关注官方招生信息", "请家长自行计算", "用户自行计算", "自行计算", "后续再算",
]
NEW_PROJECT_EXCLUDED_FROM_RANKING_TERMS = ["仅关注/待核验", "仅关注", "待核验，不参与排序", "不参与排序", "不纳入推荐排序", "观察项"]


def _new_project_relevant_segments(text: str) -> list[str]:
    # Look near the new/no-history estimation section, not across the whole report.
    anchors = ["录取位次估算", "无历史线项目", "无历史线", "首招项目", "首次招生", "新开项目", "新学院/首招项目", "新获批"]
    starts = sorted({max(0, text.find(anchor)) for anchor in anchors if text.find(anchor) >= 0})
    if not starts:
        return [text[:2500]]
    return [text[i:i+1800] for i in starts[:8]]


def _has_user_friendly_new_project_range(text: str) -> bool:
    for segment in _new_project_relevant_segments(text):
        visible_segment = _visible_cell_text(segment)
        if NEW_PROJECT_RANGE_PATTERN.search(visible_segment) and any(term in visible_segment for term in ["粗略参照范围", "历史参照范围", "估算结论", "三情景", "乐观", "中性", "保守", "位次区间"]):
            return True
    return False


def _new_project_bad_estimation_phrases(text: str) -> list[str]:
    return [phrase for phrase in NEW_PROJECT_BAD_ESTIMATION_PHRASES if phrase in text]


def _new_project_excluded_from_ranking(text: str) -> bool:
    return any(term in text for term in NEW_PROJECT_EXCLUDED_FROM_RANKING_TERMS)

def check_function3_new_project_estimation_basis(text: str) -> dict[str, Any]:
    """Stronger Function 3 check for new/no-history project rank estimates."""
    triggered = _function3_no_history_estimation_triggered(text)
    if not triggered:
        return {"ok": True, "triggered": False, "missing_basis": [], "numeric_evidence": {}, "required_marker": NEW_PROJECT_ESTIMATION_INCOMPLETE_MARKER}
    base = check_report_function3_no_history_estimation_basis(text)
    required = {
        "项目状态": ["项目状态", "新开项目", "首次招生", "本省首招", "新获批", "无历史线", "暂无本项目历史线"],
        "官方/权威基础事实": ["官方", "权威", "教育部", "CRS", "招生计划", "审批", "备案", "选科", "学费"],
        "B普通招生基线": ["B 普通招生基线", "普通招生基线", "普通基线"],
        "A同省同档样本": ["A 同省同档", "同省同档", "普通—中外", "普通-中外", "国际路径"],
        "相似性维度": ["相似性维度", "学校层次", "城市", "专业接近", "学费区间", "证书模式", "4+0", "外方学校层次"],
        "样本数量与样本强弱": ["样本数量", "样本数", "样本强弱", "弱参照", "样本不足"],
        "计算公式": ["计算公式", "公式", "A→B", "B 粗略参照范围"],
        "非预测边界": ["不是今年录取预测", "不是在预测今年", "不能等同于今年", "粗略参照"],
        "关键数据链接核对": ["链接状态", "内容对应", "支持的数据", "核验边界", "key-data-evidence-check"],
    }
    missing = [name for name, terms in required.items() if not any(term in text for term in terms)]
    key_evidence = check_key_data_evidence_links(text, open_links=True, timeout=8, max_urls=40)
    marker_present = NEW_PROJECT_ESTIMATION_INCOMPLETE_MARKER in text or NEW_PROJECT_NO_RANGE_MARKER in text
    bad_phrases = _new_project_bad_estimation_phrases(text)
    has_range = _has_user_friendly_new_project_range(text)
    excluded_from_ranking = _new_project_excluded_from_ranking(text)
    # If the new/no-history project stays in the candidate recommendation/ranking,
    # the user must receive a broad usable range. "Cannot estimate" and TODO phrases are not acceptable final output.
    range_ok = has_range or excluded_from_ranking
    ok = base.get("ok") and not missing and key_evidence.get("ok") and range_ok and not bad_phrases
    if marker_present:
        ok = False
    return {
        "ok": ok,
        "triggered": True,
        "base_no_history_check": base,
        "missing_basis": missing,
        "has_user_friendly_rough_range": has_range,
        "excluded_from_ranking_instead_of_estimating": excluded_from_ranking,
        "bad_estimation_phrases": bad_phrases,
        "key_data_evidence_structural": key_evidence,
        "required_marker": NEW_PROJECT_ESTIMATION_INCOMPLETE_MARKER,
        "range_required_marker": NEW_PROJECT_NO_RANGE_MARKER,
    }


def check_report_function3_rank_estimation_evidence(text: str) -> dict[str, Any]:
    """Check function-3 style rank estimation has a visible evidence chain."""
    trigger = any(term in text for term in ["粗略参照范围", "历史参照范围", "样本推算", "估算排位", "推算区间", "普通招生基线"])
    forbidden_hits = []
    for line in text.splitlines():
        if re.search(r"今年预计.{0,12}(?:第\s*\d+|\d+\s*位|\d+\s*分|稳到)", line):
            forbidden_hits.append(line.strip()[:160])
    if not trigger:
        return {"ok": not forbidden_hits, "triggered": False, "missing": [], "forbidden_hits": forbidden_hits[:8]}
    required = {
        "B普通招生基线": ["B 普通", "普通招生基线", "普通基线"],
        "A同档样本": ["A 同档", "同省同档", "同档样本"],
        "位次差": ["位次差", "普通—中外", "普通 vs 中外"],
        "样本数或样本不足": ["样本数", "样本不足", "弱参照", "样本偏少"],
        "非预测提醒": ["不是今年录取预测", "不能等同于今年", "不预测今年"],
        "来源链接": ["来源链接", "cite", "http://", "https://"],
    }
    missing = [name for name, terms in required.items() if not any(t in text for t in terms)]
    return {"ok": not missing and not forbidden_hits, "triggered": True, "missing": missing, "forbidden_hits": forbidden_hits[:8]}




def _line_has_direct_linked_numeric_values(line: str) -> bool:
    values = _find_important_numeric_values(line)
    if not values:
        return True
    for _value, start, end in values:
        if not _numeric_value_is_directly_linked(line, start, end):
            return False
    return True


def _function3_no_history_estimation_triggered(text: str) -> bool:
    has_no_history = any(term in text for term in NO_HISTORY_ESTIMATION_TRIGGER_TERMS)
    has_estimation = any(term in text for term in NO_HISTORY_ESTIMATION_ACTION_TERMS)
    function3_like = any(term in text for term in ["所在省", "目标省", "候选", "优先关注", "可作为备选", "总体建议顺序", "当年新批准", "新获批", "可参考项目", "候选分组"])
    return has_no_history and has_estimation and function3_like


def check_report_function3_no_history_estimation_basis(text: str) -> dict[str, Any]:
    """Check Function 3 no-history/first-intake estimates expose their basis.

    For candidates with no historical admission line, a single inferred score/rank
    is not enough. A compliant report shows B baseline, A same-tier samples,
    sample count/weakness, formula, rough range, source links, and non-prediction
    boundary. Missing items may be explicitly marked with the required markers.
    """
    triggered = _function3_no_history_estimation_triggered(text)
    forbidden_hits: list[str] = []
    for line in text.splitlines():
        if re.search(r"今年(?:预计|大概|估计|推测).{0,18}(?:约\s*)?(?:第\s*)?\d+(?:\.\d+)?\s*(?:位|分|名)", line):
            forbidden_hits.append(line.strip()[:180])
    if not triggered:
        return {
            "ok": not forbidden_hits,
            "triggered": False,
            "missing_basis": [],
            "numeric_link_missing": [],
            "forbidden_hits": forbidden_hits[:10],
            "required_markers": [NO_HISTORY_ESTIMATION_INCOMPLETE_MARKER, ESTIMATION_NUMERIC_LINK_MISSING_MARKER],
        }

    required = {
        "无历史线候选核验表": ["无历史线候选核验表", "首次招生候选核验表", "本项目历史线", "没有本项目历史线", "无历史线候选"],
        "B普通招生基线": ["B 普通招生基线", "B普通招生基线", "普通招生基线", "普通基线"],
        "A同省同档样本": ["A 同省同档", "A 同档", "同省同档", "同档普通—中外", "同档普通-中外"],
        "项目状态": ["项目状态", "新开项目", "首次招生", "本省首招", "新获批", "无历史线", "暂无本项目历史线"],
        "官方/权威基础事实": ["官方", "权威", "教育部", "CRS", "招生计划", "审批", "备案", "选科", "学费"],
        "样本数量/样本强弱": ["样本数量", "样本数", "样本不足", "弱参照", "样本强弱", "少于约3组", "约3组"],
        "相似性维度": ["相似性维度", "学校层次", "城市", "专业接近", "学费区间", "证书模式", "4+0", "外方学校层次"],
        "计算公式": ["计算公式", "公式", "=", "B 普通", "B粗略参照范围", "A→B"],
        "B粗略参照范围": ["B 粗略参照范围", "B粗略参照范围", "粗略参照范围", "历史参照范围"],
        "非当年预测边界": ["不是今年录取预测", "不能等同于今年", "不预测今年", "不得写“今年预计", "不是在预测今年"],
        "来源链接": ["来源链接", "原文链接", "https://", "http://", "cite"],
        "链接状态/内容对应": ["链接状态", "内容对应", "内容匹配", "支持的数据", "核验边界"],
    }
    missing_basis = [name for name, terms in required.items() if not any(term in text for term in terms)]

    numeric_link_missing: list[dict[str, Any]] = []
    for line_no, raw_line in enumerate(text.splitlines(), start=1):
        line = raw_line.strip()
        if not line or _is_markdown_table_separator(line) or _is_exempt_fact_line(line):
            continue
        if not any(term in line for term in ESTIMATION_BASIS_LINE_TERMS):
            continue
        for value, start, end in _find_important_numeric_values(raw_line):
            if _numeric_value_is_directly_linked(raw_line, start, end):
                continue
            if ESTIMATION_NUMERIC_LINK_MISSING_MARKER in raw_line:
                continue
            numeric_link_missing.append({"line": line_no, "value": value, "context": line[:240]})

    basis_marked = NO_HISTORY_ESTIMATION_INCOMPLETE_MARKER in text
    numeric_marked = ESTIMATION_NUMERIC_LINK_MISSING_MARKER in text
    ok_missing_basis = (not missing_basis) or basis_marked
    ok_numeric_links = (not numeric_link_missing) or numeric_marked
    ok = ok_missing_basis and ok_numeric_links and not forbidden_hits
    return {
        "ok": ok,
        "triggered": True,
        "missing_basis": missing_basis,
        "basis_incomplete_marker_present": basis_marked,
        "numeric_link_missing": numeric_link_missing[:50],
        "numeric_link_missing_marker_present": numeric_marked,
        "forbidden_hits": forbidden_hits[:10],
        "required_markers": [NO_HISTORY_ESTIMATION_INCOMPLETE_MARKER, ESTIMATION_NUMERIC_LINK_MISSING_MARKER],
    }


def annotate_function3_no_history_estimation(text: str) -> tuple[str, dict[str, Any]]:
    """Add visible markers to a Function 3 no-history estimation report when checks fail."""
    result = check_report_function3_no_history_estimation_basis(text)
    lines = text.splitlines()
    if not result.get("triggered"):
        return text, result

    # Mark numeric-link problems first, before inserting any new line that would shift line numbers.
    if result.get("numeric_link_missing") and ESTIMATION_NUMERIC_LINK_MISSING_MARKER not in "\n".join(lines):
        missing_lines = {item["line"] for item in result.get("numeric_link_missing", [])}
        new_lines: list[str] = []
        for idx, line in enumerate(lines, start=1):
            if idx in missing_lines and ESTIMATION_NUMERIC_LINK_MISSING_MARKER not in line:
                new_lines.append(line + ESTIMATION_NUMERIC_LINK_MISSING_MARKER)
            else:
                new_lines.append(line)
        lines = new_lines

    # Then mark incomplete basis near the first no-history/estimation sentence.
    if result.get("missing_basis") and NO_HISTORY_ESTIMATION_INCOMPLETE_MARKER not in "\n".join(lines):
        inserted = False
        for idx, line in enumerate(lines):
            if any(term in line for term in NO_HISTORY_ESTIMATION_TRIGGER_TERMS + ["推测依据", "粗略参照范围"]):
                lines.insert(idx + 1, NO_HISTORY_ESTIMATION_INCOMPLETE_MARKER)
                inserted = True
                break
        if not inserted:
            lines.append(NO_HISTORY_ESTIMATION_INCOMPLETE_MARKER)

    annotated = "\n".join(lines)
    return annotated, check_report_function3_no_history_estimation_basis(annotated)


def check_report_function3_current_year_approvals(text: str) -> dict[str, Any]:
    """Function-3 style recommendation reports should visibly check current-year MOE/CRS approvals."""
    trigger = any(term in text for term in ["候选分组", "优先关注", "可作为备选", "目标省份", "所在省份", "总体建议顺序", "粗略参照范围"])
    if not trigger:
        return {"ok": True, "triggered": False, "missing": []}
    required = {
        "当年新批准检索": ["当年新批准", "新获批", "最新批准", "最新公布", "最新复核"],
        "教育部/CRS": ["教育部", "CRS", "中外合作办学监管"],
        "所在省计划状态": ["所在省计划", "目标省计划", "本省计划", "招生计划", "专业组"],
        "正式候选边界": ["正式候选", "计划待确认", "可关注", "未核到所在省", "未核到目标省"],
        "来源链接": ["来源链接", "http://", "https://", "cite"],
    }
    missing = [name for name, terms in required.items() if not any(t in text for t in terms)]
    return {"ok": not missing, "triggered": True, "missing": missing}



def check_report_multi_source_verification_awareness(text: str) -> dict[str, Any]:
    """User-visible reports should show source links and cautious wording, while internal verification terms stay hidden.

    This is a lightweight guardrail: it does not expose the internal claim ledger, but it checks that reports with
    high-impact facts have source links and at least some confirmation/official-source language.
    """
    trigger = _looks_like_fact_requiring_link(text)
    if not trigger:
        return {"ok": True, "triggered": False, "missing": []}
    required = {
        "official_or_authoritative_language": ["官方", "省考试院", "教育部", "CRS", "学校", "招生章程", "培养方案", "来源链接", "原文链接"],
        "confirmation_language": ["核到", "核验", "确认", "需要向", "未核到", "口径不一致", "以学校", "以省考试院"],
        "source_links": ["来源链接", "原文链接", "http://", "https://", "cite"],
    }
    missing = [name for name, terms in required.items() if not any(t in text for t in terms)]
    return {"ok": not missing, "triggered": True, "missing": missing}


def check_report_community_module(text: str) -> dict[str, Any]:
    """Ensure public discussion is present as anonymous aggregation."""
    missing: list[str] = []
    for group, terms in COMMUNITY_MODULE_REQUIRED_GROUPS.items():
        if not any(term in text for term in terms):
            missing.append(group)
    return {"ok": not missing, "missing": missing}


def check_report_no_rate_sorting(text: str) -> dict[str, Any]:
    """Employment/further-study/overseas-study/postgraduate recommendation rates must be shown side-by-side, not ranked."""
    hits: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if "不排序" in stripped or "不做排序" in stripped or "只并列" in stripped:
            continue
        if RATE_SORTING_PATTERN.search(stripped):
            hits.append(stripped[:180])
    return {"ok": not hits, "hits": hits[:12]}


def check_report_internal_jargon(text: str) -> dict[str, Any]:
    """Check final-report text for internal codes/placeholders that parents should not see."""
    hits = [term for term in FORBIDDEN_FINAL_INTERNAL_TERMS if term in text]
    # Catch English proxy labels without banning normal Chinese explanation.
    if re.search(r"\bproxy\b", text, flags=re.IGNORECASE):
        hits.append("proxy")
    return {"ok": not hits, "hits": sorted(set(hits))}


def check_report_curriculum(text: str) -> dict[str, Any]:
    """Check that final reports include the mandatory curriculum/course module."""
    has_curriculum_word = "培养方案" in text
    has_course_word = any(term in text for term in ["课程", "课程模块", "课程清单", "宣传册"])
    has_major_profile = any(term in text for term in ["学习难点", "适合孩子", "劝退", "高中能力"])
    ok = has_curriculum_word and has_course_word and has_major_profile
    missing = []
    if not has_curriculum_word:
        missing.append("培养方案")
    if not has_course_word:
        missing.append("课程/课程模块/宣传册")
    if not has_major_profile:
        missing.append("学习难点/适合画像/高中能力")
    return {"ok": ok, "missing": missing}


def _line_has_any(line: str, terms: list[str]) -> bool:
    return any(t in line for t in terms)


def check_report_first_intake_neutrality(text: str) -> dict[str, Any]:
    """Ensure first-intake/no-history status is not used as a recommendation reason."""
    hits: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or not _line_has_any(stripped, FIRST_INTAKE_TERMS):
            continue
        if any(safe in stripped for safe in FIRST_INTAKE_SAFE_NEGATION_TERMS):
            continue
        if _line_has_any(stripped, FIRST_INTAKE_REASON_TERMS) or _line_has_any(stripped, FIRST_INTAKE_JUDGMENT_TERMS):
            hits.append(stripped[:160])
    return {"ok": not hits, "hits": hits[:12]}


def check_report_first_intake_no_avoidance(text: str) -> dict[str, Any]:
    """Ensure first-intake/no-history status is not used to avoid/filter/default-observe function-3 candidates."""
    hits: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        mentions_status = _line_has_any(stripped, FIRST_INTAKE_TERMS) or _line_has_any(stripped, NO_HISTORY_TERMS)
        if not mentions_status:
            continue
        if any(safe in stripped for safe in FIRST_INTAKE_SAFE_NEGATION_TERMS):
            continue
        has_avoidance = any(term in stripped for term in ["回避", "过滤", "排除", "剔除", "淘汰", "不纳入", "不推荐", "暂不建议", "默认观察", "默认放后", "放后"])
        has_reason = _line_has_any(stripped, FIRST_INTAKE_REASON_TERMS) or any(term in stripped for term in ["只因", "仅因", "单因"])
        if has_avoidance and has_reason:
            hits.append(stripped[:180])
    return {"ok": not hits, "hits": hits[:12]}


def check_report_first_intake_rankgap_when_recommending(text: str) -> dict[str, Any]:
    """If a function-3 style report includes first-intake/no-history candidates, require rank-gap evidence rather than avoidance."""
    mentions_status = _line_has_any(text, FIRST_INTAKE_TERMS) or _line_has_any(text, NO_HISTORY_TERMS)
    function3_style = any(term in text for term in ["优先关注", "可作为备选", "候选", "总排序", "总体排序", "粗略参照范围"])
    if not (mentions_status and function3_style):
        return {"ok": True, "triggered": False, "missing": []}
    required = {
        "B普通招生基线": ["B 普通", "普通招生基线", "普通基线", "同校普通"],
        "A同档样本": ["A 同档", "同省同档", "同档样本"],
        "位次差": ["位次差", "普通—中外", "普通 vs 中外"],
        "粗略参照范围": ["粗略参照范围", "历史参照范围", "推算范围"],
        "非预测提醒": ["不是今年录取预测", "不能等同于今年", "不预测今年"],
        "来源链接": ["来源链接", "cite", "http://", "https://"],
    }
    missing = [name for name, terms in required.items() if not any(t in text for t in terms)]
    return {"ok": not missing, "triggered": True, "missing": missing}


def check_report_same_school_reference(text: str) -> dict[str, Any]:
    """If a report says there is no direct history line, it should show same-school international/cooperative reference search first."""
    mentions_no_history = _line_has_any(text, NO_HISTORY_TERMS)
    mentions_same_school_international = _line_has_any(text, SAME_SCHOOL_INTERNATIONAL_TERMS)
    ok = (not mentions_no_history) or mentions_same_school_international
    missing = [] if ok else ["无本项目历史线时缺少同校既有中外/学分互认/国际互认/联合培养参照"]
    return {"ok": ok, "mentions_no_history": mentions_no_history, "mentions_same_school_international": mentions_same_school_international, "missing": missing}


def check_report_same_province_competitor(text: str) -> dict[str, Any]:
    """Reports with competitor/alternative sections should show that formal competitors are target-province alternatives."""
    mentions_competitor = any(t in text for t in ["竞品", "可替代", "可参考", "相似项目"])
    mentions_same_province = _line_has_any(text, SAME_PROVINCE_COMPETITOR_TERMS)
    ok = (not mentions_competitor) or mentions_same_province
    missing = [] if ok else ["竞品/可替代项目未标明目标省招生或同省正式竞品"]
    return {"ok": ok, "mentions_competitor": mentions_competitor, "mentions_same_province": mentions_same_province, "missing": missing}


def check_report_rank_gap_reference(text: str) -> dict[str, Any]:
    """Direct reports should mention ordinary-vs-cooperative rank-gap reference, or explain non-applicability."""
    mentions_rank_gap = _line_has_any(text, RANK_GAP_TERMS)
    mentions_non_applicable = _line_has_any(text, NO_CHINESE_ORDINARY_BASELINE_TERMS)
    ok = mentions_rank_gap or mentions_non_applicable
    missing = [] if ok else ["缺少普通—中外/国际路径位次空间参照或不适用说明"]
    return {"ok": ok, "mentions_rank_gap": mentions_rank_gap, "mentions_non_applicable": mentions_non_applicable, "missing": missing}


def check_report_direct_reply_completeness_markers(text: str) -> dict[str, Any]:
    """Lightweight check for report body containing the required parent-facing blocks."""
    required_groups = {
        "结论": ["先说结论", "结论"],
        "录取参照": ["录取参照", "分数", "位次"],
        "课程": ["培养方案", "课程"],
        "专业与行业前景分析": ["专业所属行业", "行业规模", "景气程度", "龙头企业", "人工智能", "招聘", "如何应对"],
        "未来四年路径": ["未来四年", "四条路", "四条路径", "大一", "大二", "大三", "大四", "出国申硕", "国内考研"],
        "就业、升学、出国和保研情况": ["就业率", "升学率", "深造率", "出国/境升学率", "境外升学", "保研", "推免"],
        "公开讨论": ["公开讨论", "网络讨论", "匿名聚合", "公开口碑"],
        "竞品": ["竞品", "可替代", "相似项目"],
        "普通—中外位次空间": ["普通—中外", "普通 vs 中外", "位次差", "位次空间", "历史参照区间", "不适用"],
        "画像": ["适合孩子", "劝退", "适合家庭"],
        "待问": ["待问", "问清", "需要问"],
    }
    missing = []
    for name, terms in required_groups.items():
        if not any(t in text for t in terms):
            missing.append(name)
    return {"ok": not missing, "missing": missing}


def check_report_runtime_date_basis(text: str) -> dict[str, Any]:
    """Ensure reports visibly state the tool-acquired runtime date/time basis."""
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    has_runtime_line = any(RUNTIME_DATE_LINE_PATTERN.search(ln) for ln in lines[:12])
    has_any_runtime_line = any(RUNTIME_DATE_LINE_PATTERN.search(ln) for ln in lines)
    first_line_ok = bool(lines and lines[0] == DISCLAIMER_REQUIRED)
    position_ok = False
    if first_line_ok and len(lines) >= 2:
        position_ok = bool(RUNTIME_DATE_LINE_PATTERN.search(lines[1]))
    missing = []
    if not has_any_runtime_line:
        missing.append("缺少检索执行日期/运行时日期行")
    elif not has_runtime_line:
        missing.append("检索执行日期行没有放在报告开头附近")
    if not position_ok:
        missing.append("检索执行日期必须紧跟固定免责声明之后")
    return {
        "ok": not missing,
        "has_runtime_line": has_any_runtime_line,
        "line_near_top": has_runtime_line,
        "after_disclaimer": position_ok,
        "missing": missing,
    }


def check_startup_page_contract(text: str) -> dict[str, Any]:
    """Check the launch/startup page stays as a clean three-function entry screen."""
    lines = [ln.rstrip() for ln in text.splitlines()]
    nonempty = [ln.strip() for ln in lines if ln.strip()]
    missing: list[str] = []
    hits: list[str] = []

    if not nonempty or nonempty[0] != DISCLAIMER_REQUIRED:
        missing.append("固定免责声明必须是第一行非空内容")
    if len(nonempty) < 2 or not RUNTIME_DATE_LINE_PATTERN.search(nonempty[1]):
        missing.append("检索执行日期必须紧跟固定免责声明之后")

    for fn in STARTUP_REQUIRED_FUNCTIONS:
        count = text.count(fn)
        if count != 1:
            missing.append(f"核心功能卡片数量错误:{fn} 出现 {count} 次")

    heading_count = sum(1 for ln in nonempty if re.match(r"^#{1,4}\s*[①②③]", ln))
    if heading_count != 3:
        missing.append(f"启动页应只有3个功能标题，当前为 {heading_count} 个")

    if "所在省份" not in text:
        missing.append("启动页必须使用‘所在省份’作为省份口径")
    if "默认按中方高校所在省份" not in text and "默认按中方学校所在地" not in text:
        missing.append("启动页必须说明未写所在省份时默认按中方高校所在省份")

    required_examples = [
        "1，南京师范大学 + 麦考瑞大学 + 计算机科学与技术 + 江苏",
        "2，项目A vs 项目B vs 项目C + 所在省份/分数或位次",
        "3，浙江，物理类，约2.5万位，计算机或人工智能方向，预算约10万每年",
    ]
    for example in required_examples:
        if example not in text:
            missing.append(f"启动页示例必须精确包含新版示例: {example}")

    if not any(term in text for term in ["招生章程", "招生计划", "宣传册", "培养方案", "项目网页截图"]):
        missing.append("缺少材料上传提醒")

    for term in STARTUP_FORBIDDEN_TERMS:
        if term in text:
            hits.append(term)

    if len(nonempty) > 28:
        hits.append(f"启动页过长: 非空行 {len(nonempty)} 行")

    return {
        "ok": not missing and not hits,
        "missing_or_wrong": missing,
        "forbidden_or_messy_hits": sorted(set(hits)),
        "required_functions": STARTUP_REQUIRED_FUNCTIONS,
        "max_nonempty_lines": 28,
        "nonempty_line_count": len(nonempty),
    }


def check_report_pdf_policy(text: str) -> dict[str, Any]:
    """Light check for generated report metadata/content to include PDF-ready title/disclaimer context."""
    has_ai_title = "AI分析报告" in text
    return {"ok": has_ai_title, "has_ai_title": has_ai_title}


def check_report_policy(text: str, strict: bool = True) -> dict[str, Any]:
    privacy = check_report_privacy(text, strict=strict)
    disclaimer = check_report_disclaimer(text)
    closing_disclaimer = check_report_closing_disclaimer(text)
    runtime_date_basis = check_report_runtime_date_basis(text)
    tone = check_report_tone(text)
    rating = check_report_rating(text)
    pdf_policy = check_report_pdf_policy(text)
    clear_outcome_language = check_report_clear_outcome_language(text)
    rate_module = check_report_rates_module(text)
    rate_year_source_validity = check_report_rate_year_source_validity(text)
    future_four_paths = check_report_future_four_paths(text)
    major_industry_ai_analysis = check_report_major_industry_ai_analysis(text)
    future_employment_horizon = check_report_future_employment_horizon(text)
    function2_future_employment_comparison = check_report_function2_future_employment_comparison(text)
    function2_delivery_quality = check_function2_delivery_quality(text)
    source_authority = check_report_source_authority_markers(text)
    community_module = check_report_community_module(text)
    no_rate_sorting = check_report_no_rate_sorting(text)
    internal_jargon = check_report_internal_jargon(text)
    curriculum = check_report_curriculum(text)
    first_intake = check_report_first_intake_neutrality(text)
    first_intake_no_avoidance = check_report_first_intake_no_avoidance(text)
    first_intake_rankgap = check_report_first_intake_rankgap_when_recommending(text)
    same_school_reference = check_report_same_school_reference(text)
    same_province_competitor = check_report_same_province_competitor(text)
    rank_gap_reference = check_report_rank_gap_reference(text)
    direct_reply_markers = check_report_direct_reply_completeness_markers(text)
    evidence_links = check_report_evidence_links(text)
    consolidated_sources = check_report_consolidated_sources(text)
    clickable_sources = check_report_clickable_sources(text)
    important_numeric_hyperlinks = check_report_important_numeric_hyperlinks(text)
    approx_numeric_prefix = check_report_approx_numeric_prefix(text)
    no_invalid_sources_for_data = check_report_no_invalid_sources_for_data(text)
    red_data_source_notice = check_report_red_data_source_notice(text)
    function3_rank_estimation = check_report_function3_rank_estimation_evidence(text)
    function3_no_history_estimation_basis = check_report_function3_no_history_estimation_basis(text)
    function3_current_year_approvals = check_report_function3_current_year_approvals(text)
    no_local_sources = check_report_no_local_sources_as_evidence(text)
    multi_source_awareness = check_report_multi_source_verification_awareness(text)
    postgraduate_recommendation_evidence = check_report_postgraduate_recommendation_evidence(text)
    key_data_evidence = check_key_data_evidence_links(text, open_links=True, timeout=8, max_urls=40)
    function3_new_project_estimation = check_function3_new_project_estimation_basis(text)
    pdf_table_layout = check_pdf_table_layout(text)
    blanket_source_claims = check_report_no_blanket_source_claims(text)
    ok = (privacy["ok"] and disclaimer["ok"] and closing_disclaimer["ok"] and runtime_date_basis["ok"] and tone["ok"] and rating["ok"] and pdf_policy["ok"]
          and clear_outcome_language["ok"] and rate_module["ok"] and rate_year_source_validity["ok"] and future_four_paths["ok"]
          and major_industry_ai_analysis["ok"] and future_employment_horizon["ok"] and function2_future_employment_comparison["ok"] and function2_delivery_quality["ok"] and source_authority["ok"] and community_module["ok"]
          and no_rate_sorting["ok"] and internal_jargon["ok"] and curriculum["ok"] and first_intake["ok"]
          and first_intake_no_avoidance["ok"] and first_intake_rankgap["ok"]
          and same_school_reference["ok"] and same_province_competitor["ok"]
          and rank_gap_reference["ok"] and direct_reply_markers["ok"]
          and evidence_links["ok"] and consolidated_sources["ok"] and clickable_sources["ok"] and important_numeric_hyperlinks["ok"] and approx_numeric_prefix["ok"] and no_invalid_sources_for_data["ok"] and red_data_source_notice["ok"]
          and function3_rank_estimation["ok"] and function3_no_history_estimation_basis["ok"] and function3_current_year_approvals["ok"]
          and no_local_sources["ok"] and multi_source_awareness["ok"] and postgraduate_recommendation_evidence["ok"] and key_data_evidence["ok"] and function3_new_project_estimation["ok"] and pdf_table_layout["ok"] and blanket_source_claims["ok"])
    return {
        "ok": ok,
        "privacy": privacy,
        "disclaimer": disclaimer,
        "closing_disclaimer": closing_disclaimer,
        "runtime_date_basis": runtime_date_basis,
        "tone": tone,
        "rating": rating,
        "pdf_policy": pdf_policy,
        "clear_outcome_language": clear_outcome_language,
        "rate_module": rate_module,
        "rate_year_source_validity": rate_year_source_validity,
        "future_four_paths": future_four_paths,
        "major_industry_ai_analysis": major_industry_ai_analysis,
        "future_employment_horizon": future_employment_horizon,
        "function2_future_employment_comparison": function2_future_employment_comparison,
        "source_authority": source_authority,
        "community_module": community_module,
        "no_rate_sorting": no_rate_sorting,
        "internal_jargon": internal_jargon,
        "curriculum": curriculum,
        "first_intake_neutrality": first_intake,
        "first_intake_no_avoidance": first_intake_no_avoidance,
        "first_intake_rankgap_when_recommending": first_intake_rankgap,
        "same_school_reference": same_school_reference,
        "same_province_competitor": same_province_competitor,
        "rank_gap_reference": rank_gap_reference,
        "direct_reply_markers": direct_reply_markers,
        "evidence_links": evidence_links,
        "consolidated_sources": consolidated_sources,
        "clickable_sources": clickable_sources,
        "important_numeric_hyperlinks": important_numeric_hyperlinks,
        "approx_numeric_prefix": approx_numeric_prefix,
        "no_invalid_sources_for_data": no_invalid_sources_for_data,
        "red_data_source_notice": red_data_source_notice,
        "function3_rank_estimation": function3_rank_estimation,
        "function3_no_history_estimation_basis": function3_no_history_estimation_basis,
        "function3_current_year_approvals": function3_current_year_approvals,
        "no_local_sources_as_evidence": no_local_sources,
        "multi_source_verification_awareness": multi_source_awareness,
        "postgraduate_recommendation_evidence": postgraduate_recommendation_evidence,
        "key_data_evidence": key_data_evidence,
        "function3_new_project_estimation": function3_new_project_estimation,
        "pdf_table_layout": pdf_table_layout,
        "no_blanket_source_claims": blanket_source_claims,
    }





def _pdf_paths_from_text(text: str) -> list[str]:
    paths: list[str] = []
    for m in PDF_LINK_PATTERN.finditer(text):
        raw = m.group(0)
        url_match = re.search(r"\(([^)]+\.pdf(?:[?#][^)]+)?)\)", raw, flags=re.I)
        url = url_match.group(1) if url_match else raw
        url = url.split('#')[0].split('?')[0]
        if url.startswith('sandbox:'):
            url = url.replace('sandbox:', '', 1)
        if url.startswith('./'):
            url = str((ROOT / url[2:]).resolve())
        if url.startswith('/') and url not in paths:
            paths.append(url)
    return paths


def check_pdf_visual_layout(path: str) -> dict[str, Any]:
    """Best-effort visual/text-box check for generated PDF overlap.

    This uses PyMuPDF when available. It cannot replace manual review, but it
    catches common failures: overlapping text spans, extremely narrow table-like
    line spacing, and dense words sharing the same vertical band.
    """
    risks: list[dict[str, Any] | str] = []
    try:
        import fitz  # type: ignore
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "path": path, "error": f"PyMuPDF unavailable: {e}", "risks": ["无法执行PDF视觉渲染复核"]}
    p = Path(path)
    if not p.exists():
        return {"ok": False, "path": path, "error": "PDF file not found", "risks": ["PDF文件不存在，无法视觉复核"]}
    try:
        doc = fitz.open(str(p))
        for page_index, page in enumerate(doc, start=1):
            spans: list[tuple[float, float, float, float, str]] = []
            d = page.get_text("dict")
            for block in d.get("blocks", []):
                for line in block.get("lines", []):
                    for span in line.get("spans", []):
                        txt = (span.get("text") or "").strip()
                        if not txt:
                            continue
                        x0, y0, x1, y1 = map(float, span.get("bbox", [0,0,0,0]))
                        if x1 <= x0 or y1 <= y0:
                            continue
                        spans.append((x0, y0, x1, y1, txt[:60]))
            # Page-edge clipping check: text at the page boundary is often a sign of clipped lines.
            page_rect = page.rect
            for x0, y0, x1, y1, txt in spans:
                if x0 < 2 or x1 > page_rect.width - 2 or y0 < 2 or y1 > page_rect.height - 2:
                    risks.append({"page": page_index, "risk": "PDF文本靠近/越过页面边界，可能被截断", "text": txt, "bbox": [round(x0,1), round(y0,1), round(x1,1), round(y1,1)]})
                    break
            # Pairwise overlap check with tolerance. Ignore near-identical duplicate extraction.
            for i in range(min(len(spans), 900)):
                ax0, ay0, ax1, ay1, at = spans[i]
                for j in range(i + 1, min(len(spans), 900)):
                    bx0, by0, bx1, by1, bt = spans[j]
                    ix = min(ax1, bx1) - max(ax0, bx0)
                    iy = min(ay1, by1) - max(ay0, by0)
                    if ix <= 1.0 or iy <= 1.0:
                        continue
                    area_a = (ax1-ax0)*(ay1-ay0)
                    area_b = (bx1-bx0)*(by1-by0)
                    overlap_ratio = (ix*iy) / max(1.0, min(area_a, area_b))
                    if overlap_ratio > 0.18 and at != bt:
                        risks.append({"page": page_index, "risk": "PDF文本框明显重叠", "a": at, "b": bt, "overlap_ratio": round(overlap_ratio, 3)})
                        if len(risks) >= 25:
                            break
                if len(risks) >= 25:
                    break
            # Dense table heuristic: many short spans in very close y bands.
            y_values = sorted(y0 for _, y0, _, _, _ in spans)
            for k in range(0, max(0, len(y_values)-8)):
                if y_values[k+8] - y_values[k] < 5.0:
                    risks.append({"page": page_index, "risk": "同一水平带文字过密，可能是表格行高不足或文字叠加", "y_band": round(y_values[k], 2)})
                    break
        doc.close()
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "path": path, "error": f"PDF parse error: {type(e).__name__}: {e}", "risks": ["PDF解析失败，不能视为通过"]}
    return {"ok": not risks, "path": path, "risks": risks[:40], "required": "发现PDF文字叠加或视觉复核失败时，必须改成卡片/拆表后重新生成PDF"}


def check_pdf_visual_from_final_answer(text: str) -> dict[str, Any]:
    paths = _pdf_paths_from_text(text)
    if not paths:
        return {"ok": False, "triggered": True, "paths": [], "results": [], "missing": ["最终回复未找到可检查的本地PDF路径"]}
    results = [check_pdf_visual_layout(p) for p in paths[:3]]
    return {"ok": all(r.get("ok") for r in results), "triggered": True, "paths": paths[:3], "results": results}





PDF_KEY_DATA_TERMS = ["位次", "分数", "最低分", "录取", "学费", "招生", "计划", "就业率", "升学率", "出国", "保研", "推免", "QS", "软科", "排名", "营收", "利润", "行业规模", "市场规模"]
PDF_KEY_DATA_UNIT_PATTERN = re.compile(r"约\s*\d+(?:\.\d+)?(?:\s*[-—~至到]\s*约?\s*\d+(?:\.\d+)?)?\s*(?:万位|位|分|万元/年|万元|元/年|元|%|％|人|名|个|亿元|万亿元|亿美元)|QS\s*\d+|软科\s*\d+")


def _rect_intersects(a: tuple[float, float, float, float], b: tuple[float, float, float, float], pad: float = 1.5) -> bool:
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b
    return min(ax1, bx1 + pad) > max(ax0, bx0 - pad) and min(ay1, by1 + pad) > max(ay0, by0 - pad)


def _line_has_pdf_key_data(line_text: str) -> bool:
    if not PDF_KEY_DATA_UNIT_PATTERN.search(line_text):
        return False
    # Page numbers, dates and the fixed disclaimer are not data claims.
    if any(term in line_text for term in ["检索执行日期", "重要声明", "第 ", "页"]):
        return any(term in line_text for term in PDF_KEY_DATA_TERMS)
    # In table rows the header may be on a different extracted line, so a line
    # containing an approximate numeric value with admissions/cost/ranking units
    # must be treated as key data even if the header word is not repeated.
    if any(term in line_text for term in PDF_KEY_DATA_TERMS):
        return True
    return bool(re.search(r"约\s*\d+(?:\.\d+)?\s*(?:万位|位|分|万元/年|万元|元/年|元|%|％|人|名)|约第\s*\d+", line_text))


def check_pdf_key_data_links(path: str) -> dict[str, Any]:
    """Check actual generated PDF preserves clickable links for key numeric data.

    This checks the PDF itself, not Markdown. It fails if the PDF has no link
    annotations, or if key-data lines such as admission rank/score/tuition/rates
    have no link rectangle covering that line. It is a deterministic guardrail
    against the common failure where Markdown values are linked but PDF export
    strips all annotations.
    """
    risks: list[dict[str, Any] | str] = []
    try:
        import fitz  # type: ignore
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "path": path, "error": f"PyMuPDF unavailable: {e}", "risks": ["无法执行PDF关键数据链接复核"]}
    p = Path(path)
    if not p.exists():
        return {"ok": False, "path": path, "error": "PDF file not found", "risks": ["PDF文件不存在，无法复核链接"]}
    try:
        doc = fitz.open(str(p))
        total_links = 0
        checked_lines = 0
        unlinked_lines: list[dict[str, Any]] = []
        for page_index, page in enumerate(doc, start=1):
            link_rects = []
            for link in page.get_links():
                rect = link.get("from")
                if rect:
                    link_rects.append((float(rect.x0), float(rect.y0), float(rect.x1), float(rect.y1)))
            total_links += len(link_rects)
            words = page.get_text("words") or []
            # group by block/line to recover visible lines and their bbox
            grouped: dict[tuple[int, int], list[Any]] = {}
            for w in words:
                if len(w) < 7:
                    continue
                key = (int(w[5]), int(w[6]))
                grouped.setdefault(key, []).append(w)
            for (_block, _line), ws in grouped.items():
                ws_sorted = sorted(ws, key=lambda x: x[0])
                line_text = " ".join(str(w[4]) for w in ws_sorted)
                if not _line_has_pdf_key_data(line_text):
                    continue
                checked_lines += 1
                x0 = min(float(w[0]) for w in ws_sorted); y0 = min(float(w[1]) for w in ws_sorted)
                x1 = max(float(w[2]) for w in ws_sorted); y1 = max(float(w[3]) for w in ws_sorted)
                line_rect = (x0, y0, x1, y1)
                has_link = any(_rect_intersects(line_rect, r, pad=2.0) for r in link_rects)
                if not has_link:
                    unlinked_lines.append({"page": page_index, "line": line_text[:220]})
            # Token-level check: a link anywhere on the line is not enough.
            # Every visible key numeric token should be under a link rectangle.
            for w in words:
                if len(w) < 5:
                    continue
                token = str(w[4])
                if not PDF_KEY_DATA_UNIT_PATTERN.search(token):
                    continue
                if any(term in token for term in ["2026年", "2025年", "06月", "22日"]):
                    continue
                rect = (float(w[0]), float(w[1]), float(w[2]), float(w[3]))
                if not any(_rect_intersects(rect, r, pad=1.0) for r in link_rects):
                    unlinked_lines.append({"page": page_index, "line": f"关键数字未单独覆盖链接：{token}"})
        doc.close()
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "path": path, "error": f"PDF parse error: {type(e).__name__}: {e}", "risks": ["PDF解析失败，不能视为通过"]}
    if total_links == 0 and checked_lines:
        risks.append("PDF没有任何可点击链接注释；关键数字不可能是PDF内可点击来源")
    for item in unlinked_lines[:40]:
        risks.append({"risk": "PDF关键数据行没有可点击链接覆盖", **item})
    return {
        "ok": not risks,
        "path": path,
        "total_pdf_link_annotations": total_links,
        "checked_key_data_lines": checked_lines,
        "unlinked_key_data_lines": unlinked_lines[:40],
        "risks": risks[:60],
        "required_marker": PDF_KEY_DATA_LINK_MISSING_MARKER,
    }


def check_pdf_key_data_links_from_final_answer(text: str) -> dict[str, Any]:
    paths = _pdf_paths_from_text(text)
    if not paths:
        return {"ok": False, "triggered": True, "paths": [], "results": [], "missing": ["最终回复未找到可检查的本地PDF路径"]}
    results = [check_pdf_key_data_links(p) for p in paths[:3]]
    return {"ok": all(r.get("ok") for r in results), "triggered": True, "paths": paths[:3], "results": results}




def _paths_from_text_for_ext(text: str, ext: str) -> list[str]:
    """Extract local/sandbox paths for artifact links with a given extension."""
    pattern = re.compile(rf"\[[^\]]+\]\(([^)]+\.{ext}(?:[?#][^)]+)?)\)|((?:sandbox:/|\./|/)[^\s)\]]+\.{ext}(?:[?#][^\s)\]]+)?)", re.I)
    paths: list[str] = []
    for m in pattern.finditer(text):
        url = (m.group(1) or m.group(2) or "").split('#')[0].split('?')[0]
        if not url:
            continue
        if url.startswith('sandbox:'):
            url = url.replace('sandbox:', '', 1)
        if url.startswith('./'):
            url = str((ROOT / url[2:]).resolve())
        if (url.startswith('/') or not re.match(r'https?://', url)) and url not in paths:
            paths.append(url)
    return paths


def _looks_like_function_final_delivery(text: str) -> bool:
    startup_only = (
        "可以用下面 3 个入口开始" in text
        and "参考来源与核验说明" not in text
        and "一句话结论" not in text
        and "候选项目" not in text
    )
    if startup_only:
        return False
    cues = [
        "功能 1", "功能1", "单项目分析", "一句话结论", "资质与备案",
        "功能 2", "功能2", "多项目对比", "总体排序", "排序结论", "对比分析",
        "功能 3", "功能3", "候选分组", "可参考项目", "同分段", "候选项目",
        "参考来源与核验说明", "专业与行业前景", "未来四年", "AI分析报告",
    ]
    return any(term in text for term in cues)


def check_html_delivery(text: str) -> dict[str, Any]:
    """Require Function 1/2/3 final deliveries to include a visible HTML report link."""
    if not _looks_like_function_final_delivery(text):
        return {"ok": True, "triggered": False, "has_html_link": False, "missing": []}
    has_html = bool(HTML_LINK_PATTERN.search(text))
    missing = [] if has_html else ["未生成HTML可视化报告或未给出HTML下载链接"]
    return {
        "ok": has_html,
        "triggered": True,
        "has_html_link": has_html,
        "missing": missing,
        "required": "功能1/2/3最终回复必须同时提供HTML可视化报告链接；HTML必须从同一份Markdown生成，不能添加额外内容或图片。",
        "required_marker": HTML_DELIVERY_MISSING_MARKER,
    }


def check_markdown_delivery(text: str) -> dict[str, Any]:
    """Require a downloadable/source Markdown report link when PDF/HTML are delivered."""
    if not _looks_like_function_final_delivery(text):
        return {"ok": True, "triggered": False, "has_markdown_link": False, "missing": []}
    has_md = bool(MARKDOWN_LINK_PATTERN.search(text))
    missing = [] if has_md else ["未提供Markdown报告链接；HTML和PDF必须与该Markdown同源"]
    return {"ok": has_md, "triggered": True, "has_markdown_link": has_md, "missing": missing}


def check_three_artifact_delivery(text: str) -> dict[str, Any]:
    pdf = check_pdf_delivery(text)
    html = check_html_delivery(text)
    md = check_markdown_delivery(text)
    ok = pdf["ok"] and html["ok"] and md["ok"]
    return {
        "ok": ok,
        "triggered": pdf.get("triggered") or html.get("triggered") or md.get("triggered"),
        "pdf": pdf,
        "html": html,
        "markdown": md,
        "required": "功能1/2/3同一轮最终回复必须同时给出Markdown、HTML、PDF三件套下载链接。",
    }


def _html_visible_text(html: str) -> str:
    html = re.sub(r"<\s*(script|style|head|title)\b.*?<\s*/\s*\1\s*>", " ", html, flags=re.I | re.S)
    html = re.sub(r"<!--.*?-->", " ", html, flags=re.S)
    html = re.sub(r"<br\s*/?>", "\n", html, flags=re.I)
    html = re.sub(r"</(p|div|h[1-6]|li|tr|section|article|header|footer)>", "\n", html, flags=re.I)
    html = _strip_html_tags(html)
    html = re.sub(r"&nbsp;", " ", html)
    html = re.sub(r"\s+", " ", html)
    return html.strip()


def _markdown_visible_text(md: str) -> str:
    text = re.sub(r"```.*?```", " ", md, flags=re.S)
    text = re.sub(r"!\[[^\]]*\]\([^)]*\)", " ", text)
    text = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"[#>*_`~|\-]+", " ", text)
    text = _strip_html_tags(text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _important_values_from_text(text: str) -> list[str]:
    values = []
    patterns = [IMPORTANT_NUMERIC_VALUE_PATTERN, RANKING_SHORTHAND_VALUE_PATTERN, PDF_KEY_DATA_UNIT_PATTERN]
    for pat in patterns:
        for m in pat.finditer(text):
            v = re.sub(r"\s+", "", m.group(0))
            if v and v not in values and not re.fullmatch(r"20\d{2}年?", v):
                values.append(v)
    return values[:120]


def check_html_report_layout(path: str) -> dict[str, Any]:
    """Check generated HTML is a style layer over the report, not a content/template/image expansion."""
    p = Path(path)
    if not p.exists():
        return {"ok": False, "path": path, "risks": ["HTML文件不存在"]}
    try:
        html = p.read_text("utf-8")
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "path": path, "error": str(e), "risks": ["HTML文件无法读取"]}
    risks: list[str | dict[str, Any]] = []
    visible = _html_visible_text(html)
    if not visible.startswith(DISCLAIMER_REQUIRED):
        risks.append("HTML首个可见文本不是固定重要声明")
    if visible and not visible.rstrip().endswith(DISCLAIMER_REQUIRED):
        risks.append("HTML最后可见文本不是固定重要声明")
    if HTML_FORBIDDEN_EXTRA_PATTERN.search(html):
        risks.append("HTML包含图片、SVG、canvas、script、iframe或背景图片；报告HTML不能增加图片或脚本")
    if re.search(r"white-space\s*:\s*nowrap|overflow\s*:\s*hidden", html, flags=re.I):
        risks.append("HTML/CSS包含nowrap或overflow:hidden，可能导致PDF截断")
    required_css = ["overflow-wrap", "word-break", "line-break", "white-space"]
    missing_css = [t for t in required_css if t not in html]
    if missing_css:
        risks.append({"risk": "HTML缺少PDF安全换行CSS", "missing_css": missing_css})
    if re.search(r"(?:height|max-height)\s*:\s*\d+(?:px|pt|mm|cm)", html, flags=re.I):
        risks.append("HTML存在固定高度，可能导致PDF截断")
    blanket = check_report_no_blanket_source_claims(visible)
    if not blanket.get("ok"):
        risks.append({"risk": "HTML可见文本存在绝对化来源承诺", "hits": blanket.get("forbidden_hits", [])[:5]})
    return {"ok": not risks, "path": path, "risks": risks[:40], "visible_text_length": len(visible)}


def check_html_markdown_consistency(md_path: str, html_path: str) -> dict[str, Any]:
    """Best-effort check that HTML is generated from the same Markdown content and adds no content/images."""
    mdp = Path(md_path); hp = Path(html_path)
    missing_files = [str(p) for p in [mdp, hp] if not p.exists()]
    if missing_files:
        return {"ok": False, "missing_files": missing_files, "risks": ["Markdown或HTML文件不存在"]}
    md = mdp.read_text("utf-8")
    html = hp.read_text("utf-8")
    md_text = _markdown_visible_text(md)
    html_text = _html_visible_text(html)
    risks: list[str | dict[str, Any]] = []
    # Headings from markdown must appear in HTML visible text.
    headings = []
    for line in md.splitlines():
        if line.lstrip().startswith('#'):
            h = re.sub(r"^#+\s*", "", line).strip()
            h = re.sub(r"\s+", "", h)
            if h:
                headings.append(h)
    missing_headings = [h for h in headings if h not in re.sub(r"\s+", "", html_text)]
    if missing_headings:
        risks.append({"risk": "HTML缺少Markdown标题", "missing_headings": missing_headings[:20]})
    # Important values in Markdown must still be visible in HTML.
    html_compact = re.sub(r"\s+", "", html_text)
    missing_values = [v for v in _important_values_from_text(md) if v not in html_compact]
    if missing_values:
        risks.append({"risk": "HTML缺少Markdown中的关键数值", "missing_values": missing_values[:30]})
    # HTML should not add much extra visible text beyond source markdown.
    md_words = set(re.findall(r"[\u4e00-\u9fffA-Za-z0-9%％万亿元位分人名]+", md_text))
    html_words = set(re.findall(r"[\u4e00-\u9fffA-Za-z0-9%％万亿元位分人名]+", html_text))
    extra_words = sorted([w for w in html_words - md_words if len(w) >= 3 and w not in {"HTML", "CSS"}])
    # Allow a small amount of duplicate/chrome text only when not substantive.
    if len(extra_words) > max(25, int(len(md_words) * 0.08)):
        risks.append({"risk": "HTML可见文本疑似增加了Markdown外内容", "extra_word_count": len(extra_words), "sample": extra_words[:30]})
    layout = check_html_report_layout(str(hp))
    if not layout.get("ok"):
        risks.append({"risk": "HTML布局/安全规则不通过", "layout": layout})
    return {
        "ok": not risks,
        "markdown": str(mdp),
        "html": str(hp),
        "risks": risks[:50],
        "required_marker": HTML_CONSISTENCY_MARKER,
    }


def check_html_consistency_from_final_answer(text: str) -> dict[str, Any]:
    md_paths = _paths_from_text_for_ext(text, "md")
    html_paths = _paths_from_text_for_ext(text, "html")
    if not md_paths or not html_paths:
        return {"ok": False, "triggered": True, "md_paths": md_paths, "html_paths": html_paths, "missing": ["最终回复必须同时包含Markdown和HTML本地/沙盒链接以便一致性检查"]}
    results = [check_html_markdown_consistency(md_paths[0], html_paths[0])]
    return {"ok": all(r.get("ok") for r in results), "triggered": True, "md_paths": md_paths[:1], "html_paths": html_paths[:1], "results": results}


def check_pdf_text_wrap_policy(text: str) -> dict[str, Any]:
    """Preflight Markdown/HTML source for text that will clip in PDF if not wrapped."""
    if not _looks_like_function_final_delivery(text) and "<html" not in text.lower():
        return {"ok": True, "triggered": False, "risks": []}
    risks: list[dict[str, Any] | str] = []
    html_mode = "<html" in text.lower()
    html_has_safe_wrap = html_mode and all(x in text for x in ["overflow-wrap", "word-break", "line-break", "white-space"]) and not re.search(r"white-space\s*:\s*nowrap|overflow\s*:\s*hidden", text, flags=re.I)
    for i, line in enumerate(text.splitlines(), start=1):
        stripped = _strip_html_tags(line).strip()
        if not stripped or stripped.startswith("http"):
            continue
        compact = re.sub(r"\s+", "", stripped)
        cjk = _cjk_len(compact)
        # Long CJK lines should be broken before PDF export or rendered with safe CSS.
        if cjk > 42 and not html_has_safe_wrap and not any(marker in line for marker in ["overflow-wrap", "word-break", "line-break", "white-space"]):
            risks.append({"line": i, "risk": "可见中文行过长，PDF里可能截断；需要硬换行或HTML安全换行CSS", "cjk_len": cjk, "sample": stripped[:120]})
    if "<html" in text.lower():
        required = ["overflow-wrap", "word-break", "line-break", "white-space"]
        missing = [x for x in required if x not in text]
        if missing:
            risks.append({"risk": "HTML缺少打印/PDF安全换行CSS", "missing": missing})
    return {"ok": not risks, "triggered": True, "risks": risks[:60], "required_marker": PDF_TEXT_CLIP_RISK_MARKER}


def cmd_pdf_key_data_link_check(args: argparse.Namespace) -> int:
    path = Path(args.path)
    if path.suffix.lower() == '.pdf':
        result = check_pdf_key_data_links(str(path))
    else:
        text = path.read_text('utf-8')
        result = check_pdf_key_data_links_from_final_answer(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get('ok') else 1

def cmd_pdf_visual_layout_check(args: argparse.Namespace) -> int:
    path = Path(args.path)
    if path.suffix.lower() == '.pdf':
        result = check_pdf_visual_layout(str(path))
    else:
        text = path.read_text('utf-8')
        result = check_pdf_visual_from_final_answer(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get('ok') else 1


def cmd_key_data_evidence_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_key_data_evidence_links(text, open_links=not args.no_open, timeout=args.timeout, max_urls=args.max_urls)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_function3_new_project_estimation_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_function3_new_project_estimation_basis(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_postgraduate_recommendation_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_report_postgraduate_recommendation_evidence(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_pdf_table_layout_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_pdf_table_layout(text)
    if args.annotate_out:
        annotated, annotated_result = annotate_pdf_table_layout(text)
        out_path = Path(args.annotate_out)
        out_path.write_text(annotated, "utf-8")
        result["annotated_output"] = str(out_path)
        result["annotated_result"] = annotated_result
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_pdf_delivery_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_pdf_delivery(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1

def cmd_html_delivery_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_html_delivery(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_three_artifact_delivery_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_three_artifact_delivery(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_html_consistency_check(args: argparse.Namespace) -> int:
    if getattr(args, "html", None):
        result = check_html_markdown_consistency(args.markdown, args.html)
    else:
        text = Path(args.markdown).read_text("utf-8")
        result = check_html_consistency_from_final_answer(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_html_report_check(args: argparse.Namespace) -> int:
    result = check_html_report_layout(args.path)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_pdf_text_wrap_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_pdf_text_wrap_policy(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_function1_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_function1_completeness(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_function3_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_function3_completeness(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_completion_gate_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_completion_gate(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_function2_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_function2_delivery_quality(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_consolidated_source_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_report_consolidated_sources(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_runtime_date(args: argparse.Namespace) -> int:
    print(json.dumps(get_runtime_date_context(), ensure_ascii=False, indent=2))
    return 0


def cmd_query(args: argparse.Namespace) -> int:
    cands = query_candidates(args.query, top=args.top, eligible_only=args.eligible_only)
    print(json.dumps([summarize_candidate(c, i + 1) for i, c in enumerate(cands)], ensure_ascii=False, indent=2))
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    result = validate_package(max_files=args.max_files)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_rank_query(args: argparse.Namespace) -> int:
    cands = query_rankings(args.query, top=args.top)
    print(json.dumps([summarize_rank_candidate(c, i + 1) for i, c in enumerate(cands)], ensure_ascii=False, indent=2))
    return 0


def cmd_privacy(args: argparse.Namespace) -> int:
    path = Path(args.path)
    text = path.read_text("utf-8")
    result = check_report_privacy(text, strict=not args.no_strict)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_startup_check(args: argparse.Namespace) -> int:
    path = Path(args.path)
    text = path.read_text("utf-8")
    result = check_startup_page_contract(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_report_check(args: argparse.Namespace) -> int:
    path = Path(args.path)
    text = path.read_text("utf-8")
    result = check_report_policy(text, strict=not args.no_strict)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1




def cmd_numeric_link_check(args: argparse.Namespace) -> int:
    path = Path(args.path)
    text = path.read_text("utf-8")
    result = check_report_important_numeric_hyperlinks(text)
    if args.annotate_out:
        annotated, hits = annotate_unlinked_numeric_values(text)
        out_path = Path(args.annotate_out)
        out_path.write_text(annotated, "utf-8")
        result["annotated_output"] = str(out_path)
        result["annotated_marker_count"] = len(hits)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_function3_estimation_check(args: argparse.Namespace) -> int:
    path = Path(args.path)
    text = path.read_text("utf-8")
    result = check_report_function3_no_history_estimation_basis(text)
    if args.annotate_out:
        annotated, annotated_result = annotate_function3_no_history_estimation(text)
        out_path = Path(args.annotate_out)
        out_path.write_text(annotated, "utf-8")
        result["annotated_output"] = str(out_path)
        result["annotated_result"] = annotated_result
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_industry_check(args: argparse.Namespace) -> int:
    path = Path(args.path)
    text = path.read_text("utf-8")
    result = check_report_major_industry_ai_analysis(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_future_employment_check(args: argparse.Namespace) -> int:
    path = Path(args.path)
    text = path.read_text("utf-8")
    result = check_report_future_employment_horizon(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1



def cmd_closing_disclaimer_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_report_closing_disclaimer(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 2


def cmd_no_blanket_source_claims_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_report_no_blanket_source_claims(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_final_product_audit_check(args: argparse.Namespace) -> int:
    text = Path(args.path).read_text("utf-8")
    result = check_final_product_audit(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def cmd_link_check(args: argparse.Namespace) -> int:
    path = Path(args.path)
    text = path.read_text("utf-8")
    urls = extract_urls_from_text(text)
    result = check_urls_open(urls, timeout=args.timeout, max_urls=args.max_urls)
    result["url_count"] = len(urls)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="CoopLens 1.0.12 helper")
    sub = parser.add_subparsers(required=True)

    p_date = sub.add_parser("runtime-date", help="print runtime date context for current-year decisions")
    p_date.set_defaults(func=cmd_runtime_date)

    p_query = sub.add_parser("query", help="query local candidate index")
    p_query.add_argument("--query", required=True)
    p_query.add_argument("--top", type=int, default=8)
    p_query.add_argument("--eligible-only", action="store_true")
    p_query.set_defaults(func=cmd_query)

    p_val = sub.add_parser("validate", help="validate slim skill package")
    p_val.add_argument("--max-files", type=int, default=20)
    p_val.set_defaults(func=cmd_validate)

    p_rank = sub.add_parser("rank-query", help="query compact local QS/软科 ranking DB")
    p_rank.add_argument("--query", required=True)
    p_rank.add_argument("--top", type=int, default=8)
    p_rank.set_defaults(func=cmd_rank_query)

    p_priv = sub.add_parser("privacy", help="check generated report body for platform/user leakage")
    p_priv.add_argument("path")
    p_priv.add_argument("--no-strict", action="store_true")
    p_priv.set_defaults(func=cmd_privacy)

    p_report = sub.add_parser("report-check", help="check generated report for privacy and fixed disclaimer")
    p_report.add_argument("path")
    p_report.add_argument("--no-strict", action="store_true")
    p_report.set_defaults(func=cmd_report_check)

    p_startup = sub.add_parser("startup-check", help="check startup page only shows the clean three-function entry screen")
    p_startup.add_argument("path")
    p_startup.set_defaults(func=cmd_startup_check)

    p_numlink = sub.add_parser("numeric-link-check", help="check every important numeric indicator is itself a source hyperlink")
    p_numlink.add_argument("path")
    p_numlink.add_argument("--annotate-out", help="write a Markdown copy with markers after unlinked numeric indicators")
    p_numlink.set_defaults(func=cmd_numeric_link_check)

    p_consolidated = sub.add_parser("consolidated-source-check", help="check final consolidated reference-source section and no per-module source clutter")
    p_consolidated.add_argument("path")
    p_consolidated.set_defaults(func=cmd_consolidated_source_check)

    p_f2 = sub.add_parser("function2-check", help="check Function 2 structure, no unsafe tables, disclaimer, and linked key data")
    p_f2.add_argument("path")
    p_f2.set_defaults(func=cmd_function2_check)

    p_f3est = sub.add_parser("function3-estimation-check", help="check Function 3 no-history candidates have complete estimation basis and linked numeric evidence")
    p_f3est.add_argument("path")
    p_f3est.add_argument("--annotate-out", help="write a Markdown copy with missing-basis/link markers")
    p_f3est.set_defaults(func=cmd_function3_estimation_check)

    p_industry = sub.add_parser("industry-check", help="check the mandatory major-industry-AI hiring impact module")
    p_industry.add_argument("path")
    p_industry.set_defaults(func=cmd_industry_check)

    p_future = sub.add_parser("future-employment-check", help="check 4-8 year employment horizon, AI productivity impact and future talent demand")
    p_future.add_argument("path")
    p_future.set_defaults(func=cmd_future_employment_check)

    p_keydata = sub.add_parser("key-data-evidence-check", help="check key data links exist, can be opened, and support linked values")
    p_keydata.add_argument("path")
    p_keydata.add_argument("--no-open", action="store_true", help="skip URL opening and perform structural/source-section status checks only")
    p_keydata.add_argument("--timeout", type=int, default=8)
    p_keydata.add_argument("--max-urls", type=int, default=None)
    p_keydata.set_defaults(func=cmd_key_data_evidence_check)

    p_f3new = sub.add_parser("function3-new-project-estimation-check", help="check Function 3 new/no-history project rank estimates include a full evidence chain")
    p_f3new.add_argument("path")
    p_f3new.set_defaults(func=cmd_function3_new_project_estimation_check)

    p_postgrad = sub.add_parser("postgraduate-recommendation-check", help="check 保研率/推免率 official-source evidence")
    p_postgrad.add_argument("path")
    p_postgrad.set_defaults(func=cmd_postgraduate_recommendation_check)

    p_pdftable = sub.add_parser("pdf-table-layout-check", help="check Function 2/3 PDF table auto-wrap/auto-height and wide-table risks")
    p_pdftable.add_argument("path")
    p_pdftable.add_argument("--annotate-out", help="write a Markdown copy with PDF table layout risk markers")
    p_pdftable.set_defaults(func=cmd_pdf_table_layout_check)

    p_pdfvisual = sub.add_parser("pdf-visual-layout-check", help="render/check generated PDF for overlapping text and table layout failures")
    p_pdfvisual.add_argument("path", help="PDF file path, or final-answer markdown containing a local/sandbox PDF link")
    p_pdfvisual.set_defaults(func=cmd_pdf_visual_layout_check)

    p_pdfkey = sub.add_parser("pdf-key-data-link-check", help="check actual generated PDF preserves clickable links for key numeric data")
    p_pdfkey.add_argument("path", help="PDF file path, or final-answer markdown containing a local/sandbox PDF link")
    p_pdfkey.set_defaults(func=cmd_pdf_key_data_link_check)

    p_pdfdelivery = sub.add_parser("pdf-delivery-check", help="check final answer includes a visible PDF download link")
    p_pdfdelivery.add_argument("path")
    p_pdfdelivery.set_defaults(func=cmd_pdf_delivery_check)

    p_htmldelivery = sub.add_parser("html-delivery-check", help="check final answer includes a visible HTML report link")
    p_htmldelivery.add_argument("path")
    p_htmldelivery.set_defaults(func=cmd_html_delivery_check)

    p_artifacts = sub.add_parser("artifact-delivery-check", help="check final answer includes Markdown, HTML and PDF report links")
    p_artifacts.add_argument("path")
    p_artifacts.set_defaults(func=cmd_three_artifact_delivery_check)

    p_htmlreport = sub.add_parser("html-report-check", help="check generated HTML report has no extra images/content-risk and is PDF-safe")
    p_htmlreport.add_argument("path")
    p_htmlreport.set_defaults(func=cmd_html_report_check)

    p_htmlconsistency = sub.add_parser("html-consistency-check", help="check HTML was generated from the same Markdown without extra content/images")
    p_htmlconsistency.add_argument("markdown", help="Markdown report path, or final-answer markdown containing both links")
    p_htmlconsistency.add_argument("html", nargs="?", help="HTML report path")
    p_htmlconsistency.set_defaults(func=cmd_html_consistency_check)

    p_pdfwrap = sub.add_parser("pdf-text-wrap-check", help="check Markdown/HTML source has no long unwrapped lines likely to clip in PDF")
    p_pdfwrap.add_argument("path")
    p_pdfwrap.set_defaults(func=cmd_pdf_text_wrap_check)

    p_f1 = sub.add_parser("function1-check", help="check Function 1 keeps the full 12-section structure")
    p_f1.add_argument("path")
    p_f1.set_defaults(func=cmd_function1_check)

    p_f3 = sub.add_parser("function3-check", help="check Function 3 keeps candidate-search completeness")
    p_f3.add_argument("path")
    p_f3.set_defaults(func=cmd_function3_check)

    p_gate = sub.add_parser("completion-gate-check", help="check all-function completion gate including PDF delivery")
    p_gate.add_argument("path")
    p_gate.set_defaults(func=cmd_completion_gate_check)

    p_blanket = sub.add_parser("no-blanket-source-claims-check", help="check output does not claim all data/information is public or fully verified")
    p_blanket.add_argument("path")
    p_blanket.set_defaults(func=cmd_no_blanket_source_claims_check)

    p_closing = sub.add_parser("closing-disclaimer-check", help="check final report/chat/PDF-visible text ends with the fixed disclaimer")
    p_closing.add_argument("path")
    p_closing.set_defaults(func=cmd_closing_disclaimer_check)

    p_audit = sub.add_parser("final-product-audit-check", help="deterministic companion to the required executor/agent final product review")
    p_audit.add_argument("path")
    p_audit.set_defaults(func=cmd_final_product_audit_check)

    p_link = sub.add_parser("link-check", help="best-effort check that report URLs can be opened")
    p_link.add_argument("path")
    p_link.add_argument("--timeout", type=int, default=8)
    p_link.add_argument("--max-urls", type=int, default=None)
    p_link.set_defaults(func=cmd_link_check)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
